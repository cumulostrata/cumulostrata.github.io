import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Heading from '@splunk/react-ui/Heading';
import Menu from '@splunk/react-ui/Menu';
import P from '@splunk/react-ui/Paragraph';
import Button from '@splunk/react-ui/Button';
import { includes, without } from 'lodash';
import Switch from '@splunk/react-ui/Switch';
import { Splunk, Enterprise, Light, Cloud, Hunk } from '@splunk/react-ui/Logo'
import Text from '@splunk/react-ui/Text';
import css from './SplunkGCPConfigurationWebsite.css';
import ControlGroup from '@splunk/react-ui/ControlGroup';
import Multiselect from '@splunk/react-ui/Multiselect';
import { createDOMID } from '@splunk/ui-utils/id';
import FormRows from '@splunk/react-ui/FormRows';
import { v4 as uuidv4 } from 'uuid';


class SplunkGCPConfigurationWebsite extends Component {
    static propTypes = {
        name: PropTypes.string,
    };

    static defaultProps = {
        name: 'GCP to Splunk logging configuration',
    };

    constructor(props) {
        super(props);
        // Toggles visibility for certain items through display css styling
        let dynamicValues = {'Cloud Monitoring metrics': 'none', 'Cloud Audit logs': '', 'VPC flow logs': 'none', 'G Suite Admin activity': 'none', 'G Suite Logins': 'none', 'Cloud Asset Inventory snapshots': 'none', 'Custom logging filter(s)': 'none', 'Organization logging filter(s)': 'none', 'HECToken': '', 'EndpointField': '', 'EndpointValue': '' };
        // First rows in the FormRows objects
        const loggingFilterRows = [
            <FormRows.Row index={0} key="0" onRequestRemove={this.handleRequestLoggingFilterRowRemove}>
                <Text placeholder="Custom logging filter" name={0} onChange={this.handleLoggingFilterChange} />
            </FormRows.Row>,
        ];

        const orgLoggingFilterRows = [
            <FormRows.Row index={0} key="0" onRequestRemove={this.handleRequestOrgLoggingFilterRowRemove}>
                <Text placeholder="Custom organization logging filter" name={0} onChange={this.handleOrgLoggingFilterChange} />
            </FormRows.Row>,
        ];

        this.state = {
            // The FormRows objects for VPC Flow logs and CloudWatch logs
            loggingFilterRows,
            orgLoggingFilterRows,

            // Main object containing GCP Service selection metadata
            items: [
                { id: 1, title: 'Cloud Monitoring metrics', done: false, display: dynamicValues['Cloud Monitoring metrics'] },
                { id: 2, title: 'Cloud Audit logs', done: true, display: dynamicValues['Cloud Audit logs'] },
                { id: 3, title: 'VPC flow logs', done: false, display: dynamicValues['VPC flow logs'] },
                { id: 4, title: 'G Suite Admin activity', done: false, display: dynamicValues['G Suite Admin activity'] },
                { id: 5, title: 'G Suite Logins', done: false, display: dynamicValues['G Suite Logins'] },
                { id: 6, title: 'Cloud Asset Inventory snapshots', done: false, display: dynamicValues['Cloud Asset Inventory Snapshots'] },
                { id: 7, title: 'Custom logging filter(s)', done: false, display: dynamicValues['Custom logging filter(s)']},
                { id: 8, title: 'Organization logging filter(s)', done: false, display: dynamicValues['Organization logging filter(s)']},
            ],
            // The values object contains a list of all selected CloudWatch Events
            values: [],

            // loggingFilterGroups holds the ACTUAL user input to the form rows. For some reason the user input
            // is not visible in the FormRows object and most be stored externally. Format: ["foo", "bar"]
            loggingFilterGroups: [],
            orgLoggingFilterGroups: [],

            // Splunk HEC Token with indexer ack enabled
            TokenValue: '',
            // Splunk HEC Token with no indexer ack enabled
            NoAckTokenValue: '',

            // Toggles display of the the HEC token entry fields
            TokenDisplay: '',
            NoAckTokenDisplay: '',

            zone: '',
            region: '',
            project_id: '',
            org_id: '',

            NoAckTokenValue_not_provided: false,
            EndpointValue_not_provided: false,
            zone_not_provided: false,
            region_not_provided: false,
            project_id_not_provided: false,
            org_id_not_provided: false,

            // Boolean for user selection of automatic HEC token creation
            autoHEC: false,

            // Splunk endpoint related fields
            SplunkManagementEndpoint: '',
            SplunkCredentialsDisplay: 'none',

            EndpointField: dynamicValues["EndpointField"],
            EndpointValue: dynamicValues["EndpointValue"],

            /*
                A list of objects describing AWS services/CloudWatch Events
                Format: {
                            name: "Name of AWS services/CloudWatch Event",
                            type: "Either 'event' or 'service' depending on if it is an CloudWatch Event name or an AWS Service"
                        }
            */
            metrics_full_list: [{"type": "service", "name": "apigee"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/compaction_pendingtasks"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_bytes_committed"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_bytes_init"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_bytes_max"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_bytes_used"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_committed"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_init"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_max"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_used"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/process_cpu_seconds_total"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/process_max_fds"}, {"type": "event", "name": "apigee.googleapis.com/cassandra/process_open_fds"}, {"type": "event", "name": "apigee.googleapis.com/policy/latencies"}, {"type": "event", "name": "apigee.googleapis.com/proxy/latencies"}, {"type": "event", "name": "apigee.googleapis.com/proxy/request_count"}, {"type": "event", "name": "apigee.googleapis.com/proxy/response_count"}, {"type": "event", "name": "apigee.googleapis.com/server/fault_count"}, {"type": "event", "name": "apigee.googleapis.com/server/latencies"}, {"type": "event", "name": "apigee.googleapis.com/server/nio"}, {"type": "event", "name": "apigee.googleapis.com/server/num_threads"}, {"type": "event", "name": "apigee.googleapis.com/server/request_count"}, {"type": "event", "name": "apigee.googleapis.com/server/response_count"}, {"type": "event", "name": "apigee.googleapis.com/target/latencies"}, {"type": "event", "name": "apigee.googleapis.com/target/request_count"}, {"type": "event", "name": "apigee.googleapis.com/target/response_count"}, {"type": "event", "name": "apigee.googleapis.com/udca/disk/used_bytes"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/local_file_count"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/local_file_latest_ts"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/local_file_oldest_ts"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/pruned_file_count"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/retry_cache_size"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/total_latencies"}, {"type": "event", "name": "apigee.googleapis.com/udca/server/upload_latencies"}, {"type": "event", "name": "apigee.googleapis.com/udca/upstream/http_error_count"}, {"type": "event", "name": "apigee.googleapis.com/udca/upstream/http_latencies"}, {"type": "event", "name": "apigee.googleapis.com/udca/upstream/uploaded_file_count"}, {"type": "event", "name": "apigee.googleapis.com/udca/upstream/uploaded_file_sizes"}, {"type": "event", "name": "apigee.googleapis.com/upstream/latencies"}, {"type": "event", "name": "apigee.googleapis.com/upstream/request_count"}, {"type": "event", "name": "apigee.googleapis.com/upstream/response_count"}, {"type": "service", "name": "appengine"}, {"type": "event", "name": "appengine.googleapis.com/flex/autoscaler/connections/current"}, {"type": "event", "name": "appengine.googleapis.com/flex/autoscaler/current_utilization"}, {"type": "event", "name": "appengine.googleapis.com/flex/autoscaler/server/request_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/connections/current"}, {"type": "event", "name": "appengine.googleapis.com/flex/cpu/reserved_cores"}, {"type": "event", "name": "appengine.googleapis.com/flex/cpu/utilization"}, {"type": "event", "name": "appengine.googleapis.com/flex/disk/read_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/disk/write_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/instance/connections/current"}, {"type": "event", "name": "appengine.googleapis.com/flex/instance/cpu/utilization"}, {"type": "event", "name": "appengine.googleapis.com/flex/instance/network/received_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/instance/network/sent_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/instance/ws/avg_duration"}, {"type": "event", "name": "appengine.googleapis.com/flex/network/received_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/flex/network/sent_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/http/server/dos_intercept_count"}, {"type": "event", "name": "appengine.googleapis.com/http/server/quota_denial_count"}, {"type": "event", "name": "appengine.googleapis.com/http/server/response_count"}, {"type": "event", "name": "appengine.googleapis.com/http/server/response_latencies"}, {"type": "event", "name": "appengine.googleapis.com/http/server/response_style_count"}, {"type": "event", "name": "appengine.googleapis.com/memcache/centi_mcu_count"}, {"type": "event", "name": "appengine.googleapis.com/memcache/hit_ratio"}, {"type": "event", "name": "appengine.googleapis.com/memcache/operation_count"}, {"type": "event", "name": "appengine.googleapis.com/memcache/received_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/memcache/sent_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/memcache/used_cache_size"}, {"type": "event", "name": "appengine.googleapis.com/system/billed_instance_estimate_count"}, {"type": "event", "name": "appengine.googleapis.com/system/cpu/usage"}, {"type": "event", "name": "appengine.googleapis.com/system/instance_count"}, {"type": "event", "name": "appengine.googleapis.com/system/memory/usage"}, {"type": "event", "name": "appengine.googleapis.com/system/network/received_bytes_count"}, {"type": "event", "name": "appengine.googleapis.com/system/network/sent_bytes_count"}, {"type": "service", "name": "autoscaler"}, {"type": "event", "name": "autoscaler.googleapis.com/current_utilization"}, {"type": "service", "name": "bigquery"}, {"type": "event", "name": "bigquery.googleapis.com/query/count"}, {"type": "event", "name": "bigquery.googleapis.com/query/execution_times"}, {"type": "event", "name": "bigquery.googleapis.com/query/scanned_bytes"}, {"type": "event", "name": "bigquery.googleapis.com/query/scanned_bytes_billed"}, {"type": "event", "name": "bigquery.googleapis.com/query/statement_scanned_bytes"}, {"type": "event", "name": "bigquery.googleapis.com/query/statement_scanned_bytes_billed"}, {"type": "event", "name": "bigquery.googleapis.com/slots/allocated"}, {"type": "event", "name": "bigquery.googleapis.com/slots/allocated_for_project"}, {"type": "event", "name": "bigquery.googleapis.com/slots/allocated_for_project_and_job_type"}, {"type": "event", "name": "bigquery.googleapis.com/slots/allocated_for_reservation"}, {"type": "event", "name": "bigquery.googleapis.com/slots/total_allocated_for_reservation"}, {"type": "event", "name": "bigquery.googleapis.com/slots/total_available"}, {"type": "event", "name": "bigquery.googleapis.com/storage/stored_bytes"}, {"type": "event", "name": "bigquery.googleapis.com/storage/table_count"}, {"type": "event", "name": "bigquery.googleapis.com/storage/uploaded_bytes"}, {"type": "event", "name": "bigquery.googleapis.com/storage/uploaded_bytes_billed"}, {"type": "event", "name": "bigquery.googleapis.com/storage/uploaded_row_count"}, {"type": "service", "name": "bigquerybiengine"}, {"type": "event", "name": "bigquerybiengine.googleapis.com/model/request_count"}, {"type": "event", "name": "bigquerybiengine.googleapis.com/model/request_latencies"}, {"type": "event", "name": "bigquerybiengine.googleapis.com/reservation/total_bytes"}, {"type": "event", "name": "bigquerybiengine.googleapis.com/reservation/used_bytes"}, {"type": "service", "name": "bigtable"}, {"type": "event", "name": "bigtable.googleapis.com/cluster/cpu_load_hottest_node"}, {"type": "event", "name": "bigtable.googleapis.com/cluster/disk_load"}, {"type": "event", "name": "bigtable.googleapis.com/cluster/node_count"}, {"type": "event", "name": "bigtable.googleapis.com/cluster/storage_utilization"}, {"type": "event", "name": "bigtable.googleapis.com/disk/bytes_used"}, {"type": "event", "name": "bigtable.googleapis.com/disk/storage_capacity"}, {"type": "event", "name": "bigtable.googleapis.com/replication/latency"}, {"type": "event", "name": "bigtable.googleapis.com/replication/max_delay"}, {"type": "event", "name": "bigtable.googleapis.com/server/error_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/latencies"}, {"type": "event", "name": "bigtable.googleapis.com/server/modified_rows_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/multi_cluster_failovers_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/received_bytes_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/request_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/returned_rows_count"}, {"type": "event", "name": "bigtable.googleapis.com/server/sent_bytes_count"}, {"type": "event", "name": "bigtable.googleapis.com/table/bytes_used"}, {"type": "service", "name": "cloudfunctions"}, {"type": "event", "name": "cloudfunctions.googleapis.com/function/execution_count"}, {"type": "event", "name": "cloudfunctions.googleapis.com/function/execution_times"}, {"type": "event", "name": "cloudfunctions.googleapis.com/function/network_egress"}, {"type": "event", "name": "cloudfunctions.googleapis.com/function/user_memory_bytes"}, {"type": "service", "name": "cloudiot"}, {"type": "event", "name": "cloudiot.googleapis.com/device/billing_bytes_count"}, {"type": "event", "name": "cloudiot.googleapis.com/device/error_count"}, {"type": "event", "name": "cloudiot.googleapis.com/device/operation_count"}, {"type": "event", "name": "cloudiot.googleapis.com/device/received_bytes_count"}, {"type": "event", "name": "cloudiot.googleapis.com/device/sent_bytes_count"}, {"type": "service", "name": "cloudsql"}, {"type": "event", "name": "cloudsql.googleapis.com/database/available_for_failover"}, {"type": "event", "name": "cloudsql.googleapis.com/database/cpu/reserved_cores"}, {"type": "event", "name": "cloudsql.googleapis.com/database/cpu/usage_time"}, {"type": "event", "name": "cloudsql.googleapis.com/database/cpu/utilization"}, {"type": "event", "name": "cloudsql.googleapis.com/database/disk/bytes_used"}, {"type": "event", "name": "cloudsql.googleapis.com/database/disk/quota"}, {"type": "event", "name": "cloudsql.googleapis.com/database/disk/read_ops_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/disk/utilization"}, {"type": "event", "name": "cloudsql.googleapis.com/database/disk/write_ops_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/instance_state"}, {"type": "event", "name": "cloudsql.googleapis.com/database/memory/quota"}, {"type": "event", "name": "cloudsql.googleapis.com/database/memory/usage"}, {"type": "event", "name": "cloudsql.googleapis.com/database/memory/utilization"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_dirty"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_free"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_total"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_data_fsyncs"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_os_log_fsyncs"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_pages_read"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/innodb_pages_written"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/queries"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/questions"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/received_bytes_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/available_for_failover"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/seconds_behind_master"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/slave_io_running"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/slave_io_running_state"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/slave_sql_running"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/replication/slave_sql_running_state"}, {"type": "event", "name": "cloudsql.googleapis.com/database/mysql/sent_bytes_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/network/connections"}, {"type": "event", "name": "cloudsql.googleapis.com/database/network/received_bytes_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/network/sent_bytes_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/postgresql/num_backends"}, {"type": "event", "name": "cloudsql.googleapis.com/database/postgresql/replication/replica_byte_lag"}, {"type": "event", "name": "cloudsql.googleapis.com/database/postgresql/transaction_count"}, {"type": "event", "name": "cloudsql.googleapis.com/database/replication/replica_lag"}, {"type": "event", "name": "cloudsql.googleapis.com/database/state"}, {"type": "event", "name": "cloudsql.googleapis.com/database/up"}, {"type": "event", "name": "cloudsql.googleapis.com/database/uptime"}, {"type": "service", "name": "cloudtasks"}, {"type": "event", "name": "cloudtasks.googleapis.com/queue/depth"}, {"type": "event", "name": "cloudtasks.googleapis.com/queue/task_attempt_count"}, {"type": "event", "name": "cloudtasks.googleapis.com/queue/task_attempt_delays"}, {"type": "service", "name": "cloudtrace"}, {"type": "event", "name": "cloudtrace.googleapis.com/billing/monthly_spans_ingested"}, {"type": "event", "name": "cloudtrace.googleapis.com/billing/spans_ingested"}, {"type": "service", "name": "composer"}, {"type": "event", "name": "composer.googleapis.com/environment/api/request_latencies"}, {"type": "event", "name": "composer.googleapis.com/environment/dag_processing/parse_error_count"}, {"type": "event", "name": "composer.googleapis.com/environment/dag_processing/processes"}, {"type": "event", "name": "composer.googleapis.com/environment/dag_processing/processor_timeout_count"}, {"type": "event", "name": "composer.googleapis.com/environment/dag_processing/total_parse_time"}, {"type": "event", "name": "composer.googleapis.com/environment/dagbag_size"}, {"type": "event", "name": "composer.googleapis.com/environment/database_health"}, {"type": "event", "name": "composer.googleapis.com/environment/executor/open_slots"}, {"type": "event", "name": "composer.googleapis.com/environment/executor/running_tasks"}, {"type": "event", "name": "composer.googleapis.com/environment/finished_task_instance_count"}, {"type": "event", "name": "composer.googleapis.com/environment/healthy"}, {"type": "event", "name": "composer.googleapis.com/environment/num_celery_workers"}, {"type": "event", "name": "composer.googleapis.com/environment/scheduler_heartbeat_count"}, {"type": "event", "name": "composer.googleapis.com/environment/task_queue_length"}, {"type": "event", "name": "composer.googleapis.com/environment/worker/pod_eviction_count"}, {"type": "event", "name": "composer.googleapis.com/environment/zombie_task_killed_count"}, {"type": "event", "name": "composer.googleapis.com/workflow/run_count"}, {"type": "event", "name": "composer.googleapis.com/workflow/run_duration"}, {"type": "event", "name": "composer.googleapis.com/workflow/task/run_count"}, {"type": "event", "name": "composer.googleapis.com/workflow/task/run_duration"}, {"type": "service", "name": "compute"}, {"type": "event", "name": "compute.googleapis.com/firewall/dropped_packets_count"}, {"type": "event", "name": "compute.googleapis.com/guest/cpu/runnable_task_count"}, {"type": "event", "name": "compute.googleapis.com/guest/cpu/usage_time"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/bytes_used"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/io_time"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/merged_operation_count"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/operation_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/operation_count"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/operation_time"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/queue_length"}, {"type": "event", "name": "compute.googleapis.com/guest/disk/weighted_io_time"}, {"type": "event", "name": "compute.googleapis.com/guest/memory/anonymous_used"}, {"type": "event", "name": "compute.googleapis.com/guest/memory/bytes_used"}, {"type": "event", "name": "compute.googleapis.com/guest/memory/dirty_used"}, {"type": "event", "name": "compute.googleapis.com/guest/memory/page_cache_used"}, {"type": "event", "name": "compute.googleapis.com/guest/memory/unevictable_used"}, {"type": "event", "name": "compute.googleapis.com/guest/system/problem_count"}, {"type": "event", "name": "compute.googleapis.com/guest/system/problem_state"}, {"type": "event", "name": "compute.googleapis.com/guest/system/uptime"}, {"type": "event", "name": "compute.googleapis.com/instance/cpu/reserved_cores"}, {"type": "event", "name": "compute.googleapis.com/instance/cpu/scheduler_wait_time"}, {"type": "event", "name": "compute.googleapis.com/instance/cpu/usage_time"}, {"type": "event", "name": "compute.googleapis.com/instance/cpu/utilization"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/max_read_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/max_read_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/max_write_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/max_write_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/read_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/read_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/throttled_read_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/throttled_read_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/throttled_write_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/throttled_write_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/write_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/disk/write_ops_count"}, {"type": "event", "name": "compute.googleapis.com/instance/integrity/early_boot_validation_status"}, {"type": "event", "name": "compute.googleapis.com/instance/integrity/late_boot_validation_status"}, {"type": "event", "name": "compute.googleapis.com/instance/memory/balloon/ram_size"}, {"type": "event", "name": "compute.googleapis.com/instance/memory/balloon/ram_used"}, {"type": "event", "name": "compute.googleapis.com/instance/memory/balloon/swap_in_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/memory/balloon/swap_out_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/network/received_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/network/received_packets_count"}, {"type": "event", "name": "compute.googleapis.com/instance/network/sent_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/instance/network/sent_packets_count"}, {"type": "event", "name": "compute.googleapis.com/instance/uptime"}, {"type": "event", "name": "compute.googleapis.com/instance_group/size"}, {"type": "event", "name": "compute.googleapis.com/mirroring/dropped_packets_count"}, {"type": "event", "name": "compute.googleapis.com/mirroring/mirrored_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/mirroring/mirrored_packets_count"}, {"type": "event", "name": "compute.googleapis.com/nat/allocated_ports"}, {"type": "event", "name": "compute.googleapis.com/nat/closed_connections_count"}, {"type": "event", "name": "compute.googleapis.com/nat/dropped_received_packets_count"}, {"type": "event", "name": "compute.googleapis.com/nat/dropped_sent_packets_count"}, {"type": "event", "name": "compute.googleapis.com/nat/new_connections_count"}, {"type": "event", "name": "compute.googleapis.com/nat/open_connections"}, {"type": "event", "name": "compute.googleapis.com/nat/port_usage"}, {"type": "event", "name": "compute.googleapis.com/nat/received_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/nat/received_packets_count"}, {"type": "event", "name": "compute.googleapis.com/nat/sent_bytes_count"}, {"type": "event", "name": "compute.googleapis.com/nat/sent_packets_count"}, {"type": "service", "name": "container"}, {"type": "event", "name": "container.googleapis.com/container/accelerator/memory_total"}, {"type": "event", "name": "container.googleapis.com/container/accelerator/memory_used"}, {"type": "event", "name": "container.googleapis.com/container/accelerator/request"}, {"type": "event", "name": "container.googleapis.com/container/cpu/reserved_cores"}, {"type": "event", "name": "container.googleapis.com/container/cpu/usage_time"}, {"type": "event", "name": "container.googleapis.com/container/cpu/utilization"}, {"type": "event", "name": "container.googleapis.com/container/disk/bytes_total"}, {"type": "event", "name": "container.googleapis.com/container/disk/bytes_used"}, {"type": "event", "name": "container.googleapis.com/container/disk/inodes_free"}, {"type": "event", "name": "container.googleapis.com/container/disk/inodes_total"}, {"type": "event", "name": "container.googleapis.com/container/memory/bytes_total"}, {"type": "event", "name": "container.googleapis.com/container/memory/bytes_used"}, {"type": "event", "name": "container.googleapis.com/container/memory/page_fault_count"}, {"type": "event", "name": "container.googleapis.com/container/pid_limit"}, {"type": "event", "name": "container.googleapis.com/container/pid_used"}, {"type": "event", "name": "container.googleapis.com/container/uptime"}, {"type": "service", "name": "custom"}, {"type": "event", "name": "custom.googleapis.com/dataflow/inbound-pubsub-messages"}, {"type": "event", "name": "custom.googleapis.com/dataflow/outbound-failed-events"}, {"type": "event", "name": "custom.googleapis.com/dataflow/outbound-successful-events"}, {"type": "event", "name": "custom.googleapis.com/dataflow/splunk-event-conversion-successes"}, {"type": "event", "name": "custom.googleapis.com/dataflow/total-failed-messages"}, {"type": "service", "name": "dataflow"}, {"type": "event", "name": "dataflow.googleapis.com/job/current_num_vcpus"}, {"type": "event", "name": "dataflow.googleapis.com/job/current_shuffle_slots"}, {"type": "event", "name": "dataflow.googleapis.com/job/data_watermark_age"}, {"type": "event", "name": "dataflow.googleapis.com/job/elapsed_time"}, {"type": "event", "name": "dataflow.googleapis.com/job/element_count"}, {"type": "event", "name": "dataflow.googleapis.com/job/elements_produced_count"}, {"type": "event", "name": "dataflow.googleapis.com/job/estimated_byte_count"}, {"type": "event", "name": "dataflow.googleapis.com/job/estimated_bytes_produced_count"}, {"type": "event", "name": "dataflow.googleapis.com/job/is_failed"}, {"type": "event", "name": "dataflow.googleapis.com/job/per_stage_data_watermark_age"}, {"type": "event", "name": "dataflow.googleapis.com/job/per_stage_system_lag"}, {"type": "event", "name": "dataflow.googleapis.com/job/status"}, {"type": "event", "name": "dataflow.googleapis.com/job/system_lag"}, {"type": "event", "name": "dataflow.googleapis.com/job/total_memory_usage_time"}, {"type": "event", "name": "dataflow.googleapis.com/job/total_pd_usage_time"}, {"type": "event", "name": "dataflow.googleapis.com/job/total_shuffle_data_processed"}, {"type": "event", "name": "dataflow.googleapis.com/job/total_streaming_data_processed"}, {"type": "event", "name": "dataflow.googleapis.com/job/total_vcpu_time"}, {"type": "event", "name": "dataflow.googleapis.com/job/user_counter"}, {"type": "service", "name": "dataproc"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/hdfs/storage_capacity"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/hdfs/storage_utilization"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/hdfs/unhealthy_blocks"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/job/completion_time"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/job/duration"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/job/failed_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/job/running_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/job/submitted_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/operation/completion_time"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/operation/duration"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/operation/failed_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/operation/running_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/operation/submitted_count"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/allocated_memory_percentage"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/apps"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/containers"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/memory_size"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/nodemanagers"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/pending_memory_size"}, {"type": "event", "name": "dataproc.googleapis.com/cluster/yarn/virtual_cores"}, {"type": "service", "name": "datastore"}, {"type": "event", "name": "datastore.googleapis.com/entity/read_sizes"}, {"type": "event", "name": "datastore.googleapis.com/entity/write_sizes"}, {"type": "event", "name": "datastore.googleapis.com/index/write_count"}, {"type": "service", "name": "dlp"}, {"type": "event", "name": "dlp.googleapis.com/content_bytes_transformed_count"}, {"type": "event", "name": "dlp.googleapis.com/finding_count"}, {"type": "event", "name": "dlp.googleapis.com/job_result_count"}, {"type": "event", "name": "dlp.googleapis.com/job_trigger_run_count"}, {"type": "event", "name": "dlp.googleapis.com/storage_bytes_inspected_count"}, {"type": "event", "name": "dlp.googleapis.com/storage_bytes_transformed_count"}, {"type": "service", "name": "dns"}, {"type": "service", "name": "file"}, {"type": "event", "name": "file.googleapis.com/nfs/server/free_bytes_percent"}, {"type": "event", "name": "file.googleapis.com/nfs/server/procedure_call_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/read_bytes_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/read_milliseconds_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/read_ops_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/used_bytes"}, {"type": "event", "name": "file.googleapis.com/nfs/server/used_bytes_percent"}, {"type": "event", "name": "file.googleapis.com/nfs/server/write_bytes_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/write_milliseconds_count"}, {"type": "event", "name": "file.googleapis.com/nfs/server/write_ops_count"}, {"type": "service", "name": "firebaseauth"}, {"type": "service", "name": "firebasedatabase"}, {"type": "event", "name": "firebasedatabase.googleapis.com/io/persisted_bytes_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/io/sent_responses_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/io/utilization"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/active_connections"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/api_hits_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/broadcast_load"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/disabled_for_overages"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/https_requests_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/monthly_sent"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/monthly_sent_limit"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/sent_bytes_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/sent_payload_and_protocol_bytes_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/network/sent_payload_bytes_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/rules/evaluation_count"}, {"type": "event", "name": "firebasedatabase.googleapis.com/storage/disabled_for_overages"}, {"type": "event", "name": "firebasedatabase.googleapis.com/storage/limit"}, {"type": "event", "name": "firebasedatabase.googleapis.com/storage/total_bytes"}, {"type": "service", "name": "firebasehosting"}, {"type": "event", "name": "firebasehosting.googleapis.com/network/monthly_sent_limit"}, {"type": "event", "name": "firebasehosting.googleapis.com/network/sent_bytes_count"}, {"type": "event", "name": "firebasehosting.googleapis.com/storage/limit"}, {"type": "event", "name": "firebasehosting.googleapis.com/storage/total_bytes"}, {"type": "service", "name": "firebasestorage"}, {"type": "service", "name": "firestore"}, {"type": "event", "name": "firestore.googleapis.com/document/delete_count"}, {"type": "event", "name": "firestore.googleapis.com/document/read_count"}, {"type": "event", "name": "firestore.googleapis.com/document/write_count"}, {"type": "event", "name": "firestore.googleapis.com/network/active_connections"}, {"type": "event", "name": "firestore.googleapis.com/network/snapshot_listeners"}, {"type": "event", "name": "firestore.googleapis.com/rules/evaluation_count"}, {"type": "service", "name": "firewallinsights"}, {"type": "event", "name": "firewallinsights.googleapis.com/subnet/firewall_last_used_timestamp"}, {"type": "event", "name": "firewallinsights.googleapis.com/vm/firewall_hit_count"}, {"type": "event", "name": "firewallinsights.googleapis.com/vm/firewall_last_used_timestamp"}, {"type": "service", "name": "iam"}, {"type": "service", "name": "interconnect"}, {"type": "event", "name": "interconnect.googleapis.com/network/attachment/received_bytes_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/attachment/received_packets_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/attachment/sent_bytes_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/attachment/sent_packets_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/capacity"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/dropped_packets_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/link/operational"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/link/rx_power"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/link/tx_power"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/operational"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/receive_errors_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/received_bytes_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/received_unicast_packets_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/send_errors_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/sent_bytes_count"}, {"type": "event", "name": "interconnect.googleapis.com/network/interconnect/sent_unicast_packets_count"}, {"type": "service", "name": "loadbalancing"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/backend_request_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/backend_request_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/backend_response_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/frontend_tcp_rtt"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/internal/backend_latencies"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/internal/request_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/internal/request_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/internal/response_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/internal/total_latencies"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/request_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/request_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/response_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/https/total_latencies"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/external/egress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/external/egress_packets_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/external/ingress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/external/ingress_packets_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/external/rtt_latencies"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/internal/egress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/internal/egress_packets_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/internal/ingress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/internal/ingress_packets_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/l3/internal/rtt_latencies"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/closed_connections"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/egress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/frontend_tcp_rtt"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/ingress_bytes_count"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/new_connections"}, {"type": "event", "name": "loadbalancing.googleapis.com/tcp_ssl_proxy/open_connections"}, {"type": "service", "name": "logging"}, {"type": "event", "name": "logging.googleapis.com/billing/monthly_bytes_ingested"}, {"type": "event", "name": "logging.googleapis.com/byte_count"}, {"type": "event", "name": "logging.googleapis.com/dropped_log_entry_count"}, {"type": "event", "name": "logging.googleapis.com/excluded_byte_count"}, {"type": "event", "name": "logging.googleapis.com/excluded_log_entry_count"}, {"type": "event", "name": "logging.googleapis.com/exports/byte_count"}, {"type": "event", "name": "logging.googleapis.com/exports/error_count"}, {"type": "event", "name": "logging.googleapis.com/exports/log_entry_count"}, {"type": "event", "name": "logging.googleapis.com/log_entry_count"}, {"type": "event", "name": "logging.googleapis.com/logs_based_metrics_error_count"}, {"type": "event", "name": "logging.googleapis.com/metric_throttled"}, {"type": "event", "name": "logging.googleapis.com/time_series_count"}, {"type": "service", "name": "managedidentities"}, {"type": "event", "name": "managedidentities.googleapis.com/microsoft_ad/domain/trust/state"}, {"type": "service", "name": "memcache"}, {"type": "event", "name": "memcache.googleapis.com/node/cache_memory"}, {"type": "event", "name": "memcache.googleapis.com/node/cpu/usage_time"}, {"type": "event", "name": "memcache.googleapis.com/node/eviction_count"}, {"type": "event", "name": "memcache.googleapis.com/node/hit_ratio"}, {"type": "event", "name": "memcache.googleapis.com/node/items"}, {"type": "event", "name": "memcache.googleapis.com/node/operation_count"}, {"type": "event", "name": "memcache.googleapis.com/node/received_bytes_count"}, {"type": "event", "name": "memcache.googleapis.com/node/sent_bytes_count"}, {"type": "event", "name": "memcache.googleapis.com/node/uptime"}, {"type": "service", "name": "ml"}, {"type": "event", "name": "ml.googleapis.com/prediction/latencies"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/accelerator/duty_cycle"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/accelerator/memory/bytes_used"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/cpu/utilization"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/memory/bytes_used"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/network/bytes_received"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/network/bytes_sent"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/replicas"}, {"type": "event", "name": "ml.googleapis.com/prediction/online/target_replicas"}, {"type": "event", "name": "ml.googleapis.com/prediction/prediction_count"}, {"type": "event", "name": "ml.googleapis.com/prediction/response_count"}, {"type": "event", "name": "ml.googleapis.com/training/accelerator/memory/utilization"}, {"type": "event", "name": "ml.googleapis.com/training/accelerator/utilization"}, {"type": "event", "name": "ml.googleapis.com/training/cpu/utilization"}, {"type": "event", "name": "ml.googleapis.com/training/memory/utilization"}, {"type": "event", "name": "ml.googleapis.com/training/network/received_bytes_count"}, {"type": "event", "name": "ml.googleapis.com/training/network/sent_bytes_count"}, {"type": "service", "name": "monitoring"}, {"type": "event", "name": "monitoring.googleapis.com/stats/num_time_series"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/check_passed"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/content_mismatch"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/error_code"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/http_status"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/request_latency"}, {"type": "event", "name": "monitoring.googleapis.com/uptime_check/time_until_ssl_cert_expires"}, {"type": "service", "name": "netapp"}, {"type": "event", "name": "netapp.com/cloudvolume/inode_usage"}, {"type": "event", "name": "netapp.com/cloudvolume/operation_count"}, {"type": "event", "name": "netapp.com/cloudvolume/read_bytes_count"}, {"type": "event", "name": "netapp.com/cloudvolume/request_latencies"}, {"type": "event", "name": "netapp.com/cloudvolume/volume_size"}, {"type": "event", "name": "netapp.com/cloudvolume/volume_usage"}, {"type": "event", "name": "netapp.com/cloudvolume/write_bytes_count"}, {"type": "service", "name": "network"}, {"type": "event", "name": "network.googleapis.com/loadbalancer/max_utilization"}, {"type": "event", "name": "network.googleapis.com/loadbalancer/utilization"}, {"type": "service", "name": "networking"}, {"type": "event", "name": "networking.googleapis.com/vm_flow/egress_bytes_count"}, {"type": "event", "name": "networking.googleapis.com/vm_flow/ingress_bytes_count"}, {"type": "event", "name": "networking.googleapis.com/vm_flow/rtt"}, {"type": "service", "name": "networksecurity"}, {"type": "event", "name": "networksecurity.googleapis.com/https/request_count"}, {"type": "service", "name": "pubsub"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/backlog_bytes_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/config_updates_count"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/num_messages"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/num_messages_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/oldest_message_age"}, {"type": "event", "name": "pubsub.googleapis.com/snapshot/oldest_message_age_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/ack_message_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/backlog_bytes"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/byte_cost"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/config_updates_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/dead_letter_message_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/mod_ack_deadline_message_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/mod_ack_deadline_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/mod_ack_deadline_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/num_outstanding_messages"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/num_retained_acked_messages"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/num_retained_acked_messages_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/num_unacked_messages_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/num_undelivered_messages"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/oldest_retained_acked_message_age"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/oldest_retained_acked_message_age_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/oldest_unacked_message_age"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/oldest_unacked_message_age_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/pull_ack_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/pull_ack_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/pull_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/pull_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/push_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/push_request_latencies"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/retained_acked_bytes"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/retained_acked_bytes_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/seek_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/sent_message_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_ack_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_ack_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_mod_ack_deadline_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_mod_ack_deadline_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/streaming_pull_response_count"}, {"type": "event", "name": "pubsub.googleapis.com/subscription/unacked_bytes_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/byte_cost"}, {"type": "event", "name": "pubsub.googleapis.com/topic/config_updates_count"}, {"type": "event", "name": "pubsub.googleapis.com/topic/message_sizes"}, {"type": "event", "name": "pubsub.googleapis.com/topic/num_retained_acked_messages_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/num_unacked_messages_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/oldest_retained_acked_message_age_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/oldest_unacked_message_age_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/retained_acked_bytes_by_region"}, {"type": "event", "name": "pubsub.googleapis.com/topic/send_message_operation_count"}, {"type": "event", "name": "pubsub.googleapis.com/topic/send_request_count"}, {"type": "event", "name": "pubsub.googleapis.com/topic/unacked_bytes_by_region"}, {"type": "service", "name": "recaptchaenterprise"}, {"type": "service", "name": "recommendationengine"}, {"type": "service", "name": "redis"}, {"type": "event", "name": "redis.googleapis.com/clients/connected"}, {"type": "event", "name": "redis.googleapis.com/commands/calls"}, {"type": "event", "name": "redis.googleapis.com/commands/total_time"}, {"type": "event", "name": "redis.googleapis.com/commands/usec_per_call"}, {"type": "event", "name": "redis.googleapis.com/keyspace/avg_ttl"}, {"type": "event", "name": "redis.googleapis.com/keyspace/keys"}, {"type": "event", "name": "redis.googleapis.com/keyspace/keys_with_expiration"}, {"type": "event", "name": "redis.googleapis.com/persistence/rdb/bgsave_in_progress"}, {"type": "event", "name": "redis.googleapis.com/replication/master/slaves/lag"}, {"type": "event", "name": "redis.googleapis.com/replication/master/slaves/offset"}, {"type": "event", "name": "redis.googleapis.com/replication/master_repl_offset"}, {"type": "event", "name": "redis.googleapis.com/replication/offset_diff"}, {"type": "event", "name": "redis.googleapis.com/replication/role"}, {"type": "event", "name": "redis.googleapis.com/server/uptime"}, {"type": "event", "name": "redis.googleapis.com/stats/cache_hit_ratio"}, {"type": "event", "name": "redis.googleapis.com/stats/connections/total"}, {"type": "event", "name": "redis.googleapis.com/stats/cpu_utilization"}, {"type": "event", "name": "redis.googleapis.com/stats/evicted_keys"}, {"type": "event", "name": "redis.googleapis.com/stats/expired_keys"}, {"type": "event", "name": "redis.googleapis.com/stats/keyspace_hits"}, {"type": "event", "name": "redis.googleapis.com/stats/keyspace_misses"}, {"type": "event", "name": "redis.googleapis.com/stats/memory/maxmemory"}, {"type": "event", "name": "redis.googleapis.com/stats/memory/system_memory_overload_duration"}, {"type": "event", "name": "redis.googleapis.com/stats/memory/system_memory_usage_ratio"}, {"type": "event", "name": "redis.googleapis.com/stats/memory/usage"}, {"type": "event", "name": "redis.googleapis.com/stats/memory/usage_ratio"}, {"type": "event", "name": "redis.googleapis.com/stats/network_traffic"}, {"type": "event", "name": "redis.googleapis.com/stats/pubsub/channels"}, {"type": "event", "name": "redis.googleapis.com/stats/pubsub/patterns"}, {"type": "event", "name": "redis.googleapis.com/stats/reject_connections_count"}, {"type": "service", "name": "remotebuildexecution"}, {"type": "event", "name": "remotebuildexecution.googleapis.com/action/execution/active"}, {"type": "event", "name": "remotebuildexecution.googleapis.com/action/execution/count"}, {"type": "event", "name": "remotebuildexecution.googleapis.com/action/execution/durations"}, {"type": "event", "name": "remotebuildexecution.googleapis.com/workerpool/size"}, {"type": "event", "name": "remotebuildexecution.googleapis.com/workerpool/slots"}, {"type": "service", "name": "router"}, {"type": "event", "name": "router.googleapis.com/bfd/control/receive_intervals"}, {"type": "event", "name": "router.googleapis.com/bfd/control/received_packets_count"}, {"type": "event", "name": "router.googleapis.com/bfd/control/rejected_packets_count"}, {"type": "event", "name": "router.googleapis.com/bfd/control/transmit_intervals"}, {"type": "event", "name": "router.googleapis.com/bfd/control/transmitted_packets_count"}, {"type": "event", "name": "router.googleapis.com/bfd/session_up"}, {"type": "event", "name": "router.googleapis.com/bgp/received_routes_count"}, {"type": "event", "name": "router.googleapis.com/bgp/sent_routes_count"}, {"type": "event", "name": "router.googleapis.com/bgp/session_up"}, {"type": "event", "name": "router.googleapis.com/bgp_sessions_down_count"}, {"type": "event", "name": "router.googleapis.com/bgp_sessions_up_count"}, {"type": "event", "name": "router.googleapis.com/nat/allocated_ports"}, {"type": "event", "name": "router.googleapis.com/nat/closed_connections_count"}, {"type": "event", "name": "router.googleapis.com/nat/dropped_received_packets_count"}, {"type": "event", "name": "router.googleapis.com/nat/dropped_sent_packets_count"}, {"type": "event", "name": "router.googleapis.com/nat/nat_allocation_failed"}, {"type": "event", "name": "router.googleapis.com/nat/new_connections_count"}, {"type": "event", "name": "router.googleapis.com/nat/open_connections"}, {"type": "event", "name": "router.googleapis.com/nat/port_usage"}, {"type": "event", "name": "router.googleapis.com/nat/received_bytes_count"}, {"type": "event", "name": "router.googleapis.com/nat/received_packets_count"}, {"type": "event", "name": "router.googleapis.com/nat/sent_bytes_count"}, {"type": "event", "name": "router.googleapis.com/nat/sent_packets_count"}, {"type": "event", "name": "router.googleapis.com/router_up"}, {"type": "event", "name": "router.googleapis.com/sent_routes_count"}, {"type": "service", "name": "run"}, {"type": "event", "name": "run.googleapis.com/container/cpu/allocation_time"}, {"type": "event", "name": "run.googleapis.com/container/cpu/utilizations"}, {"type": "event", "name": "run.googleapis.com/container/memory/allocation_time"}, {"type": "event", "name": "run.googleapis.com/container/memory/utilizations"}, {"type": "event", "name": "run.googleapis.com/request_count"}, {"type": "event", "name": "run.googleapis.com/request_latencies"}, {"type": "service", "name": "serviceruntime"}, {"type": "event", "name": "serviceruntime.googleapis.com/api/request_latencies"}, {"type": "event", "name": "serviceruntime.googleapis.com/api/request_latencies_backend"}, {"type": "event", "name": "serviceruntime.googleapis.com/api/request_latencies_overhead"}, {"type": "event", "name": "serviceruntime.googleapis.com/api/request_sizes"}, {"type": "event", "name": "serviceruntime.googleapis.com/api/response_sizes"}, {"type": "event", "name": "serviceruntime.googleapis.com/quota/allocation/usage"}, {"type": "event", "name": "serviceruntime.googleapis.com/quota/exceeded"}, {"type": "event", "name": "serviceruntime.googleapis.com/quota/limit"}, {"type": "event", "name": "serviceruntime.googleapis.com/quota/rate/net_usage"}, {"type": "event", "name": "serviceruntime.googleapis.com/reserved/metric1"}, {"type": "service", "name": "spanner"}, {"type": "event", "name": "spanner.googleapis.com/api/received_bytes_count"}, {"type": "event", "name": "spanner.googleapis.com/api/request_count"}, {"type": "event", "name": "spanner.googleapis.com/api/request_latencies"}, {"type": "event", "name": "spanner.googleapis.com/api/sent_bytes_count"}, {"type": "event", "name": "spanner.googleapis.com/instance/backup/used_bytes"}, {"type": "event", "name": "spanner.googleapis.com/instance/cpu/smoothed_utilization"}, {"type": "event", "name": "spanner.googleapis.com/instance/cpu/utilization"}, {"type": "event", "name": "spanner.googleapis.com/instance/cpu/utilization_by_priority"}, {"type": "event", "name": "spanner.googleapis.com/instance/node_count"}, {"type": "event", "name": "spanner.googleapis.com/instance/session_count"}, {"type": "event", "name": "spanner.googleapis.com/instance/storage/limit_bytes"}, {"type": "event", "name": "spanner.googleapis.com/instance/storage/used_bytes"}, {"type": "event", "name": "spanner.googleapis.com/instance/storage/utilization"}, {"type": "event", "name": "spanner.googleapis.com/query_count"}, {"type": "service", "name": "storage"}, {"type": "event", "name": "storage.googleapis.com/authn/authentication_count"}, {"type": "event", "name": "storage.googleapis.com/authz/acl_based_object_access_count"}, {"type": "event", "name": "storage.googleapis.com/authz/acl_operations_count"}, {"type": "event", "name": "storage.googleapis.com/authz/object_specific_acl_mutation_count"}, {"type": "event", "name": "storage.googleapis.com/network/received_bytes_count"}, {"type": "event", "name": "storage.googleapis.com/network/sent_bytes_count"}, {"type": "event", "name": "storage.googleapis.com/storage/object_count"}, {"type": "event", "name": "storage.googleapis.com/storage/total_byte_seconds"}, {"type": "event", "name": "storage.googleapis.com/storage/total_bytes"}, {"type": "service", "name": "storagetransfer"}, {"type": "event", "name": "storagetransfer.googleapis.com/agent/transferred_bytes_count"}, {"type": "service", "name": "tpu"}, {"type": "event", "name": "tpu.googleapis.com/memory/usage"}, {"type": "event", "name": "tpu.googleapis.com/network/received_bytes_count"}, {"type": "event", "name": "tpu.googleapis.com/network/sent_bytes_count"}, {"type": "service", "name": "vpcaccess"}, {"type": "event", "name": "vpcaccess.googleapis.com/connector/received_packets_count"}, {"type": "event", "name": "vpcaccess.googleapis.com/connector/sent_bytes_count"}, {"type": "event", "name": "vpcaccess.googleapis.com/connector/sent_packets_count"}, {"type": "service", "name": "vpn"}, {"type": "event", "name": "vpn.googleapis.com/network/dropped_received_packets_count"}, {"type": "event", "name": "vpn.googleapis.com/network/dropped_sent_packets_count"}, {"type": "event", "name": "vpn.googleapis.com/network/received_bytes_count"}, {"type": "event", "name": "vpn.googleapis.com/network/received_packets_count"}, {"type": "event", "name": "vpn.googleapis.com/network/sent_bytes_count"}, {"type": "event", "name": "vpn.googleapis.com/network/sent_packets_count"}, {"type": "event", "name": "vpn.googleapis.com/tunnel_established"}],

            // A mapping of all CloudWatch Events to the AWS service they come from
            metrics_service_map: {"redis.googleapis.com/stats/memory/usage": "redis", "appengine.googleapis.com/http/server/response_count": "appengine", "custom.googleapis.com/dataflow/splunk-event-conversion-successes": "custom", "apigee.googleapis.com/target/request_count": "apigee", "redis.googleapis.com/commands/total_time": "redis", "router.googleapis.com/sent_routes_count": "router", "cloudsql.googleapis.com/database/mysql/replication/slave_sql_running_state": "cloudsql", "composer.googleapis.com/environment/finished_task_instance_count": "composer", "memcache.googleapis.com/node/operation_count": "memcache", "firewallinsights.googleapis.com/subnet/firewall_last_used_timestamp": "firewallinsights", "pubsub.googleapis.com/subscription/sent_message_count": "pubsub", "router.googleapis.com/bfd/control/rejected_packets_count": "router", "spanner.googleapis.com/instance/cpu/utilization_by_priority": "spanner", "container.googleapis.com/container/disk/inodes_total": "container", "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_dirty": "cloudsql", "bigtable.googleapis.com/cluster/node_count": "bigtable", "firebasedatabase.googleapis.com/storage/limit": "firebasedatabase", "appengine.googleapis.com/flex/disk/write_bytes_count": "appengine", "redis.googleapis.com/stats/pubsub/patterns": "redis", "logging.googleapis.com/metric_throttled": "logging", "spanner.googleapis.com/query_count": "spanner", "bigquery.googleapis.com/slots/allocated": "bigquery", "pubsub.googleapis.com/topic/num_retained_acked_messages_by_region": "pubsub", "network.googleapis.com/loadbalancer/max_utilization": "network", "dataflow.googleapis.com/job/total_vcpu_time": "dataflow", "compute.googleapis.com/nat/open_connections": "compute", "firebasedatabase.googleapis.com/network/sent_bytes_count": "firebasedatabase", "composer.googleapis.com/environment/zombie_task_killed_count": "composer", "cloudsql.googleapis.com/database/mysql/questions": "cloudsql", "cloudiot.googleapis.com/device/sent_bytes_count": "cloudiot", "compute.googleapis.com/instance/disk/throttled_write_ops_count": "compute", "loadbalancing.googleapis.com/l3/internal/egress_bytes_count": "loadbalancing", "file.googleapis.com/nfs/server/write_bytes_count": "file", "loadbalancing.googleapis.com/https/internal/response_bytes_count": "loadbalancing", "pubsub.googleapis.com/subscription/streaming_pull_message_operation_count": "pubsub", "serviceruntime.googleapis.com/quota/rate/net_usage": "serviceruntime", "file.googleapis.com/nfs/server/read_bytes_count": "file", "redis.googleapis.com/stats/expired_keys": "redis", "loadbalancing.googleapis.com/tcp_ssl_proxy/open_connections": "loadbalancing", "autoscaler.googleapis.com/current_utilization": "autoscaler", "compute.googleapis.com/guest/system/uptime": "compute", "loadbalancing.googleapis.com/https/internal/backend_latencies": "loadbalancing", "pubsub.googleapis.com/subscription/retained_acked_bytes_by_region": "pubsub", "dataflow.googleapis.com/job/total_pd_usage_time": "dataflow", "router.googleapis.com/bgp/received_routes_count": "router", "managedidentities.googleapis.com/microsoft_ad/domain/trust/state": "managedidentities", "compute.googleapis.com/guest/disk/merged_operation_count": "compute", "redis.googleapis.com/stats/pubsub/channels": "redis", "bigquery.googleapis.com/storage/uploaded_bytes_billed": "bigquery", "appengine.googleapis.com/flex/autoscaler/server/request_count": "appengine", "serviceruntime.googleapis.com/api/request_sizes": "serviceruntime", "networking.googleapis.com/vm_flow/egress_bytes_count": "networking", "bigtable.googleapis.com/server/returned_rows_count": "bigtable", "redis.googleapis.com/commands/calls": "redis", "ml.googleapis.com/training/network/received_bytes_count": "ml", "compute.googleapis.com/mirroring/mirrored_packets_count": "compute", "apigee.googleapis.com/udca/upstream/uploaded_file_count": "apigee", "dataflow.googleapis.com/job/total_memory_usage_time": "dataflow", "spanner.googleapis.com/api/request_latencies": "spanner", "bigtable.googleapis.com/table/bytes_used": "bigtable", "compute.googleapis.com/instance/disk/max_read_bytes_count": "compute", "composer.googleapis.com/workflow/task/run_duration": "composer", "interconnect.googleapis.com/network/attachment/sent_bytes_count": "interconnect", "cloudsql.googleapis.com/database/mysql/replication/available_for_failover": "cloudsql", "memcache.googleapis.com/node/received_bytes_count": "memcache", "bigtable.googleapis.com/disk/storage_capacity": "bigtable", "pubsub.googleapis.com/subscription/oldest_retained_acked_message_age_by_region": "pubsub", "vpn.googleapis.com/network/sent_packets_count": "vpn", "redis.googleapis.com/stats/keyspace_hits": "redis", "container.googleapis.com/container/disk/bytes_used": "container", "loadbalancing.googleapis.com/tcp_ssl_proxy/ingress_bytes_count": "loadbalancing", "logging.googleapis.com/byte_count": "logging", "storage.googleapis.com/network/received_bytes_count": "storage", "pubsub.googleapis.com/subscription/streaming_pull_response_count": "pubsub", "spanner.googleapis.com/instance/session_count": "spanner", "ml.googleapis.com/prediction/online/memory/bytes_used": "ml", "redis.googleapis.com/replication/role": "redis", "vpn.googleapis.com/network/dropped_received_packets_count": "vpn", "cloudsql.googleapis.com/database/network/sent_bytes_count": "cloudsql", "compute.googleapis.com/guest/system/problem_state": "compute", "dlp.googleapis.com/job_result_count": "dlp", "appengine.googleapis.com/flex/instance/connections/current": "appengine", "firebasedatabase.googleapis.com/network/monthly_sent_limit": "firebasedatabase", "cloudsql.googleapis.com/database/network/received_bytes_count": "cloudsql", "serviceruntime.googleapis.com/reserved/metric1": "serviceruntime", "dataproc.googleapis.com/cluster/hdfs/storage_capacity": "dataproc", "firestore.googleapis.com/rules/evaluation_count": "firestore", "cloudsql.googleapis.com/database/mysql/sent_bytes_count": "cloudsql", "composer.googleapis.com/environment/executor/running_tasks": "composer", "pubsub.googleapis.com/subscription/mod_ack_deadline_request_count": "pubsub", "redis.googleapis.com/stats/keyspace_misses": "redis", "logging.googleapis.com/time_series_count": "logging", "container.googleapis.com/container/memory/bytes_total": "container", "loadbalancing.googleapis.com/l3/internal/ingress_packets_count": "loadbalancing", "spanner.googleapis.com/api/received_bytes_count": "spanner", "dataproc.googleapis.com/cluster/job/running_count": "dataproc", "ml.googleapis.com/prediction/latencies": "ml", "interconnect.googleapis.com/network/attachment/received_bytes_count": "interconnect", "cloudsql.googleapis.com/database/cpu/utilization": "cloudsql", "dataflow.googleapis.com/job/element_count": "dataflow", "netapp.com/cloudvolume/volume_usage": "netapp", "cloudiot.googleapis.com/device/operation_count": "cloudiot", "spanner.googleapis.com/instance/storage/used_bytes": "spanner", "composer.googleapis.com/environment/dag_processing/processes": "composer", "vpcaccess.googleapis.com/connector/sent_packets_count": "vpcaccess", "cloudsql.googleapis.com/database/postgresql/transaction_count": "cloudsql", "bigtable.googleapis.com/server/request_count": "bigtable", "cloudsql.googleapis.com/database/mysql/replication/slave_sql_running": "cloudsql", "file.googleapis.com/nfs/server/free_bytes_percent": "file", "loadbalancing.googleapis.com/https/request_bytes_count": "loadbalancing", "firebasedatabase.googleapis.com/network/https_requests_count": "firebasedatabase", "cloudsql.googleapis.com/database/disk/bytes_used": "cloudsql", "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_free": "cloudsql", "appengine.googleapis.com/flex/cpu/utilization": "appengine", "interconnect.googleapis.com/network/interconnect/dropped_packets_count": "interconnect", "cloudsql.googleapis.com/database/cpu/usage_time": "cloudsql", "bigquery.googleapis.com/slots/allocated_for_project": "bigquery", "apigee.googleapis.com/server/fault_count": "apigee", "appengine.googleapis.com/flex/connections/current": "appengine", "redis.googleapis.com/keyspace/keys_with_expiration": "redis", "dataflow.googleapis.com/job/current_num_vcpus": "dataflow", "compute.googleapis.com/instance/cpu/scheduler_wait_time": "compute", "router.googleapis.com/bgp/sent_routes_count": "router", "appengine.googleapis.com/http/server/response_style_count": "appengine", "bigquery.googleapis.com/storage/stored_bytes": "bigquery", "compute.googleapis.com/instance/network/sent_bytes_count": "compute", "compute.googleapis.com/instance/memory/balloon/swap_out_bytes_count": "compute", "redis.googleapis.com/stats/memory/usage_ratio": "redis", "compute.googleapis.com/instance/network/received_bytes_count": "compute", "serviceruntime.googleapis.com/api/request_latencies": "serviceruntime", "apigee.googleapis.com/udca/upstream/uploaded_file_sizes": "apigee", "router.googleapis.com/bgp_sessions_down_count": "router", "apigee.googleapis.com/cassandra/jvm_memory_bytes_committed": "apigee", "compute.googleapis.com/guest/memory/unevictable_used": "compute", "interconnect.googleapis.com/network/interconnect/sent_unicast_packets_count": "interconnect", "container.googleapis.com/container/pid_used": "container", "spanner.googleapis.com/instance/node_count": "spanner", "pubsub.googleapis.com/subscription/backlog_bytes": "pubsub", "pubsub.googleapis.com/subscription/num_outstanding_messages": "pubsub", "pubsub.googleapis.com/snapshot/num_messages": "pubsub", "loadbalancing.googleapis.com/tcp_ssl_proxy/new_connections": "loadbalancing", "redis.googleapis.com/server/uptime": "redis", "cloudsql.googleapis.com/database/instance_state": "cloudsql", "dataproc.googleapis.com/cluster/yarn/memory_size": "dataproc", "netapp.com/cloudvolume/volume_size": "netapp", "logging.googleapis.com/excluded_log_entry_count": "logging", "appengine.googleapis.com/memcache/sent_bytes_count": "appengine", "apigee.googleapis.com/cassandra/process_max_fds": "apigee", "file.googleapis.com/nfs/server/read_milliseconds_count": "file", "cloudsql.googleapis.com/database/disk/read_ops_count": "cloudsql", "apigee.googleapis.com/cassandra/process_cpu_seconds_total": "apigee", "apigee.googleapis.com/udca/server/local_file_latest_ts": "apigee", "cloudsql.googleapis.com/database/mysql/innodb_buffer_pool_pages_total": "cloudsql", "interconnect.googleapis.com/network/interconnect/capacity": "interconnect", "apigee.googleapis.com/udca/disk/used_bytes": "apigee", "router.googleapis.com/bfd/control/receive_intervals": "router", "bigquery.googleapis.com/query/count": "bigquery", "composer.googleapis.com/environment/worker/pod_eviction_count": "composer", "compute.googleapis.com/instance/integrity/early_boot_validation_status": "compute", "pubsub.googleapis.com/subscription/streaming_pull_ack_request_count": "pubsub", "apigee.googleapis.com/upstream/request_count": "apigee", "compute.googleapis.com/mirroring/dropped_packets_count": "compute", "compute.googleapis.com/guest/disk/queue_length": "compute", "router.googleapis.com/nat/allocated_ports": "router", "cloudsql.googleapis.com/database/postgresql/replication/replica_byte_lag": "cloudsql", "router.googleapis.com/bfd/control/received_packets_count": "router", "cloudfunctions.googleapis.com/function/network_egress": "cloudfunctions", "pubsub.googleapis.com/subscription/streaming_pull_mod_ack_deadline_request_count": "pubsub", "cloudsql.googleapis.com/database/mysql/innodb_data_fsyncs": "cloudsql", "compute.googleapis.com/instance/disk/write_bytes_count": "compute", "compute.googleapis.com/instance/disk/throttled_read_bytes_count": "compute", "bigtable.googleapis.com/cluster/disk_load": "bigtable", "storage.googleapis.com/authz/acl_based_object_access_count": "storage", "cloudtasks.googleapis.com/queue/task_attempt_delays": "cloudtasks", "dlp.googleapis.com/content_bytes_transformed_count": "dlp", "redis.googleapis.com/stats/reject_connections_count": "redis", "pubsub.googleapis.com/topic/num_unacked_messages_by_region": "pubsub", "tpu.googleapis.com/network/received_bytes_count": "tpu", "memcache.googleapis.com/node/uptime": "memcache", "composer.googleapis.com/environment/database_health": "composer", "router.googleapis.com/nat/new_connections_count": "router", "pubsub.googleapis.com/topic/unacked_bytes_by_region": "pubsub", "spanner.googleapis.com/instance/backup/used_bytes": "spanner", "pubsub.googleapis.com/subscription/oldest_unacked_message_age_by_region": "pubsub", "pubsub.googleapis.com/snapshot/config_updates_count": "pubsub", "firebasedatabase.googleapis.com/rules/evaluation_count": "firebasedatabase", "vpn.googleapis.com/tunnel_established": "vpn", "apigee.googleapis.com/cassandra/jvm_memory_bytes_used": "apigee", "bigquery.googleapis.com/storage/uploaded_row_count": "bigquery", "loadbalancing.googleapis.com/l3/external/rtt_latencies": "loadbalancing", "container.googleapis.com/container/memory/page_fault_count": "container", "compute.googleapis.com/instance/disk/max_write_ops_count": "compute", "compute.googleapis.com/instance/uptime": "compute", "dataproc.googleapis.com/cluster/operation/failed_count": "dataproc", "tpu.googleapis.com/memory/usage": "tpu", "firebasedatabase.googleapis.com/io/persisted_bytes_count": "firebasedatabase", "file.googleapis.com/nfs/server/write_ops_count": "file", "dataflow.googleapis.com/job/elements_produced_count": "dataflow", "custom.googleapis.com/dataflow/inbound-pubsub-messages": "custom", "loadbalancing.googleapis.com/l3/internal/egress_packets_count": "loadbalancing", "firebasedatabase.googleapis.com/network/monthly_sent": "firebasedatabase", "container.googleapis.com/container/cpu/usage_time": "container", "pubsub.googleapis.com/subscription/pull_message_operation_count": "pubsub", "loadbalancing.googleapis.com/https/request_count": "loadbalancing", "cloudiot.googleapis.com/device/billing_bytes_count": "cloudiot", "apigee.googleapis.com/upstream/response_count": "apigee", "firebasedatabase.googleapis.com/network/active_connections": "firebasedatabase", "interconnect.googleapis.com/network/interconnect/link/operational": "interconnect", "serviceruntime.googleapis.com/quota/exceeded": "serviceruntime", "loadbalancing.googleapis.com/l3/external/egress_bytes_count": "loadbalancing", "compute.googleapis.com/mirroring/mirrored_bytes_count": "compute", "firebasehosting.googleapis.com/network/monthly_sent_limit": "firebasehosting", "pubsub.googleapis.com/subscription/ack_message_count": "pubsub", "bigtable.googleapis.com/replication/max_delay": "bigtable", "appengine.googleapis.com/memcache/operation_count": "appengine", "container.googleapis.com/container/accelerator/memory_used": "container", "dlp.googleapis.com/storage_bytes_transformed_count": "dlp", "datastore.googleapis.com/entity/write_sizes": "datastore", "redis.googleapis.com/replication/master/slaves/lag": "redis", "pubsub.googleapis.com/subscription/mod_ack_deadline_message_operation_count": "pubsub", "ml.googleapis.com/prediction/online/replicas": "ml", "logging.googleapis.com/exports/error_count": "logging", "ml.googleapis.com/prediction/online/network/bytes_sent": "ml", "compute.googleapis.com/nat/allocated_ports": "compute", "interconnect.googleapis.com/network/interconnect/received_unicast_packets_count": "interconnect", "bigtable.googleapis.com/cluster/cpu_load_hottest_node": "bigtable", "redis.googleapis.com/persistence/rdb/bgsave_in_progress": "redis", "redis.googleapis.com/replication/offset_diff": "redis", "logging.googleapis.com/logs_based_metrics_error_count": "logging", "pubsub.googleapis.com/topic/send_request_count": "pubsub", "bigquery.googleapis.com/slots/total_allocated_for_reservation": "bigquery", "firestore.googleapis.com/document/write_count": "firestore", "loadbalancing.googleapis.com/l3/internal/rtt_latencies": "loadbalancing", "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_used": "apigee", "redis.googleapis.com/stats/memory/system_memory_usage_ratio": "redis", "dataproc.googleapis.com/cluster/yarn/apps": "dataproc", "dataflow.googleapis.com/job/current_shuffle_slots": "dataflow", "spanner.googleapis.com/instance/storage/utilization": "spanner", "dataproc.googleapis.com/cluster/yarn/virtual_cores": "dataproc", "apigee.googleapis.com/udca/server/local_file_count": "apigee", "storage.googleapis.com/storage/object_count": "storage", "netapp.com/cloudvolume/request_latencies": "netapp", "cloudsql.googleapis.com/database/state": "cloudsql", "router.googleapis.com/nat/open_connections": "router", "firebasedatabase.googleapis.com/io/utilization": "firebasedatabase", "dataproc.googleapis.com/cluster/yarn/pending_memory_size": "dataproc", "storage.googleapis.com/authz/object_specific_acl_mutation_count": "storage", "custom.googleapis.com/dataflow/total-failed-messages": "custom", "container.googleapis.com/container/pid_limit": "container", "loadbalancing.googleapis.com/l3/external/egress_packets_count": "loadbalancing", "compute.googleapis.com/instance/network/received_packets_count": "compute", "appengine.googleapis.com/http/server/dos_intercept_count": "appengine", "vpcaccess.googleapis.com/connector/received_packets_count": "vpcaccess", "serviceruntime.googleapis.com/api/request_latencies_overhead": "serviceruntime", "spanner.googleapis.com/instance/cpu/smoothed_utilization": "spanner", "remotebuildexecution.googleapis.com/workerpool/size": "remotebuildexecution", "dataproc.googleapis.com/cluster/job/duration": "dataproc", "appengine.googleapis.com/flex/network/sent_bytes_count": "appengine", "pubsub.googleapis.com/subscription/pull_ack_request_count": "pubsub", "cloudtasks.googleapis.com/queue/depth": "cloudtasks", "monitoring.googleapis.com/uptime_check/error_code": "monitoring", "pubsub.googleapis.com/subscription/byte_cost": "pubsub", "redis.googleapis.com/stats/memory/maxmemory": "redis", "pubsub.googleapis.com/subscription/dead_letter_message_count": "pubsub", "pubsub.googleapis.com/topic/byte_cost": "pubsub", "monitoring.googleapis.com/uptime_check/time_until_ssl_cert_expires": "monitoring", "logging.googleapis.com/dropped_log_entry_count": "logging", "pubsub.googleapis.com/topic/config_updates_count": "pubsub", "dataproc.googleapis.com/cluster/yarn/nodemanagers": "dataproc", "cloudsql.googleapis.com/database/postgresql/num_backends": "cloudsql", "appengine.googleapis.com/flex/cpu/reserved_cores": "appengine", "firestore.googleapis.com/document/read_count": "firestore", "container.googleapis.com/container/cpu/utilization": "container", "apigee.googleapis.com/cassandra/jvm_memory_bytes_max": "apigee", "firestore.googleapis.com/network/snapshot_listeners": "firestore", "firebasedatabase.googleapis.com/network/sent_payload_and_protocol_bytes_count": "firebasedatabase", "redis.googleapis.com/keyspace/avg_ttl": "redis", "apigee.googleapis.com/cassandra/jvm_memory_bytes_init": "apigee", "remotebuildexecution.googleapis.com/action/execution/count": "remotebuildexecution", "dataproc.googleapis.com/cluster/operation/submitted_count": "dataproc", "netapp.com/cloudvolume/read_bytes_count": "netapp", "appengine.googleapis.com/flex/autoscaler/current_utilization": "appengine", "cloudsql.googleapis.com/database/mysql/innodb_pages_written": "cloudsql", "cloudfunctions.googleapis.com/function/user_memory_bytes": "cloudfunctions", "storage.googleapis.com/network/sent_bytes_count": "storage", "memcache.googleapis.com/node/items": "memcache", "interconnect.googleapis.com/network/interconnect/link/rx_power": "interconnect", "compute.googleapis.com/instance/integrity/late_boot_validation_status": "compute", "compute.googleapis.com/nat/port_usage": "compute", "remotebuildexecution.googleapis.com/action/execution/durations": "remotebuildexecution", "custom.googleapis.com/dataflow/outbound-failed-events": "custom", "monitoring.googleapis.com/uptime_check/content_mismatch": "monitoring", "storage.googleapis.com/authz/acl_operations_count": "storage", "cloudiot.googleapis.com/device/error_count": "cloudiot", "redis.googleapis.com/replication/master/slaves/offset": "redis", "dataproc.googleapis.com/cluster/operation/duration": "dataproc", "pubsub.googleapis.com/subscription/unacked_bytes_by_region": "pubsub", "appengine.googleapis.com/flex/instance/network/received_bytes_count": "appengine", "pubsub.googleapis.com/subscription/num_retained_acked_messages": "pubsub", "composer.googleapis.com/environment/scheduler_heartbeat_count": "composer", "appengine.googleapis.com/flex/autoscaler/connections/current": "appengine", "appengine.googleapis.com/system/instance_count": "appengine", "bigquery.googleapis.com/query/statement_scanned_bytes_billed": "bigquery", "compute.googleapis.com/instance/cpu/reserved_cores": "compute", "pubsub.googleapis.com/subscription/num_unacked_messages_by_region": "pubsub", "storage.googleapis.com/storage/total_bytes": "storage", "cloudsql.googleapis.com/database/mysql/replication/slave_io_running_state": "cloudsql", "router.googleapis.com/nat/sent_packets_count": "router", "redis.googleapis.com/stats/evicted_keys": "redis", "appengine.googleapis.com/system/network/received_bytes_count": "appengine", "router.googleapis.com/nat/nat_allocation_failed": "router", "bigtable.googleapis.com/server/error_count": "bigtable", "composer.googleapis.com/environment/num_celery_workers": "composer", "pubsub.googleapis.com/topic/oldest_retained_acked_message_age_by_region": "pubsub", "serviceruntime.googleapis.com/quota/allocation/usage": "serviceruntime", "pubsub.googleapis.com/topic/message_sizes": "pubsub", "composer.googleapis.com/environment/api/request_latencies": "composer", "cloudfunctions.googleapis.com/function/execution_count": "cloudfunctions", "custom.googleapis.com/dataflow/outbound-successful-events": "custom", "firebasedatabase.googleapis.com/network/sent_payload_bytes_count": "firebasedatabase", "cloudsql.googleapis.com/database/mysql/replication/slave_io_running": "cloudsql", "cloudfunctions.googleapis.com/function/execution_times": "cloudfunctions", "datastore.googleapis.com/entity/read_sizes": "datastore", "firewallinsights.googleapis.com/vm/firewall_last_used_timestamp": "firewallinsights", "ml.googleapis.com/training/accelerator/memory/utilization": "ml", "ml.googleapis.com/training/memory/utilization": "ml", "appengine.googleapis.com/system/billed_instance_estimate_count": "appengine", "spanner.googleapis.com/instance/cpu/utilization": "spanner", "compute.googleapis.com/nat/closed_connections_count": "compute", "composer.googleapis.com/workflow/run_duration": "composer", "run.googleapis.com/container/memory/allocation_time": "run", "monitoring.googleapis.com/uptime_check/check_passed": "monitoring", "compute.googleapis.com/instance/memory/balloon/swap_in_bytes_count": "compute", "cloudsql.googleapis.com/database/disk/quota": "cloudsql", "bigquery.googleapis.com/query/execution_times": "bigquery", "cloudsql.googleapis.com/database/mysql/queries": "cloudsql", "cloudsql.googleapis.com/database/available_for_failover": "cloudsql", "appengine.googleapis.com/flex/instance/network/sent_bytes_count": "appengine", "router.googleapis.com/router_up": "router", "apigee.googleapis.com/cassandra/process_open_fds": "apigee", "compute.googleapis.com/nat/received_packets_count": "compute", "cloudtrace.googleapis.com/billing/spans_ingested": "cloudtrace", "remotebuildexecution.googleapis.com/workerpool/slots": "remotebuildexecution", "loadbalancing.googleapis.com/https/backend_request_count": "loadbalancing", "apigee.googleapis.com/cassandra/compaction_pendingtasks": "apigee", "interconnect.googleapis.com/network/interconnect/sent_bytes_count": "interconnect", "cloudsql.googleapis.com/database/mysql/innodb_os_log_fsyncs": "cloudsql", "apigee.googleapis.com/udca/server/pruned_file_count": "apigee", "bigquerybiengine.googleapis.com/model/request_latencies": "bigquerybiengine", "dataproc.googleapis.com/cluster/job/completion_time": "dataproc", "apigee.googleapis.com/server/nio": "apigee", "bigtable.googleapis.com/cluster/storage_utilization": "bigtable", "composer.googleapis.com/environment/executor/open_slots": "composer", "cloudsql.googleapis.com/database/replication/replica_lag": "cloudsql", "router.googleapis.com/bgp_sessions_up_count": "router", "netapp.com/cloudvolume/write_bytes_count": "netapp", "logging.googleapis.com/excluded_byte_count": "logging", "run.googleapis.com/container/memory/utilizations": "run", "router.googleapis.com/nat/received_packets_count": "router", "vpn.googleapis.com/network/dropped_sent_packets_count": "vpn", "firebasedatabase.googleapis.com/storage/disabled_for_overages": "firebasedatabase", "memcache.googleapis.com/node/sent_bytes_count": "memcache", "bigquerybiengine.googleapis.com/model/request_count": "bigquerybiengine", "ml.googleapis.com/prediction/response_count": "ml", "compute.googleapis.com/nat/dropped_received_packets_count": "compute", "datastore.googleapis.com/index/write_count": "datastore", "cloudsql.googleapis.com/database/mysql/received_bytes_count": "cloudsql", "firebasedatabase.googleapis.com/network/broadcast_load": "firebasedatabase", "bigquery.googleapis.com/query/statement_scanned_bytes": "bigquery", "container.googleapis.com/container/uptime": "container", "redis.googleapis.com/keyspace/keys": "redis", "apigee.googleapis.com/udca/server/upload_latencies": "apigee", "appengine.googleapis.com/http/server/response_latencies": "appengine", "vpn.googleapis.com/network/received_packets_count": "vpn", "ml.googleapis.com/prediction/online/accelerator/duty_cycle": "ml", "compute.googleapis.com/instance/disk/max_read_ops_count": "compute", "pubsub.googleapis.com/snapshot/oldest_message_age": "pubsub", "pubsub.googleapis.com/subscription/push_request_latencies": "pubsub", "compute.googleapis.com/instance/disk/read_bytes_count": "compute", "apigee.googleapis.com/proxy/response_count": "apigee", "dataflow.googleapis.com/job/system_lag": "dataflow", "compute.googleapis.com/guest/disk/bytes_used": "compute", "file.googleapis.com/nfs/server/read_ops_count": "file", "file.googleapis.com/nfs/server/write_milliseconds_count": "file", "pubsub.googleapis.com/snapshot/oldest_message_age_by_region": "pubsub", "compute.googleapis.com/guest/memory/page_cache_used": "compute", "loadbalancing.googleapis.com/tcp_ssl_proxy/egress_bytes_count": "loadbalancing", "bigtable.googleapis.com/server/multi_cluster_failovers_count": "bigtable", "composer.googleapis.com/workflow/task/run_count": "composer", "networking.googleapis.com/vm_flow/ingress_bytes_count": "networking", "router.googleapis.com/bfd/control/transmitted_packets_count": "router", "compute.googleapis.com/nat/new_connections_count": "compute", "compute.googleapis.com/guest/disk/operation_time": "compute", "cloudiot.googleapis.com/device/received_bytes_count": "cloudiot", "firewallinsights.googleapis.com/vm/firewall_hit_count": "firewallinsights", "bigquery.googleapis.com/query/scanned_bytes": "bigquery", "storage.googleapis.com/storage/total_byte_seconds": "storage", "dataflow.googleapis.com/job/elapsed_time": "dataflow", "compute.googleapis.com/guest/disk/operation_count": "compute", "interconnect.googleapis.com/network/interconnect/link/tx_power": "interconnect", "dataproc.googleapis.com/cluster/yarn/containers": "dataproc", "compute.googleapis.com/nat/dropped_sent_packets_count": "compute", "logging.googleapis.com/log_entry_count": "logging", "dataproc.googleapis.com/cluster/job/failed_count": "dataproc", "pubsub.googleapis.com/snapshot/num_messages_by_region": "pubsub", "logging.googleapis.com/billing/monthly_bytes_ingested": "logging", "run.googleapis.com/request_latencies": "run", "compute.googleapis.com/instance/disk/read_ops_count": "compute", "compute.googleapis.com/instance/memory/balloon/ram_used": "compute", "apigee.googleapis.com/udca/server/total_latencies": "apigee", "apigee.googleapis.com/target/latencies": "apigee", "netapp.com/cloudvolume/operation_count": "netapp", "apigee.googleapis.com/udca/upstream/http_error_count": "apigee", "serviceruntime.googleapis.com/api/response_sizes": "serviceruntime", "pubsub.googleapis.com/subscription/retained_acked_bytes": "pubsub", "apigee.googleapis.com/upstream/latencies": "apigee", "cloudsql.googleapis.com/database/disk/utilization": "cloudsql", "firebasedatabase.googleapis.com/storage/total_bytes": "firebasedatabase", "networking.googleapis.com/vm_flow/rtt": "networking", "bigtable.googleapis.com/server/modified_rows_count": "bigtable", "appengine.googleapis.com/memcache/received_bytes_count": "appengine", "serviceruntime.googleapis.com/quota/limit": "serviceruntime", "network.googleapis.com/loadbalancer/utilization": "network", "compute.googleapis.com/instance/memory/balloon/ram_size": "compute", "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_max": "apigee", "networksecurity.googleapis.com/https/request_count": "networksecurity", "pubsub.googleapis.com/subscription/num_retained_acked_messages_by_region": "pubsub", "file.googleapis.com/nfs/server/used_bytes_percent": "file", "run.googleapis.com/request_count": "run", "interconnect.googleapis.com/network/attachment/received_packets_count": "interconnect", "redis.googleapis.com/stats/cpu_utilization": "redis", "pubsub.googleapis.com/subscription/oldest_unacked_message_age": "pubsub", "loadbalancing.googleapis.com/l3/external/ingress_packets_count": "loadbalancing", "cloudsql.googleapis.com/database/mysql/replication/seconds_behind_master": "cloudsql", "pubsub.googleapis.com/subscription/seek_request_count": "pubsub", "pubsub.googleapis.com/subscription/pull_request_count": "pubsub", "bigquery.googleapis.com/storage/table_count": "bigquery", "compute.googleapis.com/guest/system/problem_count": "compute", "composer.googleapis.com/environment/task_queue_length": "composer", "firebasehosting.googleapis.com/storage/limit": "firebasehosting", "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_committed": "apigee", "memcache.googleapis.com/node/cpu/usage_time": "memcache", "router.googleapis.com/bgp/session_up": "router", "compute.googleapis.com/guest/memory/dirty_used": "compute", "cloudtasks.googleapis.com/queue/task_attempt_count": "cloudtasks", "compute.googleapis.com/instance/disk/throttled_write_bytes_count": "compute", "pubsub.googleapis.com/topic/oldest_unacked_message_age_by_region": "pubsub", "compute.googleapis.com/nat/received_bytes_count": "compute", "dataflow.googleapis.com/job/is_failed": "dataflow", "vpcaccess.googleapis.com/connector/sent_bytes_count": "vpcaccess", "apigee.googleapis.com/server/latencies": "apigee", "dataflow.googleapis.com/job/user_counter": "dataflow", "compute.googleapis.com/guest/cpu/runnable_task_count": "compute", "loadbalancing.googleapis.com/https/frontend_tcp_rtt": "loadbalancing", "appengine.googleapis.com/flex/disk/read_bytes_count": "appengine", "compute.googleapis.com/instance/disk/max_write_bytes_count": "compute", "bigtable.googleapis.com/replication/latency": "bigtable", "compute.googleapis.com/guest/disk/operation_bytes_count": "compute", "apigee.googleapis.com/proxy/latencies": "apigee", "interconnect.googleapis.com/network/attachment/sent_packets_count": "interconnect", "monitoring.googleapis.com/uptime_check/http_status": "monitoring", "compute.googleapis.com/guest/memory/anonymous_used": "compute", "cloudsql.googleapis.com/database/uptime": "cloudsql", "dataproc.googleapis.com/cluster/yarn/allocated_memory_percentage": "dataproc", "compute.googleapis.com/instance/cpu/usage_time": "compute", "appengine.googleapis.com/flex/instance/cpu/utilization": "appengine", "cloudsql.googleapis.com/database/up": "cloudsql", "pubsub.googleapis.com/snapshot/backlog_bytes_by_region": "pubsub", "interconnect.googleapis.com/network/interconnect/receive_errors_count": "interconnect", "composer.googleapis.com/environment/healthy": "composer", "bigquery.googleapis.com/slots/allocated_for_project_and_job_type": "bigquery", "bigquery.googleapis.com/slots/total_available": "bigquery", "loadbalancing.googleapis.com/tcp_ssl_proxy/closed_connections": "loadbalancing", "ml.googleapis.com/training/cpu/utilization": "ml", "firestore.googleapis.com/document/delete_count": "firestore", "ml.googleapis.com/training/accelerator/utilization": "ml", "file.googleapis.com/nfs/server/procedure_call_count": "file", "monitoring.googleapis.com/uptime_check/request_latency": "monitoring", "dlp.googleapis.com/job_trigger_run_count": "dlp", "redis.googleapis.com/stats/connections/total": "redis", "appengine.googleapis.com/memcache/centi_mcu_count": "appengine", "pubsub.googleapis.com/subscription/streaming_pull_ack_message_operation_count": "pubsub", "dataflow.googleapis.com/job/total_streaming_data_processed": "dataflow", "router.googleapis.com/nat/port_usage": "router", "router.googleapis.com/nat/sent_bytes_count": "router", "container.googleapis.com/container/cpu/reserved_cores": "container", "interconnect.googleapis.com/network/interconnect/received_bytes_count": "interconnect", "ml.googleapis.com/prediction/online/network/bytes_received": "ml", "firebasedatabase.googleapis.com/io/sent_responses_count": "firebasedatabase", "bigquery.googleapis.com/query/scanned_bytes_billed": "bigquery", "bigtable.googleapis.com/server/sent_bytes_count": "bigtable", "loadbalancing.googleapis.com/l3/external/ingress_bytes_count": "loadbalancing", "loadbalancing.googleapis.com/https/response_bytes_count": "loadbalancing", "memcache.googleapis.com/node/cache_memory": "memcache", "remotebuildexecution.googleapis.com/action/execution/active": "remotebuildexecution", "vpn.googleapis.com/network/sent_bytes_count": "vpn", "spanner.googleapis.com/api/request_count": "spanner", "composer.googleapis.com/environment/dagbag_size": "composer", "dataproc.googleapis.com/cluster/operation/running_count": "dataproc", "logging.googleapis.com/exports/byte_count": "logging", "dataflow.googleapis.com/job/estimated_bytes_produced_count": "dataflow", "vpn.googleapis.com/network/received_bytes_count": "vpn", "compute.googleapis.com/guest/memory/bytes_used": "compute", "redis.googleapis.com/commands/usec_per_call": "redis", "pubsub.googleapis.com/subscription/num_undelivered_messages": "pubsub", "firebasedatabase.googleapis.com/network/disabled_for_overages": "firebasedatabase", "dataflow.googleapis.com/job/data_watermark_age": "dataflow", "compute.googleapis.com/guest/disk/io_time": "compute", "netapp.com/cloudvolume/inode_usage": "netapp", "memcache.googleapis.com/node/hit_ratio": "memcache", "loadbalancing.googleapis.com/tcp_ssl_proxy/frontend_tcp_rtt": "loadbalancing", "apigee.googleapis.com/cassandra/jvm_memory_pool_bytes_init": "apigee", "dataflow.googleapis.com/job/estimated_byte_count": "dataflow", "dataflow.googleapis.com/job/total_shuffle_data_processed": "dataflow", "composer.googleapis.com/environment/dag_processing/parse_error_count": "composer", "loadbalancing.googleapis.com/l3/internal/ingress_bytes_count": "loadbalancing", "bigquerybiengine.googleapis.com/reservation/total_bytes": "bigquerybiengine", "compute.googleapis.com/nat/sent_packets_count": "compute", "storage.googleapis.com/authn/authentication_count": "storage", "compute.googleapis.com/instance/cpu/utilization": "compute", "redis.googleapis.com/clients/connected": "redis", "logging.googleapis.com/exports/log_entry_count": "logging", "dlp.googleapis.com/storage_bytes_inspected_count": "dlp", "apigee.googleapis.com/target/response_count": "apigee", "bigtable.googleapis.com/server/latencies": "bigtable", "pubsub.googleapis.com/subscription/streaming_pull_mod_ack_deadline_message_operation_count": "pubsub", "apigee.googleapis.com/udca/server/retry_cache_size": "apigee", "redis.googleapis.com/stats/network_traffic": "redis", "appengine.googleapis.com/memcache/used_cache_size": "appengine", "apigee.googleapis.com/udca/server/local_file_oldest_ts": "apigee", "interconnect.googleapis.com/network/interconnect/send_errors_count": "interconnect", "appengine.googleapis.com/flex/network/received_bytes_count": "appengine", "run.googleapis.com/container/cpu/utilizations": "run", "cloudsql.googleapis.com/database/memory/usage": "cloudsql", "compute.googleapis.com/guest/cpu/usage_time": "compute", "dataflow.googleapis.com/job/per_stage_data_watermark_age": "dataflow", "apigee.googleapis.com/proxy/request_count": "apigee", "bigquery.googleapis.com/slots/allocated_for_reservation": "bigquery", "compute.googleapis.com/instance_group/size": "compute", "router.googleapis.com/nat/dropped_received_packets_count": "router", "container.googleapis.com/container/disk/bytes_total": "container", "ml.googleapis.com/prediction/online/target_replicas": "ml", "tpu.googleapis.com/network/sent_bytes_count": "tpu", "apigee.googleapis.com/server/num_threads": "apigee", "pubsub.googleapis.com/subscription/mod_ack_deadline_message_count": "pubsub", "pubsub.googleapis.com/subscription/oldest_retained_acked_message_age": "pubsub", "cloudsql.googleapis.com/database/memory/quota": "cloudsql", "bigquery.googleapis.com/storage/uploaded_bytes": "bigquery", "pubsub.googleapis.com/subscription/pull_ack_message_operation_count": "pubsub", "redis.googleapis.com/stats/memory/system_memory_overload_duration": "redis", "ml.googleapis.com/training/network/sent_bytes_count": "ml", "cloudsql.googleapis.com/database/memory/utilization": "cloudsql", "bigquerybiengine.googleapis.com/reservation/used_bytes": "bigquerybiengine", "redis.googleapis.com/replication/master_repl_offset": "redis", "composer.googleapis.com/environment/dag_processing/total_parse_time": "composer", "apigee.googleapis.com/policy/latencies": "apigee", "compute.googleapis.com/instance/network/sent_packets_count": "compute", "pubsub.googleapis.com/subscription/push_request_count": "pubsub", "router.googleapis.com/nat/received_bytes_count": "router", "memcache.googleapis.com/node/eviction_count": "memcache", "cloudsql.googleapis.com/database/network/connections": "cloudsql", "loadbalancing.googleapis.com/https/backend_response_bytes_count": "loadbalancing", "pubsub.googleapis.com/subscription/config_updates_count": "pubsub", "storagetransfer.googleapis.com/agent/transferred_bytes_count": "storagetransfer", "spanner.googleapis.com/instance/storage/limit_bytes": "spanner", "ml.googleapis.com/prediction/online/accelerator/memory/bytes_used": "ml", "cloudsql.googleapis.com/database/mysql/innodb_pages_read": "cloudsql", "appengine.googleapis.com/system/cpu/usage": "appengine", "firebasehosting.googleapis.com/network/sent_bytes_count": "firebasehosting", "monitoring.googleapis.com/stats/num_time_series": "monitoring", "cloudsql.googleapis.com/database/disk/write_ops_count": "cloudsql", "loadbalancing.googleapis.com/https/internal/total_latencies": "loadbalancing", "spanner.googleapis.com/api/sent_bytes_count": "spanner", "router.googleapis.com/bfd/control/transmit_intervals": "router", "cloudsql.googleapis.com/database/cpu/reserved_cores": "cloudsql", "ml.googleapis.com/prediction/prediction_count": "ml", "apigee.googleapis.com/server/response_count": "apigee", "firebasehosting.googleapis.com/storage/total_bytes": "firebasehosting", "composer.googleapis.com/workflow/run_count": "composer", "dataproc.googleapis.com/cluster/job/submitted_count": "dataproc", "firestore.googleapis.com/network/active_connections": "firestore", "firebasedatabase.googleapis.com/network/api_hits_count": "firebasedatabase", "loadbalancing.googleapis.com/https/internal/request_count": "loadbalancing", "apigee.googleapis.com/udca/upstream/http_latencies": "apigee", "compute.googleapis.com/instance/disk/throttled_read_ops_count": "compute", "dataflow.googleapis.com/job/per_stage_system_lag": "dataflow", "container.googleapis.com/container/accelerator/memory_total": "container", "run.googleapis.com/container/cpu/allocation_time": "run", "container.googleapis.com/container/accelerator/request": "container", "container.googleapis.com/container/disk/inodes_free": "container", "bigtable.googleapis.com/disk/bytes_used": "bigtable", "loadbalancing.googleapis.com/https/total_latencies": "loadbalancing", "router.googleapis.com/nat/closed_connections_count": "router", "bigtable.googleapis.com/server/received_bytes_count": "bigtable", "cloudtrace.googleapis.com/billing/monthly_spans_ingested": "cloudtrace", "router.googleapis.com/bfd/session_up": "router", "ml.googleapis.com/prediction/online/cpu/utilization": "ml", "compute.googleapis.com/guest/disk/weighted_io_time": "compute", "composer.googleapis.com/environment/dag_processing/processor_timeout_count": "composer", "appengine.googleapis.com/flex/instance/ws/avg_duration": "appengine", "pubsub.googleapis.com/topic/send_message_operation_count": "pubsub", "serviceruntime.googleapis.com/api/request_latencies_backend": "serviceruntime", "pubsub.googleapis.com/topic/retained_acked_bytes_by_region": "pubsub", "dataflow.googleapis.com/job/status": "dataflow", "file.googleapis.com/nfs/server/used_bytes": "file", "dataproc.googleapis.com/cluster/hdfs/unhealthy_blocks": "dataproc", "appengine.googleapis.com/memcache/hit_ratio": "appengine", "apigee.googleapis.com/server/request_count": "apigee", "loadbalancing.googleapis.com/https/internal/request_bytes_count": "loadbalancing", "dataproc.googleapis.com/cluster/hdfs/storage_utilization": "dataproc", "appengine.googleapis.com/system/network/sent_bytes_count": "appengine", "appengine.googleapis.com/http/server/quota_denial_count": "appengine", "redis.googleapis.com/stats/cache_hit_ratio": "redis", "appengine.googleapis.com/system/memory/usage": "appengine", "interconnect.googleapis.com/network/interconnect/operational": "interconnect", "compute.googleapis.com/nat/sent_bytes_count": "compute", "container.googleapis.com/container/memory/bytes_used": "container", "dataproc.googleapis.com/cluster/operation/completion_time": "dataproc", "dlp.googleapis.com/finding_count": "dlp", "loadbalancing.googleapis.com/https/backend_request_bytes_count": "loadbalancing", "compute.googleapis.com/instance/disk/write_ops_count": "compute", "router.googleapis.com/nat/dropped_sent_packets_count": "router", "compute.googleapis.com/firewall/dropped_packets_count": "compute"}
        };
    }

    render() {
        return (
            <div className={css.main}>
                <div className={css.container}>
                    <Heading level={1} style={{ "textAlign": 'center', "color": "#5cc05c" }}>{this.props.name}</Heading>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Use the following form to create a unique Terraform template that will push logs and metrics from your GCP environment to Splunk.
                        Once you have selected all your data sources, download the Terraform template and deploy it using GCP's Cloud Shell tool or your local CLI with the Terraform tool installed.
                    </P>
                    <br/>
                    <h3 style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        <b>See prerequisites and additional documentation in the GitHub repository <a target="_blank" href="https://github.com/cumulostrata/cumulostrata.github.io">README</a>.</b>
                    </h3>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        <b>General configuration</b>
                    </P>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Provide general details about your GCP and Splunk environment
                    </P>
                    <br/>
                    <ControlGroup
                        label="Splunk endpoint URL and port"
                        labelPosition="top"
                        tooltip="Format is https://{{server}}:{{port}}. The default port for HTTP Event Collector is 8088 (For Splunk Cloud endpoints, the default is 443). This endpoint should have a valid SSL certificate installed for the port."
                        help="Example: https://1.1.1.1:8088"
                        style={{ "margin": '0 auto', "display": this.state.EndpointField }}
                        error={this.state.EndpointValue_not_provided}
                    >
                        <Text canClear onChange={this.handleEndpointChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="Splunk management endpoint URL and port"
                        labelPosition="top"
                        tooltip="Format is https://{{server}}:{{port}}. The default management port for Splunk is 8089."
                        help="Example: https://1.1.1.1:8089"
                        style={{ "margin": '0 auto', "display": this.state.SplunkCredentialsDisplay }}
                    >
                        <Text canClear onChange={this.handleMgmtEndpointChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="HTTP Event Collector Token (Indexer acknowledgement disabled)"
                        labelPosition="top"
                        tooltip="Format is 12345678-qwer-asdf-zxcv-123456789qwe. Confirm that the token is enabled and indexer acknowledgement is disabled."
                        help="Example: 12345678-qwer-asdf-zxcv-123456789qwe."
                        style={{ "margin": '0 auto' }}
                        error={this.state.NoAckTokenValue_not_provided}
                    >
                        <Text inline onChange={this.handleNoAckTokenChange} canClear/>
                    </ControlGroup>
                    <br/>
                    <ControlGroup
                        label="GCP Project ID"
                        labelPosition="top"
                        tooltip="The Project ID can be found in the home page of your GCP project console. This is the GCP project where logging resources will be deployed. For Organization logging exports, this region will be where the organization logging infrastructure (Pub/Sub, Dataflow, etc. is deployed)"
                        help="Example: myproject-1234"
                        style={{ "margin": '0 auto'}}
                        error={this.state.project_id_not_provided}
                    >
                        <Text canClear onChange={this.handleProjectIdChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="GCP Region"
                        labelPosition="top"
                        tooltip="The region where logging resources will be deployed. For Organization logging exports, this region will be where the organization logging infrastructure (Pub/Sub, Dataflow, etc. is deployed)"
                        help="Example: us-central1"
                        style={{ "margin": '0 auto'}}
                        error={this.state.region_not_provided}
                    >
                        <Text canClear onChange={this.handleRegionChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="GCP Zone"
                        labelPosition="top"
                        tooltip="The zone where logging resources will be deployed. For Organization logging exports, this zone will be where the organization logging infrastructure (Pub/Sub, Dataflow, etc. is deployed)"
                        help="Example: us-central1-c"
                        style={{ "margin": '0 auto'}}
                        error={this.state.zone_not_provided}
                    >
                        <Text canClear onChange={this.handleZoneChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <ControlGroup
                        label="GCP Organization Id"
                        labelPosition="top"
                        tooltip="The organization id can be found in Cloud Shell or you CLI using the `gcloud organizations list` command"
                        help="Example: 123456789"
                        style={{ "margin": '0 auto', "display": this.state.items[3].display === '' || this.state.items[4].display === '' || this.state.items[7].display === '' ? '' : 'none'}}
                        error={this.state.org_id_not_provided}
                    >
                        <Text canClear onChange={this.handleOrgIdChange} style={{ "width": "30%", "textAlign": 'center' }}/>
                    </ControlGroup>
                    <br/>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        <b>GCP data source configuration</b>
                    </P>
                    <P style={{ "width": "90%", "textAlign": 'center', "margin": "0 auto" }}>
                        Select the GCP data sources which will be sent to Splunk
                    </P>
                    <br/>
                    <div style={{ "margin": "0 auto", "width": "750px" }}>
                        <Menu>
                            {/*<Menu.Item
                                selectable
                                selected={this.state.items[0].done}
                                key={this.state.items[0].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[0].title}
                                <Multiselect
                                    values={this.state.values}
                                    onChange={this.handleCWEChange}
                                    style={{ "marginLeft": "40px", "display": this.state.items[0].display }}
                                    inline
                                >
                                    {this.state.metrics_full_list.map((item) =>
                                        {if (item.type === "event") {
                                            return(
                                                <Multiselect.Option label={item.name} value={item.name } />
                                            )
                                        }
                                        if (item.type === "service") {
                                            return(<Multiselect.Heading>{item.name}</Multiselect.Heading>)
                                        }}
                                    )}
                                </Multiselect>
                                <Switch
                                    key={this.state.items[0].id}
                                    value={this.state.items[0].title}
                                    onClick={() => this.handleToggleClick(0)}
                                    selected={this.state.items[0].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>*/}
                            <Menu.Item
                                selectable
                                selected={this.state.items[1].done}
                                key={this.state.items[1].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[1].title}
                                <Switch
                                    key={this.state.items[1].id}
                                    value={this.state.items[1].title}
                                    onClick={() => this.handleToggleClick(1)}
                                    selected={this.state.items[1].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[2].done}
                                key={this.state.items[2].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[2].title}
                                <Switch
                                    key={this.state.items[2].id}
                                    value={this.state.items[2].title}
                                    onClick={() => this.handleToggleClick(2)}
                                    selected={this.state.items[2].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[3].done}
                                key={this.state.items[3].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[3].title}
                                <Switch
                                    key={this.state.items[3].id}
                                    value={this.state.items[3].title}
                                    onClick={() => this.handleToggleClick(3)}
                                    selected={this.state.items[3].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[4].done}
                                key={this.state.items[4].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[4].title}
                                <Switch
                                    key={this.state.items[4].id}
                                    value={this.state.items[4].title}
                                    onClick={() => this.handleToggleClick(4)}
                                    selected={this.state.items[4].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>
                            {/*<Menu.Item
                                selectable
                                selected={this.state.items[5].done}
                                key={this.state.items[5].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[5].title}
                               <Switch
                                    key={this.state.items[5].id}
                                    value={this.state.items[5].title}
                                    onClick={() => this.handleToggleClick(5)}
                                    selected={this.state.items[5].done}
                                    appearance="toggle"
                                    style={{ "float": "right", "marginTop": "-5px" }}
                                />
                            </Menu.Item>
                            <br/>*/}
                            <Menu.Item
                                selectable
                                selected={this.state.items[6].done}
                                key={this.state.items[6].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[6].title}
                                <FormRows
                                    onRequestAdd={this.handleRequestLoggingFilterRowAdd}
                                    onRequestMove={this.handleRequestLoggingFilterRowMove}
                                    style={{ width: 400, "display": this.state.items[6].display, "marginLeft": "200px",  "marginTop": "-20px" }}
                                >
                                    {this.state.loggingFilterRows}
                                </FormRows>
                                <Switch
                                    key={this.state.items[6].id}
                                    value={this.state.items[6].title}
                                    onClick={() => this.handleToggleClick(6)}
                                    selected={this.state.items[6].done}
                                    appearance="toggle"
                                    style={{ "float": "right" }}
                                />
                            </Menu.Item>
                            <br/>
                            <Menu.Item
                                selectable
                                selected={this.state.items[7].done}
                                key={this.state.items[7].id}
                                style={{ "width": "900px", "margin": "0 auto", "float": "left" }}
                            >
                                {this.state.items[7].title}
                                <FormRows
                                    onRequestAdd={this.handleRequestOrgLoggingFilterRowAdd}
                                    onRequestMove={this.handleRequestOrgLoggingFilterRowMove}
                                    style={{ width: 400, "display": this.state.items[7].display, "marginLeft": "200px",  "marginTop": "-20px" }}
                                >
                                    {this.state.orgLoggingFilterRows}
                                </FormRows>
                                <Switch
                                    key={this.state.items[7].id}
                                    value={this.state.items[7].title}
                                    onClick={() => this.handleToggleClick(7)}
                                    selected={this.state.items[7].done}
                                    appearance="toggle"
                                    style={{ "float": "right" }}
                                />
                            </Menu.Item>
                        </Menu>
                    </div>
                    <br/>
                    <Button label="Download Terraform template" onClick={() => this.handleDownloadClick()} appearance="primary" style={{ flexBasis: '200px' }} />
                    <br/>
                    <div className={css.container}>
                        <Heading level={2} style={{ textAlign: 'center' }}>
                            Legal
                        </Heading>
                        <Heading level={3} style={{ textAlign: 'center' }}>
                            This automation template generating tool is not supported by Splunk.
                        </Heading>
                        <P style={{ textAlign: 'left' }}>
                            THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
                        </P>
                    </div>
                </div>
            </div>
        );
    }

    handleRequestLoggingFilterRowAdd = () => {
          /*
            Adds an empty row to the loggingFilterRows object
         */
        this.setState({
            loggingFilterRows: FormRows.addRow(
                <FormRows.Row
                    index={this.state.loggingFilterRows.length}
                    key={createDOMID()}
                    onRequestRemove={this.handleRequestLoggingFilterRowRemove}
                >
                    <Text placeholder="Custom logging filter" name={this.state.loggingFilterGroups.length} onChange={this.handleLoggingFilterChange} />
                </FormRows.Row>,
                this.state.loggingFilterRows
            ),
        });
    };

    handleRequestLoggingFilterRowMove = ({ fromIndex, toIndex }) => {
        /*
            Moves a row in the loggingFilterRows object.
            Also handles the movement of the row user input in the loggingFilterGroups object.
         */
        let loggingFilterGroups = this.state.loggingFilterGroups;
        let tmp = loggingFilterGroups[toIndex];
        loggingFilterGroups[toIndex] = loggingFilterGroups[fromIndex];
        loggingFilterGroups[fromIndex] = tmp;

        this.setState({ loggingFilterGroups });

        this.setState({
            loggingFilterRows: FormRows.moveRow(fromIndex, toIndex, this.state.loggingFilterRows),
        });
    };

    handleRequestLoggingFilterRowRemove = (e, { index }) => {
        /*
            Deletes a row in the Rows object.
            Also handles the deletion of the row user input in the loggingFilterGroups object.
         */
        let loggingFilterGroups = this.state.loggingFilterGroups;
        loggingFilterGroups.splice(index, 1);

        this.setState({ loggingFilterGroups });

        this.setState({
            loggingFilterRows: FormRows.removeRow(index, this.state.loggingFilterRows),
        });
    };


    handleRequestOrgLoggingFilterRowAdd = () => {
          /*
            Adds an empty row to the loggingFilterRows object
         */
        this.setState({
            orgLoggingFilterRows: FormRows.addRow(
                <FormRows.Row
                    index={this.state.orgLoggingFilterRows.length}
                    key={createDOMID()}
                    onRequestRemove={this.handleRequestOrgLoggingFilterRowRemove}
                >
                    <Text placeholder="Custom Organization logging filter" name={this.state.orgLoggingFilterGroups.length} onChange={this.handleOrgLoggingFilterChange} />
                </FormRows.Row>,
                this.state.orgLoggingFilterRows
            ),
        });
    };

    handleRequestOrgLoggingFilterRowMove = ({ fromIndex, toIndex }) => {
        /*
            Moves a row in the orgLoggingFilterRows object.
            Also handles the movement of the row user input in the loggingFilterGroups object.
         */
        let orgLoggingFilterGroups = this.state.orgLoggingFilterGroups;
        let tmp = orgLoggingFilterGroups[toIndex];
        orgLoggingFilterGroups[toIndex] = orgLoggingFilterGroups[fromIndex];
        orgLoggingFilterGroups[fromIndex] = tmp;

        this.setState({ orgLoggingFilterGroups });

        this.setState({
            orgLoggingFilterRows: FormRows.moveRow(fromIndex, toIndex, this.state.orgLoggingFilterRows),
        });
    };

    handleRequestOrgLoggingFilterRowRemove = (e, { index }) => {
        /*
            Deletes a row in the Rows object.
            Also handles the deletion of the row user input in the orgLoggingFilterGroups object.
         */
        let orgLoggingFilterGroups = this.state.orgLoggingFilterGroups;
        orgLoggingFilterGroups.splice(index, 1);

        this.setState({ orgLoggingFilterGroups });

        this.setState({
            orgLoggingFilterRows: FormRows.removeRow(index, this.state.orgLoggingFilterRows),
        });
    };

    handleCWEChange = (e, { values }) => {
        /*
            Update the values state object with the provided list of CloudWatch Events
         */
        this.setState({ values });
    };

    handleLoggingFilterChange = (e, { value, name }) => {
        /*
            Adds the user input to the loggingFilterGroups object.
            name contains the current index - use to determine if we need to append or update an existing value
         */
        let loggingFilterGroups = this.state.loggingFilterGroups;
        if (loggingFilterGroups.length <= name) {
            loggingFilterGroups.push(value);
        } else {
            loggingFilterGroups[name] = value;
        }
        this.setState({ loggingFilterGroups })
    };

    handleOrgLoggingFilterChange = (e, { value, name }) => {
        /*
            Adds the user input to the loggingFilterGroups object.
            name contains the current index - use to determine if we need to append or update an existing value
         */
        let orgLoggingFilterGroups = this.state.orgLoggingFilterGroups;
        if (orgLoggingFilterGroups.length <= name) {
            orgLoggingFilterGroups.push(value);
        } else {
            orgLoggingFilterGroups[name] = value;
        }
        this.setState({ orgLoggingFilterGroups })
    };

    handleEndpointChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.EndpointValue = value;
        this.setState({ EndpointValue_not_provided: false })
    };

    handleProjectIdChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.project_id = value;
        this.setState({ project_id_not_provided: false })
    };

    handleRegionChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.region = value;
        this.setState({ region_not_provided: false })
    };

    handleZoneChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.zone = value;
        this.setState({ zone_not_provided: false })
    }

    handleOrgIdChange = (e, { value }) => {
        /*
            Set the EndpointValue state value with the user provided Splunk endpoint
         */
        this.state.org_id = value;
        this.setState({ org_id_not_provided: false })
    };

    handleMgmtEndpointChange = (e, { value }) => {
        /*
            Set the SplunkManagementEndpoint state value with the user provided Splunk management endpoint
         */
        this.state.SplunkManagementEndpoint = value;
    };

    handleTokenChange = (e, { value }) => {
        /*
            Set the TokenValue state value with the user provided Splunk HEC Token
         */
        this.state.TokenValue = value;
    };

    handleNoAckTokenChange = (e, { value }) => {
        /*
            Set the TokenValue state value with the user provided Splunk HEC Token
         */
        this.state.NoAckTokenValue = value;
        this.setState({ NoAckTokenValue_not_provided: false })
    };

    handleAutoHecClick = () => {
        /*
            When a user selects or deselects automatic HEC token creation - Hide or show the token form inputs,
            also hide or show the Splunk credentials (username/password) form inputs.
         */
        let TokenDisplay = this.state.TokenDisplay;
        let NoAckTokenDisplay = this.state.NoAckTokenDisplay;
        let SplunkCredentialsDisplay = this.state.SplunkCredentialsDisplay;
        let autoHEC = !this.state.autoHEC;

        if (TokenDisplay === 'none') {
            TokenDisplay = "";
        } else {
            TokenDisplay = "none";
        }

        if (NoAckTokenDisplay === 'none') {
            NoAckTokenDisplay = "";
        } else {
            NoAckTokenDisplay = "none";
        }

        if (SplunkCredentialsDisplay === 'none') {
            SplunkCredentialsDisplay = "";
        } else {
            SplunkCredentialsDisplay = "none";
        }

        this.setState({ NoAckTokenDisplay });
        this.setState({ TokenDisplay });
        this.setState({ SplunkCredentialsDisplay });
        this.setState({ autoHEC });
    };

    handleToggleClick(index) {
        /*
            When a toggle is selected - flip the boolean "done" value and set the display to 'none' (not visible)
            or an empty string (visible)
         */
        const items = this.state.items;
        items[index].done = !items[index].done;

        if (items[index].display === 'none') {
            items[index].display = "";
        } else {
            items[index].display = "none";
        }

        this.setState({ items });
    }

    handleDownloadClick() {
         /*
            Called on template download click. Creates an inline JSON object based off of an inline CloudFormation template
            and the selections made by the used in the form. After creating the object, the JSON object is converted to a
            file and downloaded.
        */

         // Grab all needed state variables for easier visibility
        let hec_url = this.state.EndpointValue;
        let hec_token = this.state.NoAckTokenValue;
        let metrics_selections = this.state.values;
        let metrics_service_map = this.state.metrics_service_map;
        let loggingFilterGroups = this.state.loggingFilterGroups;
        let orgLoggingFilterGroups = this.state.orgLoggingFilterGroups;
        let gcp_project_id = this.state.project_id;
        let gcp_region = this.state.region;
        let gcp_zone = this.state.zone;
        let gcp_org_id = this.state.org_id;

        const items = this.state.items;

        let invalid = false;

        if (gcp_project_id === '') {
            invalid = true;
            this.setState({ project_id_not_provided: true })
        } else {
            this.setState({ project_id_not_provided: false })
        }

        if (gcp_region === '') {
            invalid = true;
            this.setState({ region_not_provided: true })
        } else {
            this.setState({ region_not_provided: false })
        }

        if (gcp_zone === '') {
            invalid = true;
            this.setState({ zone_not_provided: true })
        } else {
            this.setState({ zone_not_provided: false })
        }

        if (hec_url === '') {
            invalid = true;
            this.setState({ EndpointValue_not_provided: true })
        } else {
            this.setState({ EndpointValue_not_provided: false })
        }

        if (hec_token === '') {
            invalid = true;
            this.setState({ NoAckTokenValue_not_provided: true })
        } else {
            this.setState({ NoAckTokenValue_not_provided: false })
        }

        if (gcp_org_id === '' && (this.state.items[3].display === '' || this.state.items[4].display === '' || this.state.items[7].display === '')) {
            invalid = true;
            this.setState({ org_id_not_provided: true })
        } else {
            this.setState({ org_id_not_provided: false })
        }

        if (invalid) {
            window.scrollTo({
              top: 0,
              left: 0,
              behavior: 'smooth'
            });
            return
        }

        let full_filter = '';
        let full_org_filter = '';
        let vpc_flow_log_filter = '(resource.type=\"gce_subnetwork\" AND log_name=\"projects/' + gcp_project_id + '/logs/compute.googleapis.com%2Fvpc_flows\")';
        let cloudaudit_filter = '(log_name:\"projects/' + gcp_project_id + '/logs/cloudaudit.googleapis.com\")';
        let gsuite_groups_log_filter = '(log_name=\"organizations/' + gcp_org_id + '/logs/cloudaudit.googleapis.com%2Factivity\")';
        let gsuite_admin_log_filter = '(log_name=\"organizations/' + gcp_org_id + '/logs/cloudaudit.googleapis.com%2Factivity\"  protoPayload.serviceName=\"admin.googleapis.com\" resource.type=\"audited_resource\")';
        let gsuite_login_log_filter = '(log_name=\"organizations/' + gcp_org_id + '/logs/cloudaudit.googleapis.com%2Fdata_access\" protoPayload.serviceName=\"login.googleapis.com\" resource.type=\"audited_resource\")';

        // Cloud Audit
        if (items[1]['done']) {
            if (full_filter === '') {
                full_filter += cloudaudit_filter
            } else {
                full_filter += ' OR ' + cloudaudit_filter
            }
        }

        // VPC Flow
        if (items[2]['done']) {
            if (full_filter === '') {
                full_filter += vpc_flow_log_filter
            } else {
                full_filter += ' OR ' + vpc_flow_log_filter
            }
        }

        // Gsuite Admin
        if (items[3]['done']) {
            if (full_org_filter === '') {
                full_org_filter += gsuite_admin_log_filter
            } else {
                full_org_filter += ' OR ' + gsuite_admin_log_filter
            }
        }

        // Gsiuite Logins
        if (items[4]['done']) {
            if (full_org_filter === '') {
                full_org_filter += gsuite_login_log_filter
            } else {
                full_org_filter += ' OR ' + gsuite_login_log_filter
            }
        }

        // Custom filter
        if (items[6]['done']) {
            for (let i=0; i < loggingFilterGroups.length ;i++) {
                if (full_filter === '') {
                    full_filter += '(' + loggingFilterGroups[i] + ')'
                } else {
                    full_filter += ' OR (' + loggingFilterGroups[i] + ')'
                }
            }
        }

        // Custom org filter
        if (items[7]['done']) {
            for (let i=0; i < orgLoggingFilterGroups.length ;i++) {
                if (full_org_filter === '') {
                    full_org_filter += '(' + orgLoggingFilterGroups[i] + ')'
                } else {
                    full_org_filter += ' OR (' + orgLoggingFilterGroups[i] + ')'
                }
            }
        }

        let shared_template =
            'provider "google" {\n' +
            '  project = "' + gcp_project_id + '"\n' +
            '  region  = "' + gcp_region + '"\n' +
            '  zone    = "' + gcp_zone + '"\n' +
            '}\n' +
            '\n' +
            'data "google_project" "project" {}\n' +
            '\n' +
            'resource “google_project_service” “dataflow_service” {\n' +
            '    service = “dataflow.googleapis.com”\n' +
            '    disable_dependent_services = true\n' +
            '    depends_on = [ google_project_service.stackdriver_service ]\n' +
            '}' +
            '\n' +

        // The full metrics tf template
        let metrics_template = 'resource "google_pubsub_topic" "metrics-splunk-topic" {\n' +
            '  name = "metrics-splunk"\n' +
            '}\n' +
            '\n' +
            'resource "google_storage_bucket" "metrics-splunk-code-bucket" {\n' +
            ' \tname = "metrics-splunk-code"\n' +
            '}\n' +
            '\n' +
            'resource "google_storage_bucket_object" "metrics-splunk-code-object" {\n' +
            '  name = "metrics-splunk.zip"\n' +
            '  bucket = google_storage_bucket.metrics-splunk-code-bucket.name\n' +
            '  source = "./metrics-splunk-code/metrics-splunk.zip"\n' +
            '}\n' +
            '\n' +
            'resource "google_cloud_scheduler_job" "metrics-splunk-scheduler-job" {\n' +
            '  name = "metrics-splunk-scheduler"\n' +
            '  schedule = "*/5 * * * *"\n' +
            '  time_zone = "America/Los_Angeles"\n' +
            '\n' +
            '  pubsub_target {\n' +
            '    topic_name = google_pubsub_topic.metrics-splunk-topic.id\n' +
            '    data = base64encode("trigger")\n' +
            '  }\n' +
            '}\n' +
            '\n' +
            'resource "google_cloudfunctions_function" "metrics-splunk-function" {\n' +
            '  name = "metrics-splunk"\n' +
            '  event_trigger {\n' +
            '    event_type = "providers/cloud.pubsub/eventTypes/topic.publish"\n' +
            '    resource = google_pubsub_topic.metrics-splunk-topic.name\n' +
            '  }\n' +
            '  entry_point = "hello_pubsub"\n' +
            '  runtime = "python37"\n' +
            '  service_account_email = google_service_account.metrics-splunk-sa.email\n' +
            '  source_archive_bucket = google_storage_bucket.metrics-splunk-code-bucket.name\n' +
            '  source_archive_object = google_storage_bucket_object.metrics-splunk-code-object.name\n' +
            '  environment_variables = {\n' +
            '    HEC_URL = "' + hec_url + '"\n' +
            '    HEC_TOKEN = "' + hec_token + '"\n' +
            '    PROJECTID = "' + gcp_project_id + '"\n' +
            '    METRICS_LIST = "' + JSON.stringify(metrics_selections).replace(/[\""]/g, '\\"') + '"\n' +
            '    TIME_INTERVAL = "5"\n' +
            '    RETRY_TOPIC = google_pubsub_topic.metrics-retry-splunk-topic.name\n' +
            '  }\n' +
            '}\n' +
            '\n' +
            'resource "google_service_account" "metrics-splunk-sa" {\n' +
            '  account_id   = "metrics-splunk"\n' +
            '  display_name = "Service Account used by the metrics-splunk Cloud Function"\n' +
            '}\n' +
            '\n' +
            'resource "google_project_iam_binding" "metrics-splunk-sa-monitoring-viewer-role" {\n' +
            '  role    = "roles/monitoring.viewer"\n' +
            '  members = [\n' +
            '    "serviceAccount:${google_service_account.metrics-splunk-sa.email}"\n' +
            '  ]\n' +
            '}\n' +
            'resource "google_pubsub_topic" "metrics-retry-splunk-topic" {\n' +
            '  name = "retry-splunk"\n' +
            '}\n' +
            '\n' +
            'resource "google_pubsub_subscription" "metrics-retry-splunk-subscription" {\n' +
            '  name  = "retry-splunk"\n' +
            '  topic = google_pubsub_topic.metrics-retry-splunk-topic.name\n' +
            '  ack_deadline_seconds = 60\n' +
            '}\n' +
            '\n' +
            'resource "google_storage_bucket" "metrics-retry-splunk-code-bucket" {\n' +
            ' \tname = "metrics-retry-splunk-code"\n' +
            '}\n' +
            '\n' +
            'resource "google_storage_bucket_object" "metrics-retry-splunk-code-object" {\n' +
            '  name = "retry-splunk.zip"\n' +
            '  bucket = google_storage_bucket.metrics-retry-splunk-code-bucket.name\n' +
            '  source = "./retry-splunk-code/retry-splunk.zip"\n' +
            '}\n' +
            '\n' +
            'resource "google_cloudfunctions_function" "metrics-retry-splunk-function" {\n' +
            '  name = "metrics-retry-splunk"\n' +
            '  event_trigger {\n' +
            '    event_type = "providers/cloud.pubsub/eventTypes/topic.publish"\n' +
            '    resource = google_pubsub_topic.metrics-retry-splunk-topic.name\n' +
            '  }\n' +
            '  entry_point = "hello_pubsub"\n' +
            '  runtime = "python37"\n' +
            '  service_account_email = google_service_account.metrics-retry-splunk-sa.email\n' +
            '  source_archive_bucket = google_storage_bucket.metrics-retry-splunk-code-bucket.name\n' +
            '  source_archive_object = google_storage_bucket_object.metrics-retry-splunk-code-object.name\n' +
            '  environment_variables = {\n' +
            '    PROJECTID = "' + gcp_project_id + '"\n' +
            '    SUBSCRIPTION = google_pubsub_subscription.metrics-retry-splunk-subscription.name\n' +
            '    RETRY_TRIGGER_TOPIC = google_pubsub_topic.metrics-retry-splunk-topic.name\n' +
            '  }\n' +
            '}\n' +
            '\n' +
            'resource "google_service_account" "metrics-retry-splunk-sa" {\n' +
            '  account_id   = "metrics-retry"\n' +
            '  display_name = "Service Account used by the retry-snapshot Cloud Function"\n' +
            '}\n'+
            '\n'

        let dataflow_template = 'resource "random_uuid" "dataflow_name" {}\n' +
            '\n' +
            'resource "google_pubsub_topic" "deadletter-splunk-topic" {\n' +
            '  name = "deadletter-splunk"\n' +
            '}\n' +
            '\n' +
            'resource "google_pubsub_subscription" "deadletter-dataflow-splunk-subscription" {\n' +
            '  name  = "deadletter-dataflow-splunk-subscription"\n' +
            '  topic = google_pubsub_topic.deadletter-splunk-topic.name\n' +
            '}\n' +
            '\n' +
            'resource "google_pubsub_topic" "stackdriver-logs-dataflow-topic" {\n' +
            '  name = "stackdriver-dataflow-logs"\n' +
            '}\n' +
            '\n' +
            'resource "google_pubsub_subscription" "stackdriver-logs-dataflow-subscription" {\n' +
            '  name  = "stackdriver-logs-dataflow-subscription"\n' +
            '  topic = google_pubsub_topic.stackdriver-logs-dataflow-topic.name\n' +
            '}\n' +
            '\n' +
            'resource "random_uuid" "bucket_guid" {}\n' +
            '\n' +
            'resource "google_storage_bucket" "dataflow-splunk-job-temp-bucket" {\n' +
            '  name = "${random_uuid.bucket_guid.result}-splunk-dataflow"\n' +
            '}\n' +
            '\n' +
            'resource "google_storage_bucket_object" "dataflow-splunk-job-temp-object" {\n' +
            '  name = "tmp/"\n' +
            '  content = "Placeholder to satisfy Dataflow requirements"\n' +
            '  bucket = "${google_storage_bucket.dataflow-splunk-job-temp-bucket.name}"\n' +
            '}\n' +
            '\n' +
            'resource "google_dataflow_job" "splunk-dataflow-job-' + Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 9) + '" {\n' +
            '  name = "splunk-dataflow-streaming-${random_uuid.dataflow_name.result}"\n' +
            '  template_gcs_path = "gs://dataflow-templates/latest/Cloud_PubSub_to_Splunk"\n' +
            '  temp_gcs_location = join("", ["gs://", "${google_storage_bucket.dataflow-splunk-job-temp-bucket.name}", "/tmp"])\n' +
            '  max_workers = "1"\n' +
            '  parameters = {\n' +
            '    inputSubscription\t= "${google_pubsub_subscription.stackdriver-logs-dataflow-subscription.path}"\n' +
            '    token\t= "' + hec_token + '"\n' +
            '    url\t= "' + hec_url + '"\n' +
            '    disableCertificateValidation = "true"\n' +
            '    outputDeadletterTopic = join("", ["projects/", "' + gcp_project_id + '", "/topics/", "${google_pubsub_topic.deadletter-splunk-topic.name}"])\n' +
            '  }\n' +
            '}\n'

        let project_sink = 'resource "google_logging_project_sink" "audited-resource-logs-pubsub-dataflow-sink" {\n' +
            '  name = "audited-resource-logs-pubsub-dataflow-sink"\n' +
            '  destination = "pubsub.googleapis.com/projects/' + gcp_project_id + '/topics/${google_pubsub_topic.stackdriver-logs-dataflow-topic.name}"\n' +
            '  filter ="' + full_filter.replace(/[\""]/g, '\\"') + '"\n' +
            '  unique_writer_identity = true\n' +
            '}\n' +
            '\n' +
            'resource "google_project_iam_binding" "pubsub-log-writer" {\n' +
            '  role = "roles/pubsub.publisher"\n' +
            '\n' +
            '  members = [\n' +
            '    google_logging_project_sink.audited-resource-logs-pubsub-dataflow-sink.writer_identity,\n' +
            '  ]\n' +
            '}\n' +
            '\n' +
            'resource "google_project_iam_binding" "pubsub-log-viewer" {\n' +
            '  role = "roles/pubsub.viewer"\n' +
            '\n' +
            '  members = [\n' +
            '    google_logging_project_sink.audited-resource-logs-pubsub-dataflow-sink.writer_identity,\n' +
            '  ]\n' +
            '}\n' +
            '\n'

        let organization_sink = 'resource "google_logging_organization_sink" "organization-logs-pubsub-dataflow-sink" {\n' +
            '  name = "organization-logs-pubsub-dataflow-sink"\n' +
            '  org_id = "' + gcp_org_id + '"\n' +
            '  destination = "pubsub.googleapis.com/projects/' + gcp_project_id + '/topics/${google_pubsub_topic.stackdriver-logs-dataflow-topic.name}"\n' +
            '  filter ="' + full_org_filter.replace(/[\""]/g, '\\"') + '"\n' +
            '  include_children = "true"\n' +
            '}\n' +
            '\n' +
            'resource "google_project_iam_binding" "organiation-pubsub-log-writer" {\n' +
            '  role = "roles/pubsub.publisher"\n' +
            '\n' +
            '  members = [\n' +
            '    google_logging_organization_sink.organization-logs-pubsub-dataflow-sink.writer_identity,\n' +
            '  ]\n' +
            '}\n' +
            '\n' +
            'resource "google_project_iam_binding" "organiation-pubsub-log-viewer" {\n' +
            '  role = "roles/pubsub.viewer"\n' +
            '\n' +
            '  members = [\n' +
            '    google_logging_organization_sink.organization-logs-pubsub-dataflow-sink.writer_identity,\n' +
            '  ]\n' +
            '}\n' +
            '\n'

        let to_download = shared_template;

         // Metrics
        if (items[0]['done']) {
            to_download += metrics_template;
        }

        if (items[1]['done'] || items[2]['done'] || items[6]['done']) {
            to_download += dataflow_template
            to_download += project_sink
        }

        if (items[5]['done'] || items[3]['done'] || items[4]['done']) {
            if (items[1]['done'] || items[2]['done'] || items[6]['done']){
                // dataflow template already added
                to_download += organization_sink
            } else {
                to_download += dataflow_template;
                to_download += organization_sink
            }
        }

        // Set local variables
        // Add in pieces of template

        // Create the CloudFormation template based off of user selections and previous configuration
        let textFile = null, makeTextFile = function (text) {
            let data = new Blob([text], {type: 'text/plain'});

            // If we are replacing a previously generated file we need to
            // manually revoke the object URL to avoid memory leaks.
            if (textFile !== null) {
              window.URL.revokeObjectURL(textFile);
            }

            textFile = window.URL.createObjectURL(data);

            return textFile;
        };

        let anchor = document.createElement('a');
        anchor.href = makeTextFile(to_download);
        anchor.target = '_blank';
        anchor.download = "customized_splunk_gcp_template.tf";
        anchor.click();
    }
}

export default SplunkGCPConfigurationWebsite;
