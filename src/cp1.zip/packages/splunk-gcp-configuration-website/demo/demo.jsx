import React from 'react';
import { render } from 'react-dom';
import SplunkGCPConfigurationWebsite from '../src/SplunkGCPConfigurationWebsite';

const containerEl = document.getElementById('main-component-container');
render(<SplunkGCPConfigurationWebsite />, containerEl);
