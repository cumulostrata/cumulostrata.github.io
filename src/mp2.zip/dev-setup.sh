#!/bin/sh
cd app-assets
yarn install
yarn run build
cd packages/mothership-app
yarn run link:app
cd ..
yarn run start
