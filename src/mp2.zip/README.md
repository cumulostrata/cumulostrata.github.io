Mothership will be bundled as an application and deployed on an independent instance. Summary data will be pulled from pre-configured Splunk machines and stored locally. This information can be any arbitrary search including events, and other metrics that need to be pulled from each Splunk deployment.

Steps to build:

1.)
    Check that $SPLUNK_HOME env var is correctly set

2.)

    $ cd app-assets
    $ yarn install
    $ yarn run build
    $ cd packages/mothership-app
    $ yarn run link:app
    $ cd ..
    $ yarn run start

3.)
    ... RESTART SPLUNK ...

4.)
    Open the mothership-app in Splunk

5.)
    UI changes require a _bump
    Non UI changes probably require a debug/refresh and maybe rerun of `yarn run start`
