#!/bin/sh
cd app-assets
yarn install
if ls packages/mothership-app/stage &> /dev/null; then
    mv packages/mothership-app/stage packages/mothership-app/stage.`date +%s`.bak
fi
if ls packages/mothership-app/mothership &> /dev/null; then
    mv packages/mothership-app/mothership packages/mothership-app/mothership.`date +%s`.bak
fi
mv packages/mothership-app/stage packages/mothership-app/stage.bak
yarn run build
rm packages/mothership-app/stage/bin/environment_searches_eai_handler_test.py
rm packages/mothership-app/stage/bin/environments_eai_handler_test.py
rm packages/mothership-app/stage/bin/test_runner.py
VERSION="$(grep -rn version packages/mothership-app/src/main/resources/splunk/default/app.conf | cut -d'=' -f2)"
mv packages/mothership-app/stage packages/mothership-app/mothership
cd packages/mothership-app/
tar -zcvf mothership-$VERSION.tar.gz mothership
shasum mothership-$VERSION.tar.gz >> mothership-$VERSION.shasum
mv mothership-$VERSION.tar.gz ../../../
mv mothership-$VERSION.shasum ../../../
