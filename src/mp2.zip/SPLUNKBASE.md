Overview:
https://confluence.splunk.com/display/PROD/All+About+Splunk+Works
Submission:
https://confluence.splunk.com/display/PROD/Splunk+Works+App+Submission+Instructions

Summary:
Mothership App for Splunk

Description:
Data collection application enabling the archiving/snapshot of search results from one or multiple remote Splunk Search Head instances.

Name of Author:
Nicolas Stone nstone@splunk.com
Carl Yestrau carl@splunk.com

URL of Project:
https://git.splunk.com/projects/GSA/repos/mothership/browse

Reason App Built:
Need for managed service providers (MSPs) and customers with multiple Splunk deployments to be able to see events/results in one centralized Splunk instance.

Existing or planned product team work:
None.

Supported by Splunk:
Community supported.

Third-party software included:
* certifi, 2010.10.15, MPL 2.0, https://certifi.io/en/latest/
* chardet, 3.0.4, GPL 2.1, https://github.com/chardet/chardet
* idna, 10.0.0, 013-2018 Kim Davies, https://github.com/kjd/idna
* requests, 2.20.1, Apache 2.0, http://python-requests.org
* urllib3, 1.24.1, MIT, https://urllib3.readthedocs.io/en/latest/
* schema, 0.6.8, MIT, https://github.com/keleshev/schema
* Python library for Splunk, 1.6.0, Apache 2.0, https://github.com/splunk/splunk-sdk-python
* @splunk/react-ui, 1.4.0, Splunk Software License Agreement, https://www.splunk.com/en_us/legal/splunk-software-license-agreement.html
* @splunk/react-sparkline, 0.3.1, Splunk Software License Agreement, https://www.splunk.com/en_us/legal/splunk-software-license-agreement.html
* uuid, 3.3.2, MIT, https://github.com/kelektiv/node-uuid

Code included in Splunk products or projects:
Using Splunk Python SDK (https://github.com/splunk/splunk-sdk-python) and Splunk UI (http://splunkui/).

Includes confidential information:
NO sample data including potentially confidential or private information is included.

Related patents or patent applications:
Marc Knittel is the current legal representative overviewing project.

Anything a competitor might copy:
See Marc Kittle for feedback based on several meetings.

App encrypted or utilizes encryption technology?
Uses Splunk password encryption endpoint for storing authentication credentials for remote environments.

AppInspect API request-id:
0c7345ca-9880-47b0-8b80-20f199e465e4

Permission to use logo or icon?
Icon created by authors.

Software License:
MIT

JIRA:
https://jira.splunk.com/browse/SPLWORKS-1160
