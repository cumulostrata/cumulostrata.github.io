1.) Update release notes (`CHANGELOG.md`)

2.) Checkout the latest from our release branch

3.) `rm stage`

4.) `yarn run build` (To generate the production build of assets)

5.) Rename stage to mothership

6.) Create a `tar.gz` following the naming convention found on our confluence page

7.) Get the `SHA` of the `tar.gz` using `shasum release_file.tar.gz`

8.) From a configured `venv` (see: http://dev.splunk.com/view/appinspect/SP-CAAAFAK). Run `splunk-appinspect inspect mothership mothership-v[VERSION].tar.gz --mode precert`

9.) Check the results of the appinspect test. Fix any failures, relevant warnings, or manual checks that should be addressed

10.) `rm` any old Mothership app from your existing Splunk instance and extract the `tar.gz` ensuring it extracts to a directory called mothership

11.) Restart Splunk, bump cache, do a full crud lifecyle on an environment and environment search

12.) If all is well, tag the source code given the current conventions, else fix and return to the beginning of these release step

13.) Merge to master

14.) Upload `tar.gz` and hash to confluence for download

15.) Update Slack room with links, CHANGELOG, and any HIGHLIGHT screenshots