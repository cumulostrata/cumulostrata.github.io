import React from 'react';
import { render } from 'react-dom';
import MothershipComponent from '../src/MothershipComponent';

const containerEl = document.getElementById('main-component-container');
render(<MothershipComponent name="World" />, containerEl);
