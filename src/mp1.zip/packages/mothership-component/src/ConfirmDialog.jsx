import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from '@splunk/react-ui/Button';
import Message from '@splunk/react-ui/Message';
import Modal from '@splunk/react-ui/Modal';
import P from '@splunk/react-ui/Paragraph';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

class ConfirmDialog extends Component {
    static propTypes = {
        /** Open the dialog and overlay. */
        open: PropTypes.bool,
        /** Generally text, but may also include [Links](./Link). */
        children: PropTypes.node,
        /**
         * A function that will be called when a close event occurs. The callback will be passed a
         * reason (either 'escapeKey' or 'clickAway') and the event.
         *
         * Generally, this callback should be used to toggle the `open` prop.
         */
        onRequestClose: PropTypes.func,
        /**
         * A function that will be called when a submit is called on the form.
         *
         * Generally, this callback should be used to handle the submission of form values.
         */
        onRequestSubmit: PropTypes.func,
        /**
         * Optional title for form.
         */
        title: PropTypes.string,
        /**
         * Optional message for form.
         */
        confirmMessage: PropTypes.string,
        /**
         * Optional error message.
         */
        errorMessage: PropTypes.string,
        /**
         * Top level control of save spinner
         */
        showSpinner: PropTypes.bool,
        /**
         * Top level control of save button
         */
        showSave: PropTypes.bool,
        /**
         * Label of form submit button
         */
        primaryButtonLabel: PropTypes.string,
    };


    static defaultProps = {
        open: false,
        onRequestClose() {},
        onRequestSubmit() {},
        title: '',
        confirmMessage: '',
        errorMessage: '',
        showSpinner: false,
        showSave: true,
    };


    handleRequestClose = e => {
        this.props.onRequestClose(e);
    };


    handleRequestSubmit = e => {
        this.props.onRequestSubmit(e);
    };


    handleRequestDataOnChange = (e, data) => {
        if (Object.prototype.hasOwnProperty.call(this.state, data.name)) {
            const state = {};
            state[data.name] = data.value;
            this.setState(state);
        }
    };


    render() {
        return (
          <Modal
              onRequestClose={this.handleDialogCloseRequest}
              open={this.props.open}
          >
              <Modal.Header title={this.props.title} onRequestClose={this.handleRequestClose} />
              <Modal.Body>
                  { this.props.errorMessage && <Message type="error">{this.props.errorMessage}</Message> }
                  <P>
                      {this.props.confirmMessage}
                  </P>
                  {this.props.children}
              </Modal.Body>
              <Modal.Footer>
                  <Button appearance="secondary" label="Cancel" onClick={this.handleRequestClose} />
                  { this.props.showSave && <Button appearance='primary' label={this.props.primaryButtonLabel} onClick={this.handleRequestSubmit}/>}
                  { this.props.showSpinner && <WaitSpinner size="medium" style={{paddingLeft: 50, paddingRight: 50}} /> }
              </Modal.Footer>
          </Modal>
        );
    }
}
export default ConfirmDialog;
