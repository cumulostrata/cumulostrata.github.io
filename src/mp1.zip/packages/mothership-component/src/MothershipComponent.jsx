import { defaultFetchInit } from '@splunk/splunk-utils/fetch';
import { createRESTURL, createURL } from '@splunk/splunk-utils/url';
import { app } from '@splunk/splunk-utils/config';
import Button from '@splunk/react-ui/Button';
import Warning from '@splunk/react-icons/Warning';
import ColumnLayout from '@splunk/react-ui/ColumnLayout';
import DL from '@splunk/react-ui/DefinitionList';
import Heading from '@splunk/react-ui/Heading';
import Message from '@splunk/react-ui/Message';
import Refresh from '@splunk/react-icons/Refresh';
import Link from '@splunk/react-ui/Link';
import P from '@splunk/react-ui/Paragraph';
import Tooltip from '@splunk/react-ui/Tooltip';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';
import querystring from 'querystring';
import React, { Component } from 'react';
import Environments from './Environments';
import EnvironmentForm from './EnvironmentForm';
import SearchForm from './SearchForm';
import ConfirmDialog from './ConfirmDialog';
import uuidv1 from 'uuid/v1';


class MothershipComponent extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            indexes: [],
            lookups: [],

            environments: [],
            environment: {},

            environmentDeleteFormOpen: false,
            environmentDeleteFormErrorMessage: '',
            environmentDeleteFormShowSpinner: false,
            environmentDeleteFormShowSave: true,

            environmentFormOpen: false,
            environmentFormMode: 'create',
            environmentFormErrorMessage: '',
            environmentFormShowSpinner: false,
            environmentFormShowSave: true,

            loading: true,

            search: {},
            searches: {},

            searchDeleteFormOpen: false,
            searchDeleteFormErrorMessage: '',
            searchDeleteFormShowSpinner: false,
            searchDeleteFormShowSave: true,

            searchFormOpen: false,
            searchFormMode: 'create',
            searchFormErrorMessage: '',
            searchFormShowSpinner: false,
            searchFormShowSave: true,

            searchDisableFormOpen: false,
            searchDisableFormErrorMessage: '',
            searchDisableFormShowSpinner: false,
            searchDisableFormShowSave: true,

            searchEnableFormOpen: false,
            searchEnableFormErrorMessage: '',
            searchEnableFormShowSpinner: false,
            searchEnableFormShowSave: true,

            bulkSearchEnableFormErrorMessage: '',
            bulkSearchEnableFormOpen: false,
            bulkSearchEnableFormShowSpinner: false,
            bulkSearchEnableFormShowSave: true,

            bulkSearchDisableFormErrorMessage: '',
            bulkSearchDisableFormOpen: false,
            bulkSearchDisableFormShowSpinner: false,
            bulkSearchDisableFormShowSave: true,

            searchTemplates: [],

            appsLocal: [],

            //serverRoles: [],
        };
        this.refreshEnvironmentsState();
    };


    // ui event handlers
    handleBulkSearchDisableRequest = (e, environment) => {
        this.setState({ bulkSearchDisableFormOpen: true, environment });
    };


    handleBulkSearchEnableRequest = (e, environment) => {
        this.setState({ bulkSearchEnableFormOpen: true, environment });
    };


    handleBulkSearchDisableSubmitRequest = () => {
        this.setState({  bulkSearchDisableFormShowSpinner: true, bulkSearchDisableFormShowSave: false });
        let search_list = this.state.searches[this.state.environment['links']['alternate']];
        let promises = [];

        for(var i = 0; i < search_list.length; i++) {
            let search = search_list[i];
            let name = search['name'];

            let disable_post_params = {
                disabled: 'True',
                environment_link_alternate: search['content']['environment_link_alternate'],
                type: search['content']['type'],
                search: search['content']['search'],
            };
            promises.push(this.fetchSearchUpdate(name, disable_post_params));
        };

        Promise.all(promises).then((responses) => {
            this.resetEnvironmentFormState();
            this.refreshEnvironmentsState();
        });
    };


    handleBulkSearchEnableSubmitRequest = () => {
        this.setState({  bulkSearchEnableFormShowSpinner: true, bulkSearchEnableFormShowSave: false });
        let search_list = this.state.searches[this.state.environment['links']['alternate']];
        let promises = [];

        for(var i = 0; i < search_list.length; i++) {
            let search = search_list[i];
            let name = search['name'];

            let enable_post_params = {
                disabled: 'False',
                environment_link_alternate: search['content']['environment_link_alternate'],
                type: search['content']['type'],
                search: search['content']['search'],
            };
            promises.push(this.fetchSearchUpdate(name, enable_post_params));
        };

        Promise.all(promises).then((responses) => {
            this.resetEnvironmentFormState();
            this.refreshEnvironmentsState();
        });
    };


    handleEnvironmentsCreateRequest = () => {
        this.setState({ environmentFormOpen: true, environmentFormMode: 'create' });
    };


    handleEnvironmentFormSubmitRequest = (e, params) => {
        this.setState({  environmentFormShowSpinner: true, environmentFormShowSave: false });
        const {environmentFormMode} = this.state;

        for(var i = params.tags.length - 1; i >= 0; i--) {
            if(params.tags[i] === undefined) {
               params.tags.splice(i, 1);
            }
        }

        params.tags = (params.tags).join(',');
        delete params.tagRows;

        if (params.applyAppSearchTemplates) {
            params.search_template_link_alternates = this.getSearchTemplateRESTString(params.appSearchTemplates);
        }
        delete params.applyAppSearchTemplates;
        delete params.appSearchTemplates;

        if (environmentFormMode==='create') {
            this.handleJSONFetch(this.fetchEnvironmentsCreate(params), {
                successCondition: (response) => response.status === 201,
                successHandler: () => {
                    this.resetEnvironmentFormState();
                    this.refreshEnvironmentsState();
                },
                errorCondition: (response) => response.status >= 400,
                errorHandler: (response, data) => {
                    this.setState({ environmentFormErrorMessage: this.parseRESTErrorResponse(data.messages), environmentFormShowSpinner: false, environmentFormShowSave: true });
                }
            });
            return;
        }
        if (environmentFormMode==='edit') {
            const name = params.name;
            delete params.name;
            this.handleJSONFetch(this.fetchEnvironmentsUpdate(name, params), {
                successCondition: (response) => response.status === 200,
                successHandler: () => {
                    this.resetEnvironmentFormState();
                    this.refreshEnvironmentsState();
                },
                errorCondition: (response) => response.status >= 400,
                errorHandler: (response, data) => {
                    this.setState({ environmentFormErrorMessage: this.parseRESTErrorResponse(data.messages), environmentFormShowSpinner: false, environmentFormShowSave: true });
                }
            });
        }
    };


    handleSearchRefreshRequest = () => {
        this.refreshEnvironmentsState();
    };


    handleSearchCreateRequest = (e, environment) => {
        this.setState({ searchFormOpen: true, searchFormMode: 'create', environment });
    };


    handleSearchFormSubmitRequest = (e, params) => {
        this.setState({  searchFormShowSpinner: true, searchFormShowSave: false });
        const { searchFormMode } = this.state;
        switch (params.type) {
            case 'inline':
                params.search = params.inline_search;
                break;
            case 'template':
                params.search = params.template_search_id;
                break;
        }
        params.lookup_link_alternate = params.lookup_id;
        delete params.lookup_id;

        params.index_link_alternate = params.index_id;
        delete params.index_id;

        delete params.inline_search;

        delete params.template_search_id;

        delete params.indexes;

        delete params.lookups;

        if (searchFormMode==='create') {
            const { environment } = this.state;
            params.environment_link_alternate = environment.links.alternate;
            params.name = uuidv1();

            this.handleJSONFetch(this.fetchSearchCreate(params), {
                successCondition: (response) => response.status === 201,
                successHandler: () => {
                    this.resetSearchFormState();
                    this.refreshEnvironmentsState();
                },
                errorCondition: (response) => response.status >= 400,
                errorHandler: (response, data) => {
                    this.setState({ searchFormErrorMessage: this.parseRESTErrorResponse(data.messages), searchFormShowSpinner: false, searchFormShowSave: true });
                }
            });
            return;
        }

        if (searchFormMode==='edit') {
            const name = params.name;
            delete params.name;
            params.environment_link_alternate = this.state.search.content.environment_link_alternate;
            params.disabled = this.state.search.content.disabled;

            this.handleJSONFetch(this.fetchSearchUpdate(name, params), {
                successCondition: (response) => response.status === 200,
                successHandler: () => {
                    this.resetSearchFormState();
                    this.refreshEnvironmentsState();
                },
                errorCondition: (response) => response.status >= 400,
                errorHandler: (response, data) => {
                    this.setState({ searchFormErrorMessage: this.parseRESTErrorResponse(data.messages), searchFormShowSpinner: false, searchFormShowSave: true });
                }
            });
        }
    };


     handleSearchDeleteSubmitRequest = () => {
         this.setState({ searchDeleteFormShowSpinner: true, searchDeleteFormShowSave: false });
        this.handleJSONFetch(this.fetchSearchDelete(this.state.search.name), {
            successCondition: (response) => response.status === 200,
            successHandler: () => {
                this.resetSearchFormState();
                this.refreshEnvironmentsState();
            },
            errorCondition: (response) => response.status >= 400,
            errorHandler: (response, data) => {
                this.setState({ searchDeleteFormErrorMessage: this.parseRESTErrorResponse(data.messages) });
            }
        });
    };


    handleSearchEditRequest = (e, search) => {
        this.resetSearchFormState();
        this.setState({ searchFormOpen: true, searchFormMode: 'edit', search});
    };


    handleSearchBumpRequest = (e, search) => {
        this.resetSearchFormState();
        let name = search['name'];

        let disable_post_params = {
            disabled: 'True',
            environment_link_alternate: search['content']['environment_link_alternate'],
            type: search['content']['type'],
            search: search['content']['search'],
        };

        let enable_post_params = {
            disabled: 'False',
            environment_link_alternate: search['content']['environment_link_alternate'],
            type: search['content']['type'],
            search: search['content']['search'],
        };


        this.fetchSearchUpdate(name, disable_post_params)
            .then(function()  {
                this.fetchSearchUpdate(name, enable_post_params)
            }.bind(this))
            .then(function()  {
                this.refreshEnvironmentsState()
            }.bind(this));
    };


    handleSearchDeleteRequest = (e, search) => {
        this.resetSearchFormState();
        this.setState({ searchDeleteFormOpen: true, search });
    };


    handleSearchDisableRequest = (e, search) => {
        this.resetSearchFormState();
        this.setState({ searchDisableFormOpen: true, search });
    };


    handleSearchEnableRequest = (e, search) => {
        this.resetSearchFormState();
        this.setState({ searchEnableFormOpen: true, search });
    };


    handleSearchDisableSubmitRequest = () => {
        this.setState({ searchDisableFormShowSpinner: true, searchDisableFormShowSave: false });
        const name = this.state.search.name;
        const params = {};
        params.environment_link_alternate = this.state.search.content.environment_link_alternate;
        params.disabled = 'True';
        params.interval = this.state.search.content.interval;
        params.search = this.state.search.content.search;
        params.type = this.state.search.content.type;
        params.label = this.state.search.content.label;

        return this.handleJSONFetch(this.fetchSearchUpdate(name, params), {
            successCondition: (response) => response.status === 200,
            successHandler: () => {
                this.resetSearchFormState();
                this.refreshEnvironmentsState();
            },
            errorCondition: (response) => response.status >= 400,
            errorHandler: (response, data) => {
                this.setState({ searchFormErrorMessage: this.parseRESTErrorResponse(data.messages) });
            }
        });
    };


    handleSearchEnableSubmitRequest = () => {
        this.setState({ searchEnableFormShowSpinner: true, searchEnableFormShowSave: false });
        const name = this.state.search.name;
        const params = {};
        params.environment_link_alternate = this.state.search.content.environment_link_alternate;
        params.disabled = 'False';
        params.interval = this.state.search.content.interval;
        params.search = this.state.search.content.search;
        params.type = this.state.search.content.type;
        params.label = this.state.search.content.label;

        return this.handleJSONFetch(this.fetchSearchUpdate(name, params), {
            successCondition: (response) => response.status === 200,
            successHandler: () => {
                this.resetSearchFormState();
                this.refreshEnvironmentsState();
            },
            errorCondition: (response) => response.status >= 400,
            errorHandler: (response, data) => {
                this.setState({ searchFormErrorMessage: this.parseRESTErrorResponse(data.messages) });
            }
        });
    };


    handleEnvironmentDeleteSubmitRequest = () => {
        this.setState({ environmentDeleteFormShowSpinner: true, environmentDeleteFormShowSave: false });
        this.handleJSONFetch(this.fetchEnvironmentsDelete(this.state.environment.name), {
            successCondition: (response) => response.status === 200,
            successHandler: () => {
                this.resetEnvironmentFormState();
                this.refreshEnvironmentsState();
            },
            errorCondition: (response) => response.status >= 400,
            errorHandler: (response, data) => {
                this.setState({ environmentDeleteFormErrorMessage: this.parseRESTErrorResponse(data.messages) });
            }
        });
    };
    handleEnvironmentsEditRequest = (e, environment) => {
        this.resetEnvironmentFormState();
        this.setState({ environmentFormOpen: true, environmentFormMode: 'edit', environment });
    };
    handleEnvironmentsDeleteRequest = (e, environment) => {
        this.resetEnvironmentFormState();
        this.setState({ environmentDeleteFormOpen: true, environment });
    };


    // state setting helpers
    resetSearchFormState() {
        this.setState({
            environment: {},
            search: {},

            searchFormOpen: false,
            searchFormMode: '',
            searchFormErrorMessage: '',
            searchFormShowSpinner: false,
            searchFormShowSave: true,

            searchDeleteFormOpen: false,
            searchDeleteFormErrorMessage: '',
            searchDeleteFormShowSpinner: false,
            searchDeleteFormShowSave: true,

            searchDisableFormOpen: false,
            searchDisableFormErrorMessage: '',
            searchDisableFormShowSpinner: false,
            searchDisableFormShowSave: true,

            searchEnableFormOpen: false,
            searchEnableFormErrorMessage: '',
            searchEnableFormShowSpinner: false,
            searchEnableFormShowSave: true,
        });
    };


    resetEnvironmentFormState() {
        this.setState({
            environment: {},

            environmentFormOpen: false,
            environmentFormMode: '',
            environmentFormErrorMessage: '',
            environmentFormShowSpinner: false,
            environmentFormShowSave: true,

            environmentDeleteFormOpen: false,
            environmentDeleteFormErrorMessage: '',
            environmentDeleteFormShowSpinner: false,
            environmentDeleteFormShowSave: true,

            bulkSearchDisableFormOpen: false,
            bulkSearchDisableFormShowSpinner: false,
            bulkSearchDisableFormShowSave: true,

            bulkSearchEnableFormOpen: false,
            bulkSearchEnableFormShowSpinner: false,
            bulkSearchEnableFormShowSave: true,
        });
    };


    refreshEnvironmentsState() {
        const environmentsPromise = this.fetchList('environments', {enable_metrics_search: '1'})
            .then(response => response.json());
        const searchesPromise = this.fetchList('environment_searches', {enable_metrics_search: '1'})
            .then(response => response.json());
        const indexesPromise = this.fetchList('data/indexes', {search: 'name!=_*'})
            .then(response => response.json());
        const lookupsPromise = this.fetchList('data/lookup-table-files')
            .then(response => response.json());
        const searchTemplatesPromise = this.fetchList('configs/conf-environment_search_templates', {}, '-')
            .then(response => response.json());
        const appsLocalPromise = this.fetchList('apps/local', {}, '-')
            .then(response => response.json());
        //const serverRolesPromise = this.fetchList('/services/admin/server-roles')
        //    .then(response => response.json());
        Promise.all([environmentsPromise, searchesPromise, indexesPromise, lookupsPromise, searchTemplatesPromise, appsLocalPromise /*, serverRolesPromise*/]).then((responses) => {
            const environments = responses[0].entry;
            const searchesMap = {};
            const searches = responses[1].entry;
            environments.forEach((environment) => {
                const environmentLinkAlternate = environment.links.alternate;
                if (!searchesMap[environmentLinkAlternate]) {
                    searchesMap[environmentLinkAlternate] = [];
                }
                searches.forEach((search) => {
                    if (environmentLinkAlternate === search.content.environment_link_alternate) {
                        searchesMap[environmentLinkAlternate].push(search);
                    }
                });
            });
            this.setState({
                environments: responses[0].entry || [],
                searches: searchesMap,
                searchTemplates: responses[4].entry || [],
                indexes: responses[2].entry || [],
                lookups: responses[3].entry || [],
                appsLocal: responses[5].entry || [],
                //serverRoles: responses[6].entry || [],
                appTemplateMapping: this.getAppTemplateMapping(responses[4].entry || [], responses[5].entry || []),
                loading: false,
            });
        });
    };


    // fetch wrappers
    fetchSearchCreate(params) {
        return fetch(createRESTURL('environment_searches', { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'POST',
            body: querystring.encode({
                output_mode: 'json',
                ...params,
            }),
        });
    };


    fetchSearchUpdate(name, params) {
        return fetch(createRESTURL(`environment_searches/${encodeURIComponent(name)}`, { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'POST',
            body: querystring.encode({
                output_mode: 'json',
                ...params,
            }),
        });
    };


    fetchSearchDelete(name) {
        return fetch(createRESTURL(`environment_searches/${encodeURIComponent(name)}?output_mode=json`, { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'DELETE',
        });
    };


    fetchEnvironmentsCreate(params) {
        return fetch(createRESTURL('environments', { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'POST',
            body: querystring.encode({
                output_mode: 'json',
                ...params,
            }),
        });
    };


    fetchEnvironmentsUpdate(name, params) {
        return fetch(createRESTURL(`environments/${encodeURIComponent(name)}`, { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'POST',
            body: querystring.encode({
                output_mode: 'json',
                ...params,
            }),
        });
    };


    fetchEnvironmentsDelete(name) {
        return fetch(createRESTURL(`environments/${encodeURIComponent(name)}?output_mode=json`, { 'app': app, owner: 'nobody' }, {}), {
            ...defaultFetchInit,
            method: 'DELETE',
        });
    };


    fetchList(endpoint, options={}, app_name=app) {
        const defaults = {output_mode: 'json', count: '-1'};
        const pathname = createRESTURL(endpoint, { 'app': app_name, owner: 'nobody' }, {splunkdPath: 'splunkd/__raw'});
        return fetch(createURL(`${pathname}`, {...defaults, ...options}), {
            ...defaultFetchInit
        });
    };


    // utils
    handleJSONFetch(fetchPromise, { successCondition, successHandler, errorCondition, errorHandler } = { }) {
        return fetchPromise.then(response => response.json()
            .then(data => ({
                    data,
                    response
                })
            )
            .then(request => {
                if (successCondition && successCondition(request.response, request.data)) {
                    return successHandler && successHandler(request.response, request.data);
                }
                if (errorCondition && errorCondition(request.response, request.data)) {
                    return errorHandler && errorHandler(request.response, request.data);
                }
            })
        );
    };


    parseRESTErrorResponse(messages) {
        let message = '';
        for (let i=0; i<messages.length; i+=1) {
            message += messages[i].text || '';
        }
        return message;
    };


    getSearchTemplateRESTString = (searchTemplates) => {
        let searchTemplateStringList = [];

        for (let i=0; i < searchTemplates.length; i++) {
            searchTemplateStringList.push(searchTemplates[i].links.alternate)
        }

        return searchTemplateStringList.join(',');
    };


    getAppTemplateMapping = (searchTemplates, appsLocal) => {
        let appTemplateMapping = {};
        let appTemplateList = [];

        for (let i=0; i < searchTemplates.length; i++) {
            let searchTemplate = searchTemplates[i];
            let searchTemplateAppName = searchTemplate.content['eai:appName'];
            if (!appTemplateMapping.hasOwnProperty(searchTemplateAppName)) {
                appTemplateMapping[searchTemplateAppName] = {appLocal: {}, searchTemplates: []}
            }
            appTemplateMapping[searchTemplateAppName]['searchTemplates'].push(searchTemplate);
        }

        for (let i=0; i < appsLocal.length; i++) {
            let appLocal = appsLocal[i];
            if (appTemplateMapping.hasOwnProperty(appLocal.name)) {
                appTemplateMapping[appLocal.name]['appLocal'] = appLocal;
                if (appLocal.name === app) {
                    appTemplateList.unshift(appTemplateMapping[appLocal.name])
                } else {
                    appTemplateList.push(appTemplateMapping[appLocal.name])
                }
            }
        }

        return appTemplateList;
    };


    getCurrentAppContextSearchTemplates = () => {
        let appSearchTemplates = [];
        let appTemplates = this.state.appTemplateMapping[0];
        if (appTemplates && appTemplates.appLocal && appTemplates.appLocal.name === app) {
            appSearchTemplates = appTemplates.searchTemplates;
        }
        return appSearchTemplates;
    };


    displayNoEnvironmentsMessage = () => {
        return !this.state.environments.length && !this.state.loading
    };

    /*
    displaySearchClusterMessage = () => {
        const serverRolesContent = this.state.serverRoles[0] && this.state.serverRoles[0].content;
        if (serverRolesContent && serverRolesContent.role_list.includes('shc_member') && !serverRolesContent.role_list.includes('shc_captain') ) {
            return true;
        }
        return false;
    };
    */

    // render routines
    renderSearchSummary(name, searchString) {
        return (
            <DL>
                <DL.Term>Name</DL.Term>
                <DL.Description>{name}</DL.Description>
                <DL.Term>Search</DL.Term>
                <DL.Description>
                    <pre style={{ margin: 0, whiteSpace: 'pre-wrap', marginBottom: 10 }}>{searchString}</pre>
                </DL.Description>
            </DL>
        );
    };


    render() {
        const environmentContent = this.state.environment && this.state.environment.content || {};
        const searchContent = this.state.search && this.state.search.content || {};
        const {
            environmentFormOpen,
            environmentFormMode,
            environmentFormErrorMessage,
            environmentFormShowSave,
            environmentFormShowSpinner,
            environmentDeleteFormErrorMessage,
            environmentDeleteFormOpen,
            environmentDeleteFormShowSave,
            environmentDeleteFormShowSpinner,
            searchFormOpen,
            searchFormMode,
            searchFormErrorMessage,
            searchFormShowSave,
            searchFormShowSpinner,
            searchDeleteFormOpen,
            searchDeleteFormErrorMessage,
            searchDeleteFormShowSave,
            searchDeleteFormShowSpinner,
            searchDisableFormOpen,
            searchDisableFormErrorMessage,
            searchDisableFormShowSave,
            searchDisableFormShowSpinner,
            searchEnableFormOpen,
            searchEnableFormErrorMessage,
            searchEnableFormShowSave,
            searchEnableFormShowSpinner,
            bulkSearchDisableFormErrorMessage,
            bulkSearchDisableFormOpen,
            bulkSearchDisableFormShowSpinner,
            bulkSearchDisableFormShowSave,
            bulkSearchEnableFormErrorMessage,
            bulkSearchEnableFormOpen,
            bulkSearchEnableFormShowSpinner,
            bulkSearchEnableFormShowSave,
        } = this.state;
        return (
            <div>

               <ColumnLayout>
                  <ColumnLayout.Row>
                    <ColumnLayout.Column span={6}>
                       <Heading level={1} style={{marginTop: 5}}>
                           Environments&nbsp;
                            {this.state.environments.length>0 &&
                                <Link title="Refresh" onClick={this.refreshEnvironmentsState.bind(this)}><Refresh/></Link>
                            }
                        </Heading>

                       {
                           this.state.loading &&
                           <P>&nbsp;</P>
                       }
                       {
                           !this.state.loading &&
                           <P>
                              {this.state.environments.length} environment{this.state.environments.length !== 1 ? 's' : ''} being monitored.
                              {/*  this.displaySearchClusterMessage() &&
                                 <Tooltip style={{fontSize: '18px', color: "orange"}} content="Search Head Clustering peers require specific configuration.">
                                     &nbsp;<Warning />
                                 </Tooltip>
                              */}
                           </P>
                       }
                       </ColumnLayout.Column>
                    <ColumnLayout.Column style={{textAlign: 'right'}} span={6}>
                         <Button onClick={this.handleEnvironmentsCreateRequest} label='New Environment' disabled={this.state.loading}/>
                    </ColumnLayout.Column>
                  </ColumnLayout.Row>
                </ColumnLayout>

                <Environments
                    environments={this.state.environments}
                    searches={this.state.searches}
                    indexes={this.state.indexes}
                    onRequestEnvironmentEdit={this.handleEnvironmentsEditRequest.bind(this)}
                    onRequestEnvironmentDelete={this.handleEnvironmentsDeleteRequest.bind(this)}
                    onRequestBulkSearchDisable={this.handleBulkSearchDisableRequest.bind(this)}
                    onRequestBulkSearchEnable={this.handleBulkSearchEnableRequest.bind(this)}
                    onRequestSearchRefresh={this.handleSearchRefreshRequest.bind(this)}
                    onRequestSearchCreate={this.handleSearchCreateRequest.bind(this)}
                    onRequestSearchEdit={this.handleSearchEditRequest.bind(this)}
                    onRequestSearchBump={this.handleSearchBumpRequest.bind(this)}
                    onRequestSearchDelete={this.handleSearchDeleteRequest.bind(this)}
                    onRequestSearchEnable={this.handleSearchEnableRequest.bind(this)}
                    onRequestSearchDisable={this.handleSearchDisableRequest.bind(this)}
                />

                { this.displayNoEnvironmentsMessage() && <Message type="error" style={{margin: "10px"}}>No environments found.</Message> }

                { (this.state.loading) && <P style={{marginLeft: "14px", marginTop: "19px", position: 'relative'}}><WaitSpinner size="medium" /><span style={{position: "absolute", top: "1px", left: '36px'}}>Loading...</span></P> }

                { environmentFormOpen && (
                    <EnvironmentForm
                        name={this.state.environment.name || ''}
                        appContext={app}
                        mgmt_scheme_host_port={ environmentContent.mgmt_scheme_host_port || '' }
                        splunk_web_uri={environmentContent.splunk_web_uri || '' }
                        username={environmentContent.username || ''}
                        tags={environmentContent.tags || ''}
                        errorMessage={environmentFormErrorMessage}
                        showSpinner={environmentFormShowSpinner}
                        showSave={environmentFormShowSave}
                        mode={environmentFormMode}
                        onRequestClose={this.resetEnvironmentFormState.bind(this)}
                        onRequestSubmit={this.handleEnvironmentFormSubmitRequest.bind(this)}
                        open={environmentFormOpen}
                        appSearchTemplates={this.getCurrentAppContextSearchTemplates()}
                    />
                )}
                { searchFormOpen && <SearchForm
                    name={this.state.search.name || ''}
                    label={searchContent.label || ''}
                    index_id={searchContent.index_link_alternate || ''}
                    lookup_id={searchContent.lookup_link_alternate || ''}
                    inline_search={searchContent.type === 'inline' ? searchContent.search : ''}
                    template_search_id={searchContent.type === 'template' ? searchContent.search : ''}
                    environment_id={searchFormMode === 'create' ? environmentContent.environment_link_alternate :  searchContent.environment_link_alternate}
                    indexes={this.state.indexes || []}
                    lookups={this.state.lookups || []}
                    interval={searchContent.interval || '300'}
                    errorMessage={searchFormErrorMessage}
                    showSpinner={searchFormShowSpinner}
                    showSave={searchFormShowSave}
                    mode={searchFormMode}
                    onRequestClose={this.resetSearchFormState.bind(this)}
                    onRequestSubmit={this.handleSearchFormSubmitRequest.bind(this)}
                    open={searchFormOpen}
                    type={searchContent.type || 'inline'}
                    searchTemplates={this.state.searchTemplates}
                    appsLocal={this.state.appsLocal}
                    appTemplateMapping={this.state.appTemplateMapping}
                /> }

                { environmentDeleteFormOpen && (
                    <ConfirmDialog
                        title="Delete Environment"
                        primaryButtonLabel="Delete"
                        errorMessage={environmentDeleteFormErrorMessage}
                        onRequestClose={this.resetEnvironmentFormState.bind(this)}
                        onRequestSubmit={this.handleEnvironmentDeleteSubmitRequest.bind(this)}
                        open={environmentDeleteFormOpen}
                        showSpinner={environmentDeleteFormShowSpinner}
                        showSave={environmentDeleteFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to delete the following environment and associated searches?</Message>
                        <DL>
                            <DL.Term>Name</DL.Term>
                            <DL.Description>{this.state.environment.name || ''}</DL.Description>
                            <DL.Term>Server</DL.Term>
                            <DL.Description>{ environmentContent.mgmt_scheme_host_port || '' }</DL.Description>
                            <DL.Term>Search(es)</DL.Term>
                            <DL.Description>
                                { this.state.searches[this.state.environment.links.alternate].map(search => (
                                    <P style={{marginBottom: 2}} key={search.content.label}>{search.content.label} <Tooltip content={search.content.search_string} /></P>
                                ))}
                                { !this.state.searches[this.state.environment.links.alternate].length && 'None' }
                            </DL.Description>
                        </DL>
                        <P style={{ fontStyle: 'italic', paddingTop: 10 }}>Note: Indexes are never deleted to ensure no data loss.</P>
                    </ConfirmDialog>
                )}

                { searchDeleteFormOpen && (
                    <ConfirmDialog
                        title="Delete Search"
                        primaryButtonLabel="Delete"
                        open={searchDeleteFormOpen}
                        errorMessage={searchDeleteFormErrorMessage}
                        onRequestClose={this.resetSearchFormState.bind(this)}
                        onRequestSubmit={this.handleSearchDeleteSubmitRequest.bind(this)}
                        showSpinner={searchDeleteFormShowSpinner}
                        showSave={searchDeleteFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to delete the following search?</Message>
                        {this.renderSearchSummary(searchContent.label, searchContent.search_string)}
                        <P style={{fontStyle: 'italic', paddingTop: 10}}>Note: Indexes are never deleted to ensure no data
                            loss.</P>
                    </ConfirmDialog>
                )}

                { searchDisableFormOpen && (
                    <ConfirmDialog
                        title="Disable Search"
                        primaryButtonLabel="Disable"
                        open={searchDisableFormOpen}
                        errorMessage={searchDisableFormErrorMessage}
                        onRequestClose={this.resetSearchFormState.bind(this)}
                        onRequestSubmit={this.handleSearchDisableSubmitRequest.bind(this)}
                        showSpinner={searchDisableFormShowSpinner}
                        showSave={searchDisableFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to disable retrieving data from the following search?</Message>
                        {this.renderSearchSummary(searchContent.label, searchContent.search_string)}
                    </ConfirmDialog>
                )}

                { searchEnableFormOpen && (
                    <ConfirmDialog
                        title="Enable Search"
                        primaryButtonLabel="Enable"
                        open={searchEnableFormOpen}
                        errorMessage={searchEnableFormErrorMessage}
                        onRequestClose={this.resetSearchFormState.bind(this)}
                        onRequestSubmit={this.handleSearchEnableSubmitRequest.bind(this)}
                        showSpinner={searchEnableFormShowSpinner}
                        showSave={searchEnableFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to enable retrieving data from the following search?</Message>
                        {this.renderSearchSummary(searchContent.label, searchContent.search_string)}
                    </ConfirmDialog>
                )}

                { bulkSearchEnableFormOpen && (
                    <ConfirmDialog
                        title="Enable all searches attached to this environment"
                        primaryButtonLabel="Enable"
                        open={bulkSearchEnableFormOpen}
                        errorMessage={bulkSearchEnableFormErrorMessage}
                        onRequestClose={this.resetEnvironmentFormState.bind(this)}
                        onRequestSubmit={this.handleBulkSearchEnableSubmitRequest.bind(this)}
                        showSpinner={bulkSearchEnableFormShowSpinner}
                        showSave={bulkSearchEnableFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to enable the following { this.state.searches[this.state.environment.links.alternate].length } searches?</Message>
                        { this.state.searches[this.state.environment.links.alternate].map(search => (
                            this.renderSearchSummary(search.content.label, search.content.search_string)
                        ))}
                    </ConfirmDialog>
                )}

                { bulkSearchDisableFormOpen && (
                    <ConfirmDialog
                        title="Disable all searches attached to this environment"
                        primaryButtonLabel="Disable"
                        open={bulkSearchDisableFormOpen}
                        errorMessage={bulkSearchDisableFormErrorMessage}
                        onRequestClose={this.resetEnvironmentFormState.bind(this)}
                        onRequestSubmit={this.handleBulkSearchDisableSubmitRequest.bind(this)}
                        showSpinner={bulkSearchDisableFormShowSpinner}
                        showSave={bulkSearchDisableFormShowSave}
                    >
                        <Message type="warning">Are you sure you want to disable the following { this.state.searches[this.state.environment.links.alternate].length } searches?</Message>
                        { this.state.searches[this.state.environment.links.alternate].map(search => (
                            this.renderSearchSummary(search.content.label, search.content.search_string)
                        ))}
                    </ConfirmDialog>
                )}

            </div>
        );
    }
}

export default MothershipComponent;
