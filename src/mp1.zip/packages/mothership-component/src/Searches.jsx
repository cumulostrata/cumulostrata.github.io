 import PropTypes from 'prop-types';
import ChevronDown from '@splunk/react-icons/ChevronDown';
import Dropdown from '@splunk/react-ui/Dropdown';
import DL from '@splunk/react-ui/DefinitionList';
import External from '@splunk/react-icons/External';
import Heading from '@splunk/react-ui/Heading';
import Link from '@splunk/react-ui/Link';
import Menu from '@splunk/react-ui/Menu';
import P from '@splunk/react-ui/Paragraph';
import Line from '@splunk/react-sparkline/Line';
import Table from '@splunk/react-ui/Table';
import { createURL } from '@splunk/splunk-utils/url';
import { app } from '@splunk/splunk-utils/config';
import moment from '@splunk/moment';
import {bytesToFileSize} from '@splunk/ui-utils/format';
import React, { Component } from 'react';
import { abbreviateNumber } from '@splunk/ui-utils/format';
import Check from '@splunk/react-icons/Check';
import Lock from '@splunk/react-icons/Lock';
import Tooltip from '@splunk/react-ui/Tooltip';
import { normalizeBoolean } from '@splunk/ui-utils/boolean';
import InfoPopover from './InfoPopover';
import { adhocSearch, editIndex, searchInputlookup, searchIndex, editLookup, manager } from './url';

class Searches extends Component {
    static propTypes = {
        /**
         * A function that will be called when a edit action menu item is called for a search.
         *
         */
        onRequestEdit: PropTypes.func,
        /**
         * A function that will be called when a bump action menu item is called for a search.
         *
         */
        onRequestBump: PropTypes.func,
        /**
         * A function that will be called when a delete action menu item is called for a search.
         *
         */
        onRequestDelete: PropTypes.func,
        /**
         * A function that will be called when a disable action menu item is called for a search.
         *
         */
        onRequestEnable: PropTypes.func,
        /**
         * A function that will be called when a enable action menu item is called for a search.
         *
         */
        onRequestDisable: PropTypes.func,
        /** The splunkd entry array value returned from the REST API */
        searches: PropTypes.array,
    };


    static defaultProps = {
        onRequestEdit() {},
        onRequestBump() {},
        onRequestDelete() {},
        onRequestEnable() {},
        onRequestDisable() {},
    };


    handleFormEditRequest = (e, entry) => {
        this.props.onRequestEdit(e, entry);
    };


    handleBumpRequest = (e, entry) => {
        this.props.onRequestBump(e, entry);
    };


    handleDialogDeleteRequest = (e, entry) => {
        this.props.onRequestDelete(e, entry);
    };


    handleDialogEnableRequest = (e, entry) => {
        this.props.onRequestEnable(e, entry);
    };


    handleDialogDisableRequest = (e, entry) => {
        this.props.onRequestDisable(e, entry);
    };


    render() {
        const toggle = <Link>Edit <ChevronDown /></Link>;
        const handleFormEditRequest = this.handleFormEditRequest;
        function getExpansionRow(entry) {
            return (
                <Table.Row key={`${entry.name}-expansion`}>
                    <Table.Cell colSpan={10}>
                        <Heading level={3}>
                            Search
                            &nbsp;
                            <Link
                                onClick={(e) => handleFormEditRequest(e, entry)}
                                style={{ fontWeight: 'normal', fontSize: 14 }}
                            >
                                Edit
                            </Link>
                        </Heading>
                        <DL>
                            <DL.Term>String</DL.Term>
                            <DL.Description>
                                <pre style={{ margin: 0, whiteSpace: 'pre-wrap', display: 'inline' }}>{entry.content.search_string || 'N/A'}</pre>
                            </DL.Description>
                            <DL.Term>Type</DL.Term>
                            <DL.Description>
                                {entry.content.type || 'N/A'}
                            </DL.Description>
                            <DL.Term>Persistence</DL.Term>
                            <DL.Description>
                                {entry.content.report_search === "1" &&
                                    <P>
                                        <Link
                                            to={searchInputlookup(entry.content.lookup_name)}
                                        >
                                            CSV Lookup
                                        </Link>
                                        &nbsp;
                                        <Tooltip content="Transforming search results (report search) are written to a csv loopup file. For every scheduled interval, the existing csv lookup will be replaced new results (no archival)." />
                                    </P>
                                }
                                {entry.content.report_search === "0" &&
                                    <P>
                                        <Link
                                            to={searchIndex(entry.content.index)}
                                        >
                                            Index
                                        </Link>
                                        &nbsp;
                                        <Tooltip content="Non-transforming search results (event search) are written to indices. For every scheduled interval, events are appended to an index (archived) but overlap of events may occur." />
                                    </P>
                                }
                                {entry.content.report_search === "" &&
                                    <P>N/A</P>
                                }
                            </DL.Description>
                        </DL>

                        <Heading level={3}>
                            Saved Search
                            &nbsp;
                            <Link
                                style={{ fontWeight: 'normal', fontSize: 14 }}
                                to={createURL(`/app/${app}/report?s=${entry.content.savedsearch_link_alternate}`)}
                                openInNewContext
                            >
                                Edit
                            </Link>
                        </Heading>
                        <DL>
                            <DL.Term>Name</DL.Term>
                            <DL.Description>{entry.content.savedsearch_link_alternate.split('/').slice(-1)[0]}</DL.Description>
                            <DL.Term>Cron Schedule</DL.Term>
                            <DL.Description>
                                {entry.content.cron_schedule || 'N/A'}
                            </DL.Description>
                        </DL>

                        <Heading level={3}>
                            Index
                            &nbsp;
                            {entry.content.index &&
                                <Link
                                    style={{ fontWeight: 'normal', fontSize: 14 }}
                                    to={editIndex(entry.content.index)}
                                    openInNewContext
                                >
                                    Edit
                                </Link>
                            }
                        </Heading>
                        <DL>
                            <DL.Term>Name</DL.Term>
                            <DL.Description>
                                {entry.content.index || 'N/A'}
                            </DL.Description>
                            <DL.Term>Event Count</DL.Term>
                            <DL.Description>
                                {!isNaN(entry.content.index_total_event_count) ? (
                                    <Link to={createURL(`/app/${app}/search?q=search%20index%3D%22${entry.content.index}%22&display.page.search.mode=verbose&dispatch.sample_ratio=1&earliest=-24h%40h&latest=now`)} title="View Events" openInNewContext>
                                        {abbreviateNumber(entry.content.index_total_event_count)}
                                    </Link>
                                    ) : (
                                    'N/A'
                                )}
                            </DL.Description>
                            <DL.Term>Latest Event</DL.Term>
                            <DL.Description>
                                {entry.content.index_event_max_time ? (
                                    <span>
                                        {moment.newSplunkTime({time: entry.content.index_event_max_time}).fromNow()}
                                        &nbsp;
                                        <Tooltip content={moment.newSplunkTime({time: entry.content.index_event_max_time}).splunkFormat('lls')} />
                                    </span>
                                    ) : (
                                    'N/A'
                                )}
                            </DL.Description>
                            <DL.Term>Earliest Event</DL.Term>
                            <DL.Description>
                                {entry.content.index_event_min_time ? (
                                    <span>
                                        {moment.newSplunkTime({time: entry.content.index_event_min_time}).fromNow()}
                                        &nbsp;
                                        <Tooltip content={moment.newSplunkTime({time: entry.content.index_event_min_time}).splunkFormat('lls')} />
                                    </span>
                                    ) : (
                                    'N/A'
                                )}
                            </DL.Description>
                            <DL.Term>Size</DL.Term>
                            <DL.Description>
                                {!isNaN(entry.content.index_current_db_size_mb) ? (
                                    bytesToFileSize(entry.content.index_current_db_size_mb * 1000000)
                                    ) : (
                                    'N/A'
                                )}
                            </DL.Description>
                        </DL>

                        <Heading level={3}>
                            HTTP Event Collector (HEC)
                            &nbsp;
                            <Link
                                style={{ fontWeight: 'normal', fontSize: 14 }}
                                to={manager('http-eventcollector')}
                                openInNewContext
                            >
                               Edit
                            </Link>
                        </Heading>
                        <DL>
                            <DL.Term>Name</DL.Term>
                            <DL.Description>{ (entry.content.hec_token_name || 'N/A').replace(/^http:\/\//, '') }</DL.Description>
                            <DL.Term>Token</DL.Term>
                            <DL.Description>{entry.content.hec_token_value || 'N/A' }</DL.Description>
                            <DL.Term>Token Status</DL.Term>
                            <DL.Description>
                                {entry.content.hec_global_disabled &&
                                    <span><Lock style={{ color: 'red' }}/> Global HEC Disabled</span>
                                }
                                {!entry.content.hec_global_disabled && !normalizeBoolean(entry.content.hec_token_enabled || false) &&
                                    <span><Check style={{ color: 'green' }}/> Enabled</span>
                                }
                                {!entry.content.hec_global_disabled && normalizeBoolean(entry.content.hec_token_enabled || false) &&
                                    <span><Lock style={{ color: 'red' }}/> Disabled</span>
                                }
                                &nbsp;

                            </DL.Description>
                        </DL>

                        <Heading level={3}>
                            Lookup
                            &nbsp;
                            <Link
                                style={{ fontWeight: 'normal', fontSize: 14 }}
                                to={editLookup(entry.content.lookup_name)}
                                openInNewContext
                            >
                                Edit
                            </Link>
                        </Heading>
                          <DL>
                              <DL.Term>Name</DL.Term>
                              <DL.Description>
                                  {entry.content.lookup_name}
                              </DL.Description>
                          </DL>
                    </Table.Cell>
                </Table.Row>
            );
        }
        return (
            <Table stripeRows rowExpansion="multi" outerStyle={{marginBottom: 20}}>
                <Table.Head>
                    <Table.HeadCell>Label</Table.HeadCell>
                    <Table.HeadCell>Errors</Table.HeadCell>
                    <Table.HeadCell>Latest Results</Table.HeadCell>
                    <Table.HeadCell>Polling Interval (Sec)</Table.HeadCell>
                    <Table.HeadCell>Last Run</Table.HeadCell>
                    <Table.HeadCell>Next Run</Table.HeadCell>
                    <Table.HeadCell>Search Time (Sec)</Table.HeadCell>
                    <Table.HeadCell>Status</Table.HeadCell>
                    <Table.HeadCell>Actions</Table.HeadCell>
                </Table.Head>
                <Table.Body>
                    { this.props.searches.map(entry => (
                        <Table.Row key={entry.name} expansionRow={getExpansionRow(entry)}>
                            <Table.Cell>{entry.content.label || 'N/A'}</Table.Cell>
                            <Table.Cell>
                                {entry.content.results_count_sparkline && entry.content.results_count_sparkline.constructor == Array ? (
                                    <Line
                                        data={entry.content.results_count_sparkline.slice(1).map(Number)}
                                        showEndDot={true}
                                        endDotRadius={3}
                                        endDotStroke='black'
                                        endDotStrokeWidth={2}
                                        endDotCount={0}
                                        lineColor='black'
                                        fillColor='black'
                                        fillOpacity= {0.1}
                                        height={16}
                                        width={120}
                                        isArea
                                    />
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                            <Table.Cell>
                                { entry.content.results_count || 'N/A' }
                            </Table.Cell>
                            <Table.Cell>
                                {entry.content.interval ? (
                                    entry.content.interval
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                            <Table.Cell>
                                {entry.content.script_run_time ? (
                                    moment.newSplunkTime({ time: entry.content.script_run_time }).fromNow()
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                            <Table.Cell>
                                {entry.content.next_scheduled_time ? (
                                     moment.newSplunkTime({ time: parseInt(entry.content.next_scheduled_time) }).fromNow()
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                            <Table.Cell>
                                {entry.content.job_run_duration ? (
                                    entry.content.job_run_duration / 1000
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                            <Table.Cell>
                                {entry.content.disabled === "True" &&
                                    <span><Lock style={{ color: 'red' }}/> Disabled</span>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "" &&
                                    <span>N/A</span>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "8" &&
                                    <InfoPopover status="error" label="Timeout" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "7" &&
                                    <InfoPopover status="error" label="Error" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "6" &&
                                    <InfoPopover status="error" label="Authentication" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "5" &&
                                    <InfoPopover status="error" label="Network" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "4" &&
                                    <InfoPopover status="error" label="Search Dispatch" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "3" &&
                                    <InfoPopover status="error" label="Lookup" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "2" &&
                                    <InfoPopover status="error" label="HEC" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "1" &&
                                    <InfoPopover status="error" label="Job Cancel" time={entry.content.script_timestamp} transaction={entry.content.script_message}/>
                                }
                                {entry.content.disabled === "False" && entry.content.script_status_code === "0" &&
                                    <span><Check style={{ color: 'green' }}/> Ok</span>
                                }
                            </Table.Cell>
                            <Table.Cell>
                                <Dropdown toggle={toggle}>
                                    <Menu>
                                        <Menu.Item
                                            to={createURL(`/app/${app}/search`, {
                                                q: `index="_internal" source=*/environment_poller_debug.log | transaction guid maxspan=30s | search url="*${ entry.links.alternate }"`,
                                                latest: 'now',
                                                earliest: '-15m',
                                                'display.events.maxLines': '50',
                                            })}
                                            openInNewContext
                                        >
                                            Debug <External/>
                                        </Menu.Item>
                                        <Menu.Item
                                            to={createURL(`/app/${app}/search`, {
                                                q: `index="_internal" log_level="ERROR" SavedSplunker savedsearch_id="*${ entry.content.savedsearch_link_alternate.split('/').slice(-1)[0] }"`,
                                                latest: 'now',
                                                earliest: '-15m',
                                                'display.events.maxLines': '50',
                                            })}
                                            openInNewContext
                                        >
                                            Trace <External/>
                                        </Menu.Item>
                                        <Menu.Item
                                            to={createURL(`/app/${app}/search`, {
                                                q: `index="_internal" source="*/environment_poller_metrics.log" environment_searches_link_alternate="${ entry.links.alternate }"`,
                                                latest: 'now',
                                                earliest: '-15m',
                                            })}
                                            openInNewContext
                                        >
                                            Metrics <External/>
                                        </Menu.Item>
                                        <Menu.Divider />
                                        {entry.content.report_search === "1" &&
                                            <Menu.Item
                                                to={searchInputlookup(entry.content.lookup_name)}
                                                openInNewContext
                                            >
                                                Results <External/>
                                            </Menu.Item>
                                        }
                                        {entry.content.report_search === "0" &&
                                            <Menu.Item
                                                to={searchIndex(entry.content.index)}
                                                openInNewContext
                                            >
                                                Results <External/>
                                            </Menu.Item>
                                        }
                                        {entry.content.report_search !== "" &&
                                            <Menu.Item
                                                to={adhocSearch(entry.content.environment_link_alternate, entry.content.search_string || '', entry.content.report_search==='1')}
                                                openInNewContext
                                            >
                                                Run <External/>
                                            </Menu.Item>
                                        }
                                        <Menu.Divider />
                                        {entry.content.disabled === "False" &&
                                            <Menu.Item onClick={(e) => this.handleBumpRequest(e, entry)}>
                                                Bump <Tooltip content="Disables and renables the associated scripted input resulting in new placement of execution in the queue." />
                                            </Menu.Item>
                                        }
                                        <Menu.Divider />
                                        <Menu.Item onClick={(e) => this.handleFormEditRequest(e, entry)}>
                                            Edit
                                        </Menu.Item>
                                        {entry.content.disabled === "True" ? (
                                            <Menu.Item onClick={(e) => this.handleDialogEnableRequest(e, entry)}>
                                                Enable
                                            </Menu.Item>
                                            ) : (
                                            <Menu.Item onClick={(e) => this.handleDialogDisableRequest(e, entry)}>
                                                Disable
                                            </Menu.Item>
                                        )}
                                        <Menu.Item onClick={(e) => this.handleDialogDeleteRequest(e, entry)}>
                                            Delete
                                        </Menu.Item>
                                    </Menu>
                                </Dropdown>
                            </Table.Cell>
                        </Table.Row>
                    ))}
                </Table.Body>
            </Table>
        );
    }
}

export default Searches;
