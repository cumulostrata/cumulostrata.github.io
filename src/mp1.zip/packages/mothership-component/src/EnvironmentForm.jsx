import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from '@splunk/react-ui/Button';
import ControlGroup from '@splunk/react-ui/ControlGroup';
import Message from '@splunk/react-ui/Message';
import Modal from '@splunk/react-ui/Modal';
import P from '@splunk/react-ui/Paragraph';
import Text from '@splunk/react-ui/Text';
import CollapsiblePanel from '@splunk/react-ui/CollapsiblePanel';
import FormRows from '@splunk/react-ui/FormRows';
import { createDOMID } from '@splunk/ui-utils/id';
import Switch from '@splunk/react-ui/Switch';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';

class EnvironmentForm extends Component {
    static propTypes = {
        /** Open the dialog and overlay. */
        open: PropTypes.bool,
        /**
         * A function that will be called when a close event occurs. The callback will be passed a
         * reason (either 'escapeKey' or 'clickAway') and the event.
         *
         * Generally, this callback should be used to toggle the `open` prop.
         */
        onRequestClose: PropTypes.func,
        /**
         * A function that will be called when a submit is called on the form.
         *
         * Generally, this callback should be used to handle the submission of form values.
         */
        onRequestSubmit: PropTypes.func,
        /**
         * Optional name for form.
         */
        name: PropTypes.string,
        /**
         * Optional appContext for form.
         */
        appContext: PropTypes.string,
        /**
         * Optional mgmt_scheme_host_port string for form.
         */
        mgmt_scheme_host_port: PropTypes.string,
         /**
         * Optional splunk_web_uri string for form.
         */
        splunk_web_uri: PropTypes.string,
        /**
         * Optional username string for form.
         */
        username: PropTypes.string,
        /**
         * Optional password string for form.
         */
        password: PropTypes.string,
        /**
         * Optional tags string for form.
         */
        tags: PropTypes.string,
        /**
         * Optional error message.
         */
        errorMessage: PropTypes.string,
        /**
         * Top level control of save spinner
         */
        showSpinner: PropTypes.bool,
        /**
         * Top level control of save button
         */
        showSave: PropTypes.bool,
        /**
         * Mode, one of create or edit (disabling certain features)
         */
        mode: PropTypes.oneOf(['create', 'edit']),
        /**
         * The splunkd list of environment_search_templates returned from the REST API for current app context.
         */
        appSearchTemplates: PropTypes.array,
    };


    static defaultProps = {
        open: false,
        appContext: '',
        onRequestClose() {},
        onRequestSubmit() {},
        name: '',
        mgmt_scheme_host_port: '',
        splunk_web_uri: '',
        username: '',
        password: '',
        tags: '',
        errorMessage: '',
        mode: 'create',
        appSearchTemplates: [],
        showSpinner: false,
        showSave: true,
    };


    constructor(props, context) {
        super(props, context);

        this.state = {
            name: this.props.name,
            mgmt_scheme_host_port: this.props.mgmt_scheme_host_port,
            splunk_web_uri: this.props.splunk_web_uri,
            username: this.props.username,
            password: this.props.password,
            tags: this.props.tags.split(','),
            tagRows: this.renderRows(this.props.tags.split(',')),
            applyAppSearchTemplates: false,
            appSearchTemplates: this.props.appSearchTemplates,
        };
    };


    renderRows(tags) {
        const tagRows = [];

        if (tags) {
            for (let tagIndex = 0; tagIndex < tags.length; tagIndex++) {
                tagRows.push(
                    <FormRows.Row
                        index={tagIndex}
                        key={createDOMID()}
                        onRequestRemove={this.handleRequestRemoveTag}
                    >
                        <Text defaultValue={tags[tagIndex]} name={tagIndex} onChange={this.handleTagChange} />
                    </FormRows.Row>
                );
            }
        } else {
            tagRows.push(
                <FormRows.Row index={0} key="0" onRequestRemove={this.handleRequestRemoveTag}>
                    <Text placeholder="Add a tag" name={0} onChange={this.handleTagChange} />
                </FormRows.Row>
            );
        }
        return tagRows;
    };


    handleRequestClose = e => {
        this.props.onRequestClose(e);
    };


    handleRequestSubmit = e => {
        this.props.onRequestSubmit(e, Object.assign({}, this.state));
    };


    handleRequestDataOnChange = (e, data) => {
        if (Object.prototype.hasOwnProperty.call(this.state, data.name)) {
            const state = {};
            state[data.name] = data.value;
            this.setState(state);
        }
    };


    handleRequestAddTag = () => {
        var tags = this.state.tags;
        tags.push(undefined);

        this.setState({ tags });

        this.setState({
            tagRows: FormRows.addRow(
                <FormRows.Row
                    index={this.state.tagRows.length}
                    key={createDOMID()}
                    onRequestRemove={this.handleRequestRemoveTag}
                >
                    <Text placeholder="Add a tag" name={this.state.tagRows.length} onChange={this.handleTagChange} />
                </FormRows.Row>,
                this.state.tagRows
            ),
        });
    };


    handleRequestMoveTag = ({ fromIndex, toIndex }) => {
        var tags = this.state.tags;

        var element = tags[fromIndex];
        tags.splice(fromIndex, 1);
        tags.splice(toIndex, 0, element);

        this.setState({ tags });

        this.setState({ tagRows: this.renderRows(tags)});
    };


    handleRequestRemoveTag = (e, { index }) => {
        var tags = this.state.tags;
        tags.splice(index, 1);

        this.setState({ tags });

        this.setState({
            tagRows: FormRows.removeRow(index, this.state.tagRows),
        });
    };


    handleTagChange  = (e, { value, name }) => {
        var tags = this.state.tags;
        tags[name] = value;

        this.setState({ tags })
    };


    handleApplySearchTemplates = (e, { value }) => {
        const newState = {};
        newState[value] = !this.state[value];
        this.setState(newState);
    };


    render() {
        return (
            <Modal
                onRequestClose={this.handleRequestClose}
                open={this.props.open}
            >
                <Modal.Header title="Environment Setup" onRequestClose={this.handleRequestClose}/>
                <Modal.Body style={{ width: 700 }} >
                    { this.props.errorMessage && <Message type="error">{this.props.errorMessage}</Message> }
                    <ControlGroup label="* Name">
                        <Text name="name" value={this.state.name} disabled={this.props.mode==='edit'} autoFocus={this.props.mode==='create'} onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    <ControlGroup
                        label="* Management Server"
                        help="Splunk REST server URI (HTTPS only)."
                        tooltip="Ex., https//splunkservername.mydomain:8089"
                    >
                        <Text name="mgmt_scheme_host_port" value={this.state.mgmt_scheme_host_port} disabled={this.props.mode==='edit'} onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    <ControlGroup
                        label="Web Server"
                        help="The URI that links to the associated Splunk web page."
                        tooltip="Ex., https//splunkservername.mydomain:8089"
                    >
                        <Text name="splunk_web_uri" value={this.state.splunk_web_uri} onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    <ControlGroup
                        label="* Username"
                        help="Splunk login username."
                    >
                        <Text name="username" value={this.state.username}  autoFocus={this.props.mode==='edit'} autoComplete={false} onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    <ControlGroup
                        label="* Password"
                        help="Splunk login password."
                        tooltip="Passwords are stored encrypted."
                    >
                        <Text type="password" name="password" value={this.state.password} placeholder="xxxxxx" autoComplete={false} onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    {(this.props.mode ==='create') &&
                        <ControlGroup
                            label="Search Templates"
                            help="Create environment searches using the current apps Search Templates (i.e. environment_search_templates.conf) and assign to this environment."
                            tooltip={!this.props.appSearchTemplates.length ? 'This app has no Search Templates to apply. See environment_search_templates.conf.spec.' : ''}
                        >
                            <Switch
                                value="applyAppSearchTemplates"
                                onClick={this.handleApplySearchTemplates}
                                selected={this.state.applyAppSearchTemplates}
                                appearance="toggle"
                                disabled={!this.props.appSearchTemplates.length}
                            >
                                Apply
                            </Switch>
                        </ControlGroup>
                    }
                    {(this.props.mode ==='edit') ? <CollapsiblePanel defaultOpen title='Add or remove tags' style={{paddingBottom: 10}}>
                        <FormRows
                            onRequestAdd={this.handleRequestAddTag}
                            onRequestMove={this.handleRequestMoveTag}
                            style={{ width: 300 }}
                        >
                            {this.state.tagRows}
                        </FormRows>
                    </CollapsiblePanel> :
                    <CollapsiblePanel title='Add or remove tags' style={{paddingBottom: 10}}>
                        <FormRows
                            onRequestAdd={this.handleRequestAddTag}
                            onRequestMove={this.handleRequestMoveTag}
                            style={{ width: 300 }}
                        >
                            {this.state.tagRows}
                        </FormRows>
                    </CollapsiblePanel>
                    }
                    <P>
                        * Indicates required field.
                    </P>
                </Modal.Body>
                <Modal.Footer>
                    <Button appearance="secondary" label="Cancel" onClick={this.handleRequestClose} />
                    { this.props.showSave && <Button appearance='primary' label='Save' onClick={this.handleRequestSubmit}/>}
                    { this.props.showSpinner && <WaitSpinner size="medium" style={{paddingLeft: 50, paddingRight: 50}} /> }
                </Modal.Footer>
            </Modal>
        );
    }
}
export default EnvironmentForm;
