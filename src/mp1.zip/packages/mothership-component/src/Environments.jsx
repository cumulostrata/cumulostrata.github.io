import Button from '@splunk/react-ui/Button';
import ChevronDown from '@splunk/react-icons/ChevronDown';
import ColumnLayout from '@splunk/react-ui/ColumnLayout';
import Dropdown from '@splunk/react-ui/Dropdown';
import DL from '@splunk/react-ui/DefinitionList';
import Heading from '@splunk/react-ui/Heading';
import External from '@splunk/react-icons/External';
import Refresh from '@splunk/react-icons/Refresh';
import Link from '@splunk/react-ui/Link';
import Message from '@splunk/react-ui/Message';
import Menu from '@splunk/react-ui/Menu';
import P from '@splunk/react-ui/Paragraph';
import Line from '@splunk/react-sparkline/Line';
import Table from '@splunk/react-ui/Table';
import Check from '@splunk/react-icons/Check';
import { createURL } from '@splunk/splunk-utils/url';
import { app } from '@splunk/splunk-utils/config';
import PropTypes from 'prop-types'
import React, { Component } from 'react';
import Searches from './Searches';
import InfoPopover from './InfoPopover';
import { adhocSearch } from './url';

class Environments extends Component {
    static propTypes = {
        /**
         * A function that will be called when a delete action menu item is called for an environment.
         *
         */
        onRequestSearchRefresh: PropTypes.func,
        /**
         * A function that will be called when a create new search action is called for a search.
         *
         */
        onRequestSearchCreate: PropTypes.func,
        /**
         * A function that will be called when a edit action menu item is called for a search.
         *
         */
        onRequestSearchEdit: PropTypes.func,
        /**
         * A function that will be called when a bump action menu item is called for a search.
         *
         */
        onRequestSearchBump: PropTypes.func,
        /**
         * A function that will be called when a delete action menu item is called for a search.
         *
         */
        onRequestSearchDelete: PropTypes.func,
        /**
         * A function that will be called when a enable action menu item is called for a search.
         *
         */
        onRequestSearchEnable: PropTypes.func,
        /**
         * A function that will be called when a disable action menu item is called for a search.
         *
         */
        onRequestSearchDisable: PropTypes.func,
        /**
         * A function that will be called when a edit action menu item is called for an environment.
         *
         */
        onRequestEnvironmentEdit: PropTypes.func,
        /**
         * A function that will be called when a delete action menu item is called for an environment.
         *
         */
        onRequestEnvironmentDelete: PropTypes.func,
        /**
         * A function that will be called when an enable all searches action menu item is called for an environement.
         *
         */
        onRequestBulkSearchEnable: PropTypes.func,
        /**
         * A function that will be called when a disable all searches action menu item is called for an environment.
         *
         */
        onRequestBulkSearchDisable: PropTypes.func,
        /** The splunkd entry array value returned from the REST API */
        environments: PropTypes.array,
        /** The splunkd map of searches to environments value returned from the REST API */
        searches: PropTypes.object,
    };


    static defaultProps = {
        onRequestEnvironmentEdit() {},
        onRequestEnvironmentDelete() {},
        onRequestBulkSearchEnable() {},
        onRequestBulkSearchDisable() {},
        onRequestSearchRefresh() {},
        onRequestSearchCreate() {},
        onRequestSearchEdit() {},
        onRequestSearchBump() {},
        onRequestSearchDelete() {},
        onRequestSearchDisable() {},
        onRequestSearchEnable() {},
        onRequestAppInstall() {},
    };


    handleRequestSearchRefresh = (e) => {
        this.props.onRequestSearchRefresh(e);
    };


    handleRequestSearchCreate = (e, search) => {
        this.props.onRequestSearchCreate(e, search);
    };


    handleRequestSearchEdit = (e, search) => {
        this.props.onRequestSearchEdit(e, search);
    };


     handleRequestSearchBump = (e, search) => {
        this.props.onRequestSearchBump(e, search);
    };


    handleRequestSearchDelete = (e, search) => {
        this.props.onRequestSearchDelete(e, search);
    };


    handleRequestSearchEnable = (e, search) => {
        this.props.onRequestSearchEnable(e, search);
    };


    handleRequestSearchDisable = (e, search) => {
        this.props.onRequestSearchDisable(e, search);
    };


    handleRequestBulkSearchEnable = (e, entry) => {
        this.props.onRequestBulkSearchEnable(e, entry);
    };


    handleRequestBulkSearchDisable = (e, entry) => {
        this.props.onRequestBulkSearchDisable(e, entry);
    };


    handleRequestEnvironmentEdit = (e, entry, editTags) => {
        this.props.onRequestEnvironmentEdit(e, entry, editTags);
    };


    handleRequestEnvironmentDelete = (e, entry) => {
        this.props.onRequestEnvironmentDelete(e, entry);
    };


    getAllEnvironmentFailedSearches = () => {
        let allEnvironmentFailedSearches = {};

        for (let i=0; i < this.props.environments.length; i++) {
            let environmentFailedSearches = {};
            let environmentLinkAlternate = this.props.environments[i].links.alternate;
            environmentFailedSearches = {};

            for (let i=0; i < this.props.searches[environmentLinkAlternate].length; i++) {
                let search = this.props.searches[environmentLinkAlternate][i];
                let statusCode = search.content['script_status_code'];

                if (["1", "2", "3", "4", "8"].includes(statusCode)) {
                    environmentFailedSearches['script_message'] = search.content['script_message'];
                    environmentFailedSearches['script_timestamp'] = search.content['script_timestamp'];
                }
            }
            allEnvironmentFailedSearches[environmentLinkAlternate] = environmentFailedSearches
        }
        return allEnvironmentFailedSearches;
    };


    render() {
        const toggleButton = (
            <Link>Edit <ChevronDown/></Link>
        );
        const linkColumnStyle = { overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 340 };
        const allEnvironmentFailedSearches = this.getAllEnvironmentFailedSearches();
        function getExpansionRow(environment, searches) {
            return (
                <Table.Row key={`${environment.name}-expansion`}>
                    <Table.Cell colSpan={6}>
                        <ColumnLayout>
                            <ColumnLayout.Row>
                                <ColumnLayout.Column span={6}>
                                    <Heading level={2} style={{marginTop: 5}}>
                                        Environment&nbsp;
                                        <Link
                                            style={{ fontWeight: 'normal', fontSize: 14 }}
                                            onClick={(e) => this.handleRequestEnvironmentEdit(e, environment, true)}
                                        >
                                            Edit
                                        </Link>
                                    </Heading>
                                    <DL>
                                        <DL.Term>Username</DL.Term>
                                        <DL.Description>{environment.content.username}</DL.Description>
                                        <DL.Term>Tags</DL.Term>
                                        <DL.Description>
                                            <P>
                                                { environment.content.tags && ((environment.content.tags).split(',')).map(entry => (
                                                        <Button disabled appearance="secondary" label={entry} />
                                                    )
                                                )}
                                                { !environment.content.tags &&
                                                    <span>N/A</span>
                                                }
                                            </P>
                                        </DL.Description>
                                    </DL>
                                    <Heading level={2} style={{marginTop: 5}}>
                                        Searches&nbsp;
                                        {searches.length>0 && <Link title="Refresh"
                                                                  onClick={this.handleRequestSearchRefresh}><Refresh/></Link>}
                                    </Heading>
                                    <P>
                                        {searches.length} search{searches.length !== 1 ? 'es' : ''}.
                                    </P>
                                </ColumnLayout.Column>
                                <ColumnLayout.Column style={{textAlign: 'right'}} span={6}>
                                    <Button label='New Search'
                                            onClick={(e) => this.handleRequestSearchCreate(e, environment)}
                                            size="small"/>
                                </ColumnLayout.Column>
                            </ColumnLayout.Row>
                        </ColumnLayout>
                        <Searches
                            searches={searches}
                            onRequestEdit={this.handleRequestSearchEdit}
                            onRequestBump={this.handleRequestSearchBump}
                            onRequestDelete={this.handleRequestSearchDelete}
                            onRequestEnable={this.handleRequestSearchEnable}
                            onRequestDisable={this.handleRequestSearchDisable}
                        />
                        {!searches.length &&
                        <Message type="error" style={{margin: "10px"}}>No searches found.</Message>}
                    </Table.Cell>
                </Table.Row>
            );
        }
        return (
            <Table stripeRows rowExpansion="multi">
                <Table.Head>
                    <Table.HeadCell>Name</Table.HeadCell>
                    <Table.HeadCell>Management Server</Table.HeadCell>
                    <Table.HeadCell>Web Server</Table.HeadCell>
                    <Table.HeadCell>Errors</Table.HeadCell>
                    <Table.HeadCell>Status</Table.HeadCell>
                    <Table.HeadCell>Actions</Table.HeadCell>
                </Table.Head>
                <Table.Body>
                    { this.props.environments.map(entry => (
                        <Table.Row key={entry.name} expansionRow={getExpansionRow.bind(this, entry, this.props.searches[entry.links.alternate] || [])()}>
                            <Table.Cell>{entry.name}</Table.Cell>
                            <Table.Cell style={ linkColumnStyle }>
                                <Link style={{ whiteSpace: 'nowrap' }} to={entry.content.mgmt_scheme_host_port} openInNewContext>{entry.content.mgmt_scheme_host_port}</Link>
                            </Table.Cell>
                            <Table.Cell style={ linkColumnStyle }>
                                {entry.content.splunk_web_uri ? (
                                    <Link style={{ whiteSpace: 'nowrap' }} to={entry.content.splunk_web_uri} openInNewContext>{entry.content.splunk_web_uri}</Link>
                                    ) : (
                                    'N/A'
                                )}
                            </Table.Cell>
                             <Table.Cell>
                                 {entry.content.network_error_count_sparkline && entry.content.network_error_count_sparkline.constructor == Array &&
                                 < Line
                                     data={entry.content.network_error_count_sparkline.slice(1).map(Number)}
                                     showEndDot={true}
                                     endDotRadius={3}
                                     endDotStroke='black'
                                     endDotStrokeWidth={2}
                                     endDotCount={0}
                                     lineColor='black'
                                     fillColor='black'
                                     fillOpacity= {0.1}
                                     height={16}
                                     width={120}
                                     isArea
                                     />
                                 }
                                 {entry.content.network_error_count_sparkline &&  entry.content.network_error_count_sparkline.constructor != Array &&
                                    <Line
                                        data={["##__SPARKLINE__##", "0", "0"].slice(1).map(Number)}
                                        showEndDot={true}
                                        endDotRadius={3}
                                        endDotStroke='black'
                                        endDotStrokeWidth={2}
                                        lineColor='black'
                                        endDotCount={0}
                                        height={16}
                                        width={120}
                                    />
                                }
                                 {entry.content.network_error_count_sparkline === '' &&
                                     <span>N/A</span>
                                 }
                            </Table.Cell>
                            <Table.Cell>
                                {!["0", "1", "2", "3", "4", "5", "6", "7", "8"].includes(entry.content.most_recent_environment_status) || Object.entries(this.props.searches[entry.links.alternate]).length === 0 &&
                                    <span>N/A</span>
                                }
                                {/* Most recent status is ok child search errors, and list of searches is not empty */}
                                {"0" === entry.content.most_recent_environment_status && Object.entries(allEnvironmentFailedSearches[entry.links.alternate]).length === 0  && Object.entries(this.props.searches[entry.links.alternate]).length != 0 &&
                                    <span style={{ whiteSpace: 'nowrap' }}><Check style={{color: "green"}}/> Ok</span>
                                }
                                {/* Most recent environment status could be bad, but coming from a deleted broken environment so irrelevant, not an environment level error code, no child search errors */}
                                {"0" != entry.content.most_recent_environment_status && !["5", "6", "7"].includes(entry.content.most_recent_environment_status) && Object.entries(allEnvironmentFailedSearches[entry.links.alternate]).length === 0 && Object.entries(this.props.searches[entry.links.alternate]).length != 0 &&
                                    <span style={{ whiteSpace: 'nowrap' }}><Check style={{color: "green"}}/> Ok</span>
                                }
                                { Object.entries(allEnvironmentFailedSearches[entry.links.alternate]).length != 0 &&
                                    <InfoPopover status="warn" label="Warning" time={allEnvironmentFailedSearches[entry.links.alternate]['timestamp']} transaction={allEnvironmentFailedSearches[entry.links.alternate]['script_message']}/>
                                }
                                {"5" === entry.content.most_recent_environment_status && Object.entries(this.props.searches[entry.links.alternate]).length != 0 &&
                                    <InfoPopover status="error" label="Network" time={entry.content.most_recent_environment_timestamp} transaction={entry.content.most_recent_environment_message}/>
                                }
                                {"6" === entry.content.most_recent_environment_status && Object.entries(this.props.searches[entry.links.alternate]).length != 0 &&
                                    <InfoPopover status="error" label="Authentication" time={entry.content.most_recent_environment_timestamp} transaction={entry.content.most_recent_environment_message}/>
                                }
                                {"7" === entry.content.most_recent_environment_status && Object.entries(this.props.searches[entry.links.alternate]).length != 0 &&
                                    <InfoPopover status="error" label="Error" time={entry.content.most_recent_environment_timestamp} transaction={entry.content.most_recent_environment_message}/>
                                }
                            </Table.Cell>
                            <Table.Cell>
                                <Dropdown toggle={toggleButton}>
                                    <Menu>
                                        <Menu.Item
                                            to={createURL(`/app/${app}/search`, {
                                                q: `index="_internal" source=*/environment_poller_debug.log | transaction guid maxspan=30s | search url="${ entry.links.alternate }"`,
                                                latest: 'now',
                                                earliest: '-15m',
                                                'display.events.maxLines': '50',
                                            })}
                                            openInNewContext
                                        >
                                            Debug <External/>
                                        </Menu.Item>
                                        <Menu.Item
                                            to={createURL(`/app/${app}/search`, {
                                                q: `index="_internal" source="*/environment_poller_metrics.log" environment_link_alternate="${ entry.links.alternate }"`,
                                                latest: 'now',
                                                earliest: '-15m',
                                            })}
                                            openInNewContext
                                        >
                                            Metrics <External/>
                                        </Menu.Item>
                                        <Menu.Divider />
                                        { this.props.searches[entry.links.alternate].length && (
                                            <Menu.Item onClick={(e) => this.handleRequestBulkSearchEnable(e, entry, false)}>
                                                Enable All Searches
                                            </Menu.Item>
                                        )}
                                        { this.props.searches[entry.links.alternate].length && (
                                            <Menu.Item onClick={(e) => this.handleRequestBulkSearchDisable(e, entry, false)}>
                                                Disable All Searches
                                            </Menu.Item>
                                        )}
                                        { this.props.searches[entry.links.alternate].length && (
                                            <Menu.Divider />
                                        )}
                                        <Menu.Item onClick={(e) => this.handleRequestEnvironmentEdit(e, entry, false)}>
                                            Edit
                                        </Menu.Item>
                                        <Menu.Item onClick={(e) => this.handleRequestEnvironmentDelete(e, entry)}>
                                            Delete
                                        </Menu.Item>
                                    </Menu>
                                </Dropdown>
                            </Table.Cell>
                        </Table.Row>
                    ))}
                </Table.Body>
            </Table>
        );
    }
}

export default Environments;
