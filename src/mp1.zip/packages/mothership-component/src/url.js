import { app } from '@splunk/splunk-utils/config';
import { createURL } from '@splunk/splunk-utils/url';

export function adhocSearch(environmentId, search, isReportSearch) {
  const path = `/app/${app}/search`;
  if (isReportSearch) {
      const q = `| \`adhocsearch("${environmentId}", "${search}")\``;
      return createURL(path, {q});
  }
  const q = `| \`adhocsearch_raw("${environmentId}", "${search}")\``;
  return createURL(path, {q});
}

export function editIndex(name) {
    const path = `/manager/${app}/data/indexes/${name}`;
    const q = {
        uri: `/servicesNS/nobody/${app}/data/indexes/${name}`,
        ns: app,
        action: 'edit',
    };
    return createURL(path, q);
}


export function searchInputlookup(name) {
    const path = `/app/${app}/search`;
    const q = `| inputlookup ${name}`;
    return createURL(path, {q});
}


export function searchIndex(name) {
  const path = `/app/${app}/search`;
  const q = `index=${name}`;
  return createURL(path, {q});
}


export function editLookup(name) {
  const path = `/manager/permissions/${app}/data/lookup-table-files/${name}`;
  const q = {
      uri: `/servicesNS/nobody/${app}/data/lookup-table-files/${name}`,
      manager_cancel_url: `/app/${app}/environments`,
  };
  return createURL(path, q);
}


export function manager(name, q={}) {
  const path = `/manager/${app}/${name}`;
  return createURL(path, q);
}
