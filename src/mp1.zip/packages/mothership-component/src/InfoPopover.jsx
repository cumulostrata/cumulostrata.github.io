import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from '@splunk/react-ui/Button';
import Cancel from '@splunk/react-icons/Cancel';
import Link from '@splunk/react-ui/Link';
import Popover from '@splunk/react-ui/Popover';
import Warning from '@splunk/react-icons/Warning';
import moment from '@splunk/moment';

class InfoPopover extends Component {
    static propTypes = {
        /**
         *  Title for the error.
         */
        label: PropTypes.string,
        /**
         *  Time for the error (ISO Timestamp).
         */
        time: PropTypes.string,
        /**
         *  Transaction for the error.
         */
        transaction: PropTypes.string,
        /**
         *  Status of message.
         */
        status: PropTypes.oneOf(['error', 'warn']),
    };


    constructor(props, context) {
        super(props, context);
        this.state = {
            open: false,
            anchor: null,
        };
    };


    handleMount = component => {
        this.setState({
            anchor: component,
        });
    };


    handleOpen = () => {
        this.setState({
            open: true,
        });
    };


    handleRequestClose = () => {
        this.setState({
            open: false,
        });
    };


    render() {
        const { anchor, open } = this.state;
        const days = moment.newSplunkTime({time: this.props.time}).splunkFormat('L');
        const time = moment.newSplunkTime({time: this.props.time}).splunkFormat('LTMS');
        return (
            <div style={{ whiteSpace: 'nowrap' }}>
                { this.props.status === "error" &&
                    <Cancel style={{ color: 'red' }}/>
                }
                { this.props.status === "warn" &&
                    <Warning style={{ color: 'orange' }}/>
                }
                <Link onClick={this.handleOpen} ref={this.handleMount} style={{paddingLeft: 4}}>{this.props.label}</Link>
                <Popover
                    open={open}
                    anchor={anchor}
                    onRequestClose={this.handleRequestClose}
                    appearance="light"
                >
                    <div style={{ padding: '10px', fontSize: '12px', whiteSpace: 'pre-wrap', wordBreak: 'break-all', fontFamily: 'Splunk Platform Mono,Inconsolata,Consolas,Droid Sans Mono,Monaco,Courier New,Courier,monospace'}}>
                        <table>
                            <tr>
                                <td style={{ verticalAlign: 'top', paddingRight: '10px' }}>
                                    {days}&nbsp;{time}
                                </td>
                                <td style={{ verticalAlign: 'top' }}>{this.props.transaction}</td>
                            </tr>
                        </table>
                    </div>
                </Popover>
            </div>
        );
    }
}

export default InfoPopover;
