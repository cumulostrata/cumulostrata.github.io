import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from '@splunk/react-ui/Button';
import ControlGroup from '@splunk/react-ui/ControlGroup';
import Link from '@splunk/react-ui/Link';
import Message from '@splunk/react-ui/Message';
import Modal from '@splunk/react-ui/Modal';
import Number from '@splunk/react-ui/Number';
import P from '@splunk/react-ui/Paragraph';
import Text from '@splunk/react-ui/Text';
import Tooltip from '@splunk/react-ui/Tooltip';
import CollapsiblePanel from '@splunk/react-ui/CollapsiblePanel';
import RadioList from '@splunk/react-ui/RadioList';
import Select from '@splunk/react-ui/Select';
import { adhocSearch } from './url';
import WaitSpinner from '@splunk/react-ui/WaitSpinner';


class SearchForm extends Component {
    static propTypes = {
        /** Open the dialog and overlay. */
        open: PropTypes.bool,
        /**
         * A function that will be called when a close event occurs. The callback will be passed a
         * reason (either 'escapeKey' or 'clickAway') and the event.
         *
         * Generally, this callback should be used to toggle the `open` prop.
         */
        onRequestClose: PropTypes.func,
        /**
         * A function that will be called when a submit is called on the form.
         *
         * Generally, this callback should be used to handle the submission of form values.
         */
        onRequestSubmit: PropTypes.func,
        /**
         * Optional name for form.
         */
        name: PropTypes.string,
        /**
         * Optional label for form.
         */
        label: PropTypes.string,
        /**
         * Optional inline search string for form.
         */
        inline_search: PropTypes.string,
        /**
         * Optional template search link alternate for form.
         */
        template_search_id: PropTypes.string,
        /**
         * Optional search environment_id.
         */
        environment_id: PropTypes.string,
        /**
         * Optional default interval for form.
         */
        interval: PropTypes.string,
        /**
         * Optional index for form.
         */
        index_id: PropTypes.string,
        /**
         * Optional lookup for form.
         */
        lookup_id: PropTypes.string,
        /**
         * Optional error message.
         */
        errorMessage: PropTypes.string,
        /**
         * Top level control of save spinner
         */
        showSpinner: PropTypes.bool,
        /**
         * Top level control of save button
         */
        showSave: PropTypes.bool,
        /**
         * Mode, one of create or edit (disabling certain features).
         */
        mode: PropTypes.oneOf(['create', 'edit']),
        /**
         * The splunkd list of indexes returned from the REST API.
         */
        indexes: PropTypes.array,
        /**
         * The splunkd list of lookups returned from the REST API.
         */
        lookups: PropTypes.array,
        /**
         * The search type (disabling certain features).
         */
        type: PropTypes.oneOf(['inline', 'template']),
        /**
         * The splunkd list of environment_search_templates returned from the REST API.
         */
        searchTemplates: PropTypes.array,
        /**
         * An ordered list by App Name of apps/local and environment_search_templates returned from the REST API.
         */
        appTemplateMapping: PropTypes.array,
    };


    static defaultProps = {
        open: false,
        onRequestClose() {},
        onRequestSubmit() {},
        name: '',
        label: '',
        inline_search: '',
        template_search_id: '',
        environment_id: '',
        interval: '',
        errorMessage: '',
        mode: 'create',
        index_id: '',
        lookup_id: '',
        indexes: [],
        lookups: [],
        type: 'inline',
        searchTemplates: [],
        appTemplateMapping: [],
        showSpinner: false,
        showSave: true,
    };


    constructor(props, context) {
        super(props, context);
        this.state = {
            name: this.props.name,
            label: this.props.label,
            inline_search: this.props.inline_search,
            template_search_id: this.props.template_search_id,
            interval: this.props.interval,
            index_id: this.props.index_id,
            lookup_id: this.props.lookup_id,
            lookups: this.props.lookups,
            indexes: this.props.indexes,
            type: this.props.type,
        };
    };


    getLabelPlaceHolder = () => {
        if (this.state.type === 'template' && this.state.template_search_id) {
            for (let i=0; i < this.props.searchTemplates.length; i++) {
                const searchTemplate = this.props.searchTemplates[i];
                if (searchTemplate.links.alternate === this.state.template_search_id) {
                    return `Template: ${searchTemplate.name}`;
                }
            }
        }
        return '';
    };


    getNameByLinkAlternate(object_list, link_alternate) {
        for (let i=0; i<object_list.length; i++) {
            let object = object_list[i];
            if (object.links.alternate === link_alternate) {
                return object.name;
            }
        }
        return ''
    };


    handleRequestClose = e => {
        this.props.onRequestClose(e);
    };


    handleRequestSubmit = e => {
        const params = Object.assign({}, this.state);
        // no change in label so remove (deals with layering from template)
        if (params.label===this.props.label) {
            delete params.label;
        }
        this.props.onRequestSubmit(e, params);
    };
    handleRequestDataOnChange = (e, data) => {
        if (Object.prototype.hasOwnProperty.call(this.state, data.name)) {
            const state = {};
            state[data.name] = data.value;
            this.setState(state);
        }
    };


    handleRequestExistingIndex =  (e, { value }) => {
        this.setState({ index_id: value });
    };


    handleRequestExistingLookup =  (e, { value }) => {
        this.setState({ lookup_id: value });
    };


    handleRequestSearchTypeChange = (e, { value }) => {
        if (value != this.props.type) {
            this.setState({type: value, label: ''});
        } else {
            this.setState({type: value, label: this.props.label });
        }
    };


    renderTemplateOptions = () => {
        let appTemplateMapping = this.props.appTemplateMapping;
        let children = [];

        for (let i=0; i < appTemplateMapping.length; i++) {
            children.push(<Select.Heading>{appTemplateMapping[i].appLocal.content.label}</Select.Heading>);
            for (let x=0; x < appTemplateMapping[i].searchTemplates.length; x++) {
                let searchTemplate = appTemplateMapping[i].searchTemplates[x];
                children.push(
                    <Select.Option
                        key={searchTemplate.links.alternate}
                        label={searchTemplate.name}
                        description={searchTemplate.content.search_string}
                        value={searchTemplate.links.alternate}
                    />
                )
            }
        }
        return children
    };


    render() {
        return (
            <Modal
                onRequestClose={this.handleRequestClose}
                open={this.props.open}
            >
                <Modal.Header title='Environment Search' onRequestClose={this.handleRequestClose}/>
                <Modal.Body style={{ width: 700 }} >
                    { this.props.errorMessage && <Message type='error'>{this.props.errorMessage}</Message> }
                    {this.state.type === 'inline' && <ControlGroup label='Label'>
                        <Text name='label' value={this.state.label} autoFocus
                              onChange={this.handleRequestDataOnChange}/>
                    </ControlGroup>
                    }
                    {this.state.type === 'template' && <ControlGroup label='Label'>
                        <Text name='label' value={this.getLabelPlaceHolder()} autoFocus
                              onChange={this.handleRequestDataOnChange} disabled/>
                    </ControlGroup>
                    }
                    <ControlGroup label='* Search' help='SPL to execute on remote machine.'>
                        <RadioList style={{paddingRight: 8}} value={this.state.type} onChange={this.handleRequestSearchTypeChange}>
                            <RadioList.Option value="inline">Inline</RadioList.Option>
                            <RadioList.Option value="template">
                                Template <Tooltip content="Search templates can be created manually using an environment_search_templates.conf. See specifications here: $SPLUNK_HOME/etc/apps/mothership/README/environment_search_templates.spec" />
                            </RadioList.Option>
                        </RadioList>
                        <Text
                            name='inline_search'
                            value={this.state.inline_search}
                            onChange={this.handleRequestDataOnChange}
                            size='small'
                            style={{ display: this.state.type === 'inline' ? '' : 'none' }}
                            rowsMin={3}
                            multiline
                            inline
                        />
                        &nbsp;
                        { this.state.inline_search && (
                            <Link
                                to={adhocSearch(this.props.environment_id, this.state.inline_search, true)}
                                style={{ display: this.state.type === 'inline' ? 'inline' : 'none' }}
                                openInNewContext
                            >
                                Run
                            </Link>
                        )}
                        <Select
                            name='template_search_id'
                            value={this.state.template_search_id || ''}
                            onChange={this.handleRequestDataOnChange}
                            menuStyle={{ width: 350 }}
                            style={{ display: this.state.type === 'template' ? '' : 'none' }}
                            filter
                        >
                            { this.renderTemplateOptions() }
                        </Select>
                    </ControlGroup>
                    <ControlGroup
                        label='Polling Interval'
                        help='Frequency to run the search, in seconds.'
                        controlsLayout='none'
                    >
                        <Number
                            name='interval'
                            value={parseInt(this.state.interval, 10)}
                            step={60}
                            min={60}
                            style={{ width: 90 }}
                            onChange={this.handleRequestDataOnChange}
                            inline
                        />
                    </ControlGroup>
                    {/* This panel should render dynamically based on if this is a create or edit form (use mode value to determine) */}
                    {this.props.mode === 'create' && <CollapsiblePanel title='Advanced Options' style={{paddingBottom: 10}}>
                            <P style={{padding: 10, paddingTop: 10, paddingBottom: 10}}>Send events from this search to an existing index.</P>
                            <ControlGroup label='Index' help='Events from this search will be sent to the index selected.'>
                                <Select
                                    style={{width: 300}}
                                    value={this.state.index_id}
                                    onChange={this.handleRequestExistingIndex}
                                    filter
                                >
                                    <Select.Option label='Generate a new index (Default)' value=''/>
                                    {this.props.indexes.map((index) => (
                                        <Select.Option key={index.links.alternate} label={index.name} value={index.links.alternate}/>
                                    ))};
                                </Select>
                            </ControlGroup>
                            <P style={{padding: 10, paddingTop: 10, paddingBottom: 10}}>Send results from this search to an existing lookup. <Tooltip content="Warning! Lookups are overwritten on each poll. Multiple searches writing to a single lookup WILL overwrite each other." /></P>
                            <ControlGroup label='Lookup' help='Results from this search will be sent to the lookup selected.'>
                                <Select
                                    style={{width: 300}}
                                    value={this.state.lookup_id}
                                    onChange={this.handleRequestExistingLookup}
                                    filter
                                >
                                    <Select.Option label='Generate a new lookup (Default)' value=''/>
                                    {this.props.lookups.map((lookup) => (
                                        <Select.Option key={lookup.links.alternate} label={lookup.name} value={lookup.links.alternate}/>
                                    ))};
                                </Select>
                            </ControlGroup>
                        </CollapsiblePanel>
                    }
                    {this.props.mode === 'edit' &&
                        <div>
                            <ControlGroup
                                label='Index'
                                help='Events from this search will be sent to the index selected.'
                            >
                                <Text name='index' value={this.getNameByLinkAlternate(this.state.indexes, this.state.index_id)} disabled/>
                            </ControlGroup>

                             <ControlGroup
                                label='Results from this search will be sent to the lookup selected.'
                            >
                                <Text name='lookup' value={this.getNameByLinkAlternate(this.state.lookups, this.state.lookup_id)} disabled/>
                            </ControlGroup>
                        </div>
                    }
                    <P>
                        * Indicates required field.
                    </P>
                </Modal.Body>
                <Modal.Footer>
                    <Button appearance='secondary' label='Cancel' onClick={this.handleRequestClose}/>
                    { this.props.showSave && <Button appearance='primary' label='Save' onClick={this.handleRequestSubmit}/>}
                    { this.props.showSpinner && <WaitSpinner size="medium" style={{paddingLeft: 50, paddingRight: 50}} /> }
                </Modal.Footer>
            </Modal>
        );
    }
}
export default SearchForm;
