# MothershipApp

Add all information required to get started with @splunk/mothership-app here.
