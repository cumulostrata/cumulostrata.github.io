import React from 'react';
import layout from '@splunk/react-page';

import MothershipComponent from '@splunk/mothership-component';
import css from './index.css';

layout(
    <div className={css.container}>
        <MothershipComponent />
    </div>
);
