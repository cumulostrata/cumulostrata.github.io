import React from 'react';
import layout from '@splunk/react-page';

import MothershipTemplateComponent from '@splunk/mothership-template-component';
import css from './index.css';

layout(
    <div className={css.container}>
        <MothershipTemplateComponent />
    </div>
);
