module.exports = {
    extends: '@splunk/stylelint-config',
};
