## Third Party Packages
* schema, 0.6.8, MIT, https://github.com/keleshev/schema
* Python library for Splunk, 1.6.0, Apache 2.0, https://github.com/splunk/splunk-sdk-python
* @splunk/react-ui, 1.4.0, Splunk Software License Agreement, https://www.splunk.com/en_us/legal/splunk-software-license-agreement.html
* @splunk/react-sparkline, 0.3.1, Splunk Software License Agreement, https://www.splunk.com/en_us/legal/splunk-software-license-agreement.html
* uuid, 3.3.2, MIT, https://github.com/kelektiv/node-uuid
