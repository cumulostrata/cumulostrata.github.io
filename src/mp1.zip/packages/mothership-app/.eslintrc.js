module.exports = {
    extends: '@splunk/eslint-config/browser-prettier',
};
