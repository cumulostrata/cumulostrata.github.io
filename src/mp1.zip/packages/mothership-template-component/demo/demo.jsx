import React from 'react';
import { render } from 'react-dom';
import MothershipTemplateComponent from '../src/MothershipTemplateComponent';

const containerEl = document.getElementById('main-component-container');
render(<MothershipTemplateComponent name="World" />, containerEl);
