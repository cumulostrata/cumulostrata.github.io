# MothershipTemplateComponent

Add all information required to get started with @splunk/mothership-template-component here.
